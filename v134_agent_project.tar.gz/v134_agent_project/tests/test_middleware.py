"""
Тесты middleware chain.
Проверяет порядок выполнения, ApprovalMiddleware, MetricsMiddleware.
"""
import pytest
from pydantic import BaseModel

from app.tools.base import ApprovalRequired, BaseTool
from app.tools.middleware import (
    ApprovalMiddleware,
    MetricsMiddleware,
    MiddlewareChain,
    RetryMiddleware,
    build_default_chain,
)


# ── Тестовый инструмент ───────────────────────────────────────────────────────

class _EchoParams(BaseModel):
    text: str = "hello"


class _EchoTool(BaseTool):
    name = "echo_test"
    description = "Test echo tool"
    params_schema = _EchoParams
    dangerous = False

    async def execute(self, params: _EchoParams) -> str:
        return f"echo: {params.text}"


class _DangerousTool(BaseTool):
    name = "dangerous_test"
    description = "Test dangerous tool"
    params_schema = _EchoParams
    dangerous = True

    async def execute(self, params: _EchoParams) -> str:
        return f"executed: {params.text}"


class _FailingTool(BaseTool):
    name = "failing_test"
    description = "Always fails"
    params_schema = _EchoParams
    dangerous = False
    calls: int = 0

    async def execute(self, params: _EchoParams) -> str:
        _FailingTool.calls += 1
        raise ConnectionError("simulated")


# ── ApprovalMiddleware ────────────────────────────────────────────────────────

class TestApprovalMiddleware:
    async def test_safe_tool_passes(self):
        chain = MiddlewareChain([ApprovalMiddleware()])
        result = await chain.run(_EchoTool(), {"text": "x"})
        assert "echo: x" in result

    async def test_dangerous_tool_raises(self):
        chain = MiddlewareChain([ApprovalMiddleware()])
        with pytest.raises(ApprovalRequired) as exc_info:
            await chain.run(_DangerousTool(), {"text": "x"})
        assert exc_info.value.tool_name == "dangerous_test"

    async def test_dangerous_with_skip_approval(self):
        chain = MiddlewareChain([ApprovalMiddleware()])
        result = await chain.run(_DangerousTool(), {"text": "ok"}, skip_approval=True)
        assert "executed: ok" in result


# ── MetricsMiddleware ─────────────────────────────────────────────────────────

class TestMetricsMiddleware:
    async def test_records_duration(self):
        chain = MiddlewareChain([MetricsMiddleware()])
        from app.core.metrics import metrics
        before = metrics.snapshot()["totals"]["tool_calls"]

        await chain.run(_EchoTool(), {"text": "x"})

        after = metrics.snapshot()["totals"]["tool_calls"]
        assert after == before + 1

    async def test_metrics_dont_swallow_approval(self):
        """MetricsMiddleware не должен превращать ApprovalRequired в ошибку."""
        chain = MiddlewareChain([MetricsMiddleware(), ApprovalMiddleware()])
        with pytest.raises(ApprovalRequired):
            await chain.run(_DangerousTool(), {"text": "x"})


# ── RetryMiddleware ───────────────────────────────────────────────────────────

class TestRetryMiddleware:
    async def test_retries_on_connection_error(self):
        _FailingTool.calls = 0
        chain = MiddlewareChain([RetryMiddleware(max_retries=2)])
        with pytest.raises(ConnectionError):
            await chain.run(_FailingTool(), {"text": "x"})
        # 1 первоначальная + 2 retry = 3 вызова
        assert _FailingTool.calls == 3

    async def test_retry_doesnt_apply_to_approval(self):
        """RetryMiddleware не должен повторять ApprovalRequired."""
        _FailingTool.calls = 0
        chain = MiddlewareChain([RetryMiddleware(max_retries=3), ApprovalMiddleware()])
        with pytest.raises(ApprovalRequired):
            await chain.run(_DangerousTool(), {"text": "x"})


# ── Chain composition ────────────────────────────────────────────────────────

class TestMiddlewareChainComposition:
    async def test_order_outer_to_inner(self):
        """Middlewares выполняются в порядке: первый = внешний."""
        calls = []

        class _TraceMW:
            def __init__(self, label):
                self.label = label

            async def process(self, ctx, call_next):
                calls.append(f"{self.label}_before")
                result = await call_next(ctx)
                calls.append(f"{self.label}_after")
                return result

        chain = MiddlewareChain([_TraceMW("outer"), _TraceMW("inner")])
        await chain.run(_EchoTool(), {"text": "x"})

        assert calls == ["outer_before", "inner_before", "inner_after", "outer_after"]

    async def test_default_chain_includes_required_middlewares(self):
        chain = build_default_chain()
        types = [type(m).__name__ for m in chain._middlewares]
        assert "MetricsMiddleware" in types
        assert "ApprovalMiddleware" in types
        assert "RetryMiddleware" in types
