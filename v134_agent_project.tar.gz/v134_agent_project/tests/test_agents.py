"""
Тесты агентов с мок-ами Ollama и ToolService.
Новая архитектура: BaseAgent + create_agent() + ApprovalRequired через middleware.
"""
from unittest.mock import AsyncMock, MagicMock

import pytest

from app.agents.base import BaseAgent
from app.agents.prompts import get_agent_config
from app.agents.registry import create_agent, critic_is_approved
from app.tools.base import ApprovalRequired


def make_mock_ollama(response: str = "Test response") -> MagicMock:
    mock = MagicMock()
    mock.generate = AsyncMock(return_value=response)
    mock.current_model = "test-model"
    mock.TOOL_CALL_SCHEMA = {}
    # generate_structured возвращает None → агент падает на regex fallback
    # это тестирует что fallback работает корректно
    mock.generate_structured = AsyncMock(return_value=None)
    return mock


def make_mock_tools(parse_returns=(None, None), execute_raises=None, execute_returns=None) -> MagicMock:
    """
    parse_returns: list of (tool_name, params) tuples для последовательных вызовов
                   или один tuple для всех
    execute_raises: класс исключения которое .execute должен бросить
    execute_returns: ToolResult для возврата
    """
    from app.services.tool_service import ToolResult

    mock = MagicMock()
    mock.get_tools_description = MagicMock(return_value="- run_python: Запустить код")

    if isinstance(parse_returns, list):
        mock.parse_tool_call_from_text = MagicMock(side_effect=parse_returns)
    else:
        mock.parse_tool_call_from_text = MagicMock(return_value=parse_returns)

    if execute_raises:
        mock.execute = AsyncMock(side_effect=execute_raises)
    elif execute_returns:
        mock.execute = AsyncMock(return_value=execute_returns)
    else:
        mock.execute = AsyncMock(return_value=ToolResult("test", "[OK] done"))

    return mock


# ── Agent registry/factory ────────────────────────────────────────────────────

class TestAgentRegistry:
    def test_all_agents_have_config(self):
        for key in ["single", "manager", "architect", "coder", "critic", "tester"]:
            cfg = get_agent_config(key)
            assert cfg["name"]
            assert cfg["emoji"]
            assert cfg["system_prompt"]

    def test_unknown_agent_raises(self):
        with pytest.raises(ValueError):
            get_agent_config("unknown_xyz")

    def test_create_agent_valid(self):
        ollama = make_mock_ollama()
        tools = make_mock_tools()
        agent = create_agent("single", ollama, tools)
        assert agent.agent_key == "single"
        assert isinstance(agent, BaseAgent)

    def test_create_agent_invalid(self):
        ollama = make_mock_ollama()
        tools = make_mock_tools()
        with pytest.raises(ValueError):
            create_agent("unknown_xyz", ollama, tools)


# ── BaseAgent.run() ───────────────────────────────────────────────────────────

class TestBaseAgentRun:
    async def test_run_no_tool_call(self):
        """Агент отвечает без вызова инструментов."""
        ollama = make_mock_ollama("Вот мой ответ.")
        tools = make_mock_tools(parse_returns=(None, None))
        agent = create_agent("single", ollama, tools)

        result = await agent.run(
            user_msg="Привет",
            history_text="",
            session_id="test_session",
        )
        assert result.is_done()
        assert result.response == "Вот мой ответ."
        assert len(result.steps) == 0

    async def test_run_with_tool_call(self):
        """Агент вызывает инструмент, затем даёт финальный ответ."""
        from app.services.tool_service import ToolResult

        ollama = MagicMock()
        ollama.generate = AsyncMock(side_effect=[
            '```tool\n{"tool": "run_python", "params": {"code": "print(1)"}}\n```',
            "Код выполнен.",
        ])
        ollama.TOOL_CALL_SCHEMA = {}
        ollama.generate_structured = AsyncMock(return_value=None)  # → regex fallback
        tools = make_mock_tools(
            parse_returns=[
                ("run_python", {"code": "print(1)"}),
                (None, None),
            ],
            execute_returns=ToolResult("run_python", "[OK]\n1"),
        )
        agent = create_agent("single", ollama, tools)
        result = await agent.run(
            user_msg="Посчитай 1+1",
            history_text="",
            session_id="test_session",
        )
        assert result.is_done()
        assert len(result.steps) == 1
        assert result.steps[0].tool == "run_python"
        assert "1" in result.steps[0].result

    async def test_approval_required_caught(self):
        """Если ToolService бросает ApprovalRequired — агент возвращает confirm."""
        ollama = make_mock_ollama(
            '```tool\n{"tool": "write_file", "params": {"path": "/tmp/x", "content": "y"}}\n```'
        )
        # Mock tool service бросает ApprovalRequired
        tools = make_mock_tools(
            parse_returns=("write_file", {"path": "/tmp/x", "content": "y"}),
            execute_raises=ApprovalRequired("write_file", {"path": "/tmp/x", "content": "y"}),
        )
        agent = create_agent("single", ollama, tools)
        result = await agent.run(
            user_msg="Запиши файл",
            history_text="",
            session_id="test_session",
        )
        assert result.needs_confirm()
        assert result.pending_tool == "write_file"
        assert result.pending_action_id is not None
        assert result.pending_params == {"path": "/tmp/x", "content": "y"}


# ── Critic helper ─────────────────────────────────────────────────────────────

class TestCriticHelper:
    def test_approved_true(self):
        assert critic_is_approved("APPROVED")
        assert critic_is_approved("APPROVED. Код корректный.")
        assert critic_is_approved("approved")
        assert critic_is_approved("APPROVED\nКод хорошего качества.")

    def test_approved_false(self):
        assert not critic_is_approved("Есть баги в строке 5")
        assert not critic_is_approved("Нужно исправить ошибки")
        assert not critic_is_approved("")
        assert not critic_is_approved("NOT APPROVED")
        assert not critic_is_approved("REJECTED\nAPPROVED")
        assert not critic_is_approved("APPROVED WITH WARNINGS")
        assert not critic_is_approved("APPROVED BUT needs work")
        assert not critic_is_approved("APPROVED MAYBE")
        assert not critic_is_approved("I do not fully APPROVED this")


        assert not critic_is_approved("NOT APPROVED")
        assert not critic_is_approved("REJECTED\nAPPROVED")
        assert not critic_is_approved("APPROVED WITH WARNINGS")
        assert not critic_is_approved("APPROVED BUT needs work")
        assert not critic_is_approved("I do not fully APPROVED this")




# ── BaseAgent static helpers ──────────────────────────────────────────────────

class TestBaseAgentExtractors:
    def test_extract_code(self):
        text = "Вот код:\n```python\nprint('hello')\n```\nКонец."
        assert BaseAgent.extract_code(text) == "print('hello')"

    def test_extract_code_fallback_any_block(self):
        text = "```\nprint('world')\n```"
        assert BaseAgent.extract_code(text) == "print('world')"

    def test_extract_code_no_block(self):
        text = "Просто текст без кода"
        assert "Просто текст" in BaseAgent.extract_code(text)

    def test_extract_all_files_multiple(self):
        text = (
            "# main.py\n```python\nprint('main')\n```\n"
            "# utils.py\n```python\nprint('utils')\n```"
        )
        files = BaseAgent.extract_all_files(text)
        assert "main.py" in files
        assert "utils.py" in files
        assert "print('main')" in files["main.py"]

    def test_extract_all_files_fallback(self):
        """Если нет именованных файлов — берём первый блок как main.py."""
        text = "```python\nprint('single')\n```"
        files = BaseAgent.extract_all_files(text)
        assert "main.py" in files
        assert "print('single')" in files["main.py"]
    def test_extract_all_files_inline_filename(self):
        """Формат B: имя в первой строке внутри блока."""
        text = (
            "```python\n# main.py\nprint('main')\n```\n"
            "```python\n# utils.py\nprint('utils')\n```"
        )
        files = BaseAgent.extract_all_files(text)
        assert "main.py" in files
        assert "utils.py" in files

    def test_extract_all_files_with_path_prefix(self):
        """Формат C: имя с префиксом пути (как пишет Кодер)."""
        text = (
            "```python\n# filename.py tetris_game/main.py\nprint('main')\n```\n"
            "```python\n# tetris_game/game.py\nprint('game')\n```"
        )
        files = BaseAgent.extract_all_files(text)
        assert "main.py" in files
        assert "game.py" in files
        assert "print('main')" in files["main.py"]
        assert "print('game')" in files["game.py"]

    def test_extract_all_files_ignores_plain_comments(self):
        """Обычные комментарии не должны становиться файлами."""
        text = "```python\n# Это просто комментарий, не имя файла\nprint(1)\n```"
        files = BaseAgent.extract_all_files(text)
        # Должен fallback на main.py, а не создавать файл из комментария
        assert list(files.keys()) == ["main.py"]

