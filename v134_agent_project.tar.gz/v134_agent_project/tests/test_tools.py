"""
Тесты инструментов и tool service.
Используют новый API: BaseTool registry, ApprovalRequired middleware.
asyncio_mode=auto → async def тесты работают напрямую.
"""
import json
import os
import tempfile

import pytest

from app.schemas.tool import (
    ListFilesParams,
    ReadFileParams,
    SaveProjectParams,
    WriteFileParams,
    parse_and_validate_tool_call,
)
from app.services.tool_service import get_tool_service
from app.tools.base import ApprovalRequired, get_registry


# ── Pydantic schemas ──────────────────────────────────────────────────────────

class TestToolSchemas:
    def test_read_file_params_valid(self):
        p = ReadFileParams(path="/tmp/test.txt")
        assert p.path == "/tmp/test.txt"

    def test_read_file_params_empty_path(self):
        with pytest.raises(Exception):
            ReadFileParams(path="")

    def test_write_file_params_valid(self):
        p = WriteFileParams(path="/tmp/test.txt", content="hello")
        assert p.content == "hello"

    def test_save_project_params_sanitizes_name(self):
        p = SaveProjectParams(name="my project/v2", files={"main.py": "print(1)"})
        assert "/" not in p.name
        assert " " not in p.name

    def test_save_project_params_empty_files(self):
        with pytest.raises(Exception):
            SaveProjectParams(name="test", files={})

    def test_parse_tool_call_valid(self):
        name, params = parse_and_validate_tool_call({
            "tool": "run_python",
            "params": {"code": "print(1)"},
        })
        assert name == "run_python"
        assert params.code == "print(1)"

    def test_parse_tool_call_unknown_tool(self):
        with pytest.raises(Exception):
            parse_and_validate_tool_call({"tool": "delete_everything", "params": {}})

    def test_parse_tool_call_invalid_params(self):
        with pytest.raises(Exception):
            parse_and_validate_tool_call({"tool": "read_file", "params": {}})


# ── Tool registry (новая архитектура) ─────────────────────────────────────────

class TestToolRegistry:
    """BaseTool регистрация через @tool декоратор."""

    def test_all_default_tools_registered(self):
        reg = get_registry()
        for name in ["read_file", "write_file", "list_files", "run_python", "web_search", "save_project"]:
            assert name in reg, f"Tool {name} not registered"

    def test_dangerous_flag(self):
        reg = get_registry()
        assert reg["write_file"].dangerous is True
        assert reg["save_project"].dangerous is True
        assert reg["read_file"].dangerous is False
        assert reg["run_python"].dangerous is False


# ── read_file tool (async) ────────────────────────────────────────────────────

class TestReadFileTool:
    async def test_read_existing_file(self):
        from app.tools.read_file import ReadFileTool
        tool = ReadFileTool()
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False,
                                          dir=os.path.expanduser("~"), encoding='utf-8') as f:
            f.write("test content 123")
            path = f.name
        try:
            result = await tool.execute(ReadFileParams(path=path))
            assert "test content 123" in result
            assert "[OK]" in result
        finally:
            os.unlink(path)

    async def test_read_outside_home_blocked(self):
        from app.tools.read_file import ReadFileTool
        tool = ReadFileTool()
        # /etc явно вне $HOME
        result = await tool.execute(ReadFileParams(path="/etc/passwd"))
        assert "[BLOCKED]" in result

    async def test_read_nonexistent_file(self):
        from app.tools.read_file import ReadFileTool
        tool = ReadFileTool()
        home = os.path.expanduser("~")
        result = await tool.execute(ReadFileParams(path=f"{home}/nonexistent_xyz_123.txt"))
        assert "[ERROR]" in result


# ── list_files tool ───────────────────────────────────────────────────────────

class TestListFilesTool:
    async def test_list_home_directory(self):
        from app.tools.list_files import ListFilesTool
        tool = ListFilesTool()
        home = os.path.expanduser("~")
        result_json = await tool.execute(ListFilesParams(path=home))
        data = json.loads(result_json)
        assert data["ok"] is True
        assert "items" in data

    async def test_list_nonexistent_directory(self):
        from app.tools.list_files import ListFilesTool
        tool = ListFilesTool()
        home = os.path.expanduser("~")
        result_json = await tool.execute(ListFilesParams(path=f"{home}/nonexistent_xyz_123"))
        data = json.loads(result_json)
        assert data["ok"] is False


# ── ToolService + Middleware ──────────────────────────────────────────────────

class TestToolService:
    async def test_approval_required_for_dangerous(self):
        """ApprovalMiddleware должен бросить ApprovalRequired для write_file."""
        svc = get_tool_service()
        with pytest.raises(ApprovalRequired) as exc_info:
            await svc.execute("write_file", {"path": "/tmp/x.txt", "content": "y"})
        assert exc_info.value.tool_name == "write_file"

    async def test_skip_approval_bypasses_middleware(self):
        """skip_approval=True пропускает ApprovalMiddleware."""
        svc = get_tool_service()
        # write_file с путём вне Projects → [BLOCKED], но НЕ ApprovalRequired
        result = await svc.execute(
            "write_file",
            {"path": "/tmp/x.txt", "content": "y"},
            skip_approval=True,
        )
        # Должен дойти до выполнения tool, который вернёт [BLOCKED] из-за path guard
        assert "[BLOCKED]" in result.output or "[OK]" in result.output

    async def test_safe_tool_no_approval(self):
        """Безопасный инструмент выполняется без ApprovalRequired."""
        svc = get_tool_service()
        home = os.path.expanduser("~")
        result = await svc.execute("read_file", {"path": f"{home}/nonexistent.txt"})
        # Должен дойти до tool — он вернёт [ERROR] но не ApprovalRequired
        assert result.tool_name == "read_file"

    async def test_unknown_tool_returns_error(self):
        svc = get_tool_service()
        result = await svc.execute("delete_everything", {})
        assert result.success is False
        assert "Unknown tool" in result.output

    def test_is_dangerous(self):
        svc = get_tool_service()
        assert svc.is_dangerous("write_file")
        assert svc.is_dangerous("save_project")
        assert not svc.is_dangerous("read_file")
        assert not svc.is_dangerous("run_python")

    def test_parse_tool_call_from_text_valid(self):
        svc = get_tool_service()
        text = '```tool\n{"tool": "run_python", "params": {"code": "print(1)"}}\n```'
        name, params = svc.parse_tool_call_from_text(text)
        assert name == "run_python"
        assert params["code"] == "print(1)"

    def test_parse_tool_call_no_match(self):
        svc = get_tool_service()
        text = "Just a regular response."
        name, params = svc.parse_tool_call_from_text(text)
        assert name is None
        assert params is None

    def test_tools_description_includes_all(self):
        svc = get_tool_service()
        desc = svc.get_tools_description()
        for name in ["run_python", "read_file", "write_file"]:
            assert name in desc
        # Dangerous маркировка
        assert "подтверждения" in desc.lower() or "требует" in desc.lower()
