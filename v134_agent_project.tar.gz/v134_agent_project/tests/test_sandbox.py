"""
Тесты sandbox: AST guard + DockerRunner (subprocess fallback).
Используют asyncio_mode=auto — никакого asyncio.get_event_loop().
"""

from app.sandbox.ast_guard import ASTGuard
from app.sandbox.docker_runner import DockerRunner


# ── AST Guard ─────────────────────────────────────────────────────────────────

class TestASTGuard:
    def setup_method(self):
        self.guard = ASTGuard()

    def test_safe_code_passes(self):
        result = self.guard.check("x = 1 + 1\nprint(x)")
        assert result.safe, result.reason

    def test_import_blocked(self):
        result = self.guard.check("import os")
        assert not result.safe
        assert "import" in result.reason.lower()

    def test_from_import_blocked(self):
        result = self.guard.check("from os import path")
        assert not result.safe

    def test_exec_blocked(self):
        result = self.guard.check("exec('print(1)')")
        assert not result.safe

    def test_eval_blocked(self):
        result = self.guard.check("x = eval('1+1')")
        assert not result.safe

    def test_dunder_attr_blocked(self):
        result = self.guard.check("x.__class__.__subclasses__()")
        assert not result.safe

    def test_dunder_globals_blocked(self):
        result = self.guard.check("g = globals()")
        assert not result.safe

    def test_syntax_error_caught(self):
        result = self.guard.check("def f(:\n  pass")
        assert not result.safe
        assert "SyntaxError" in result.reason

    def test_math_operations_pass(self):
        result = self.guard.check("result = sum(range(100))\nprint(result)")
        assert result.safe

    def test_function_definition_passes(self):
        code = "def fib(n):\n    if n <= 1: return n\n    return fib(n-1) + fib(n-2)\nprint(fib(10))"
        assert self.guard.check(code).safe


# ── DockerRunner (subprocess fallback path) ───────────────────────────────────

class TestDockerRunnerSubprocess:
    """
    Принудительно тестируем subprocess fallback (без Docker).
    Async тесты — asyncio_mode=auto.
    """

    def setup_method(self):
        self.runner = DockerRunner()
        # Форсируем subprocess mode
        self.runner._docker_available = False
        self.runner._image_ready = False

    async def test_simple_print(self):
        result = await self.runner.run("print('hello world')")
        assert "hello world" in result.stdout

    async def test_math_works(self):
        result = await self.runner.run("print(2 ** 10)")
        assert "1024" in result.stdout

    async def test_dangerous_code_blocked(self):
        result = await self.runner.run("import os; os.listdir('/')")
        assert result.blocked

    async def test_timeout_respected(self, monkeypatch):
        """monkeypatch.setattr — надёжно для BaseSettings."""
        from app.core.config import settings
        monkeypatch.setattr(settings, "sandbox_timeout", 1)
        result = await self.runner.run("while True: pass")
        assert result.timed_out

    async def test_format_output_ok(self):
        result = await self.runner.run("print('test output')")
        formatted = result.format_output()
        assert "test output" in formatted
        assert "[OK]" in formatted

    async def test_format_output_blocked(self):
        result = await self.runner.run("import sys")
        formatted = result.format_output()
        assert "[BLOCKED]" in formatted

    async def test_unittest_works(self):
        """
        Sandbox prelude pre-imports unittest, поэтому пользовательский
        код может использовать unittest без import (AST guard блокирует import).
        """
        code = (
            "class T(unittest.TestCase):\n"
            "    def test_add(self):\n"
            "        self.assertEqual(1+1, 2)\n"
            "unittest.main(argv=['x'], exit=False, verbosity=0)\n"
        )
        result = await self.runner.run(code)
        assert not result.timed_out
        assert not result.blocked
