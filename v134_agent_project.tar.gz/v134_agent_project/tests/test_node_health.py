"""
test_node_health.py — «Health check на себя»

Идея: Anthropic перед каждым релизом Claude гоняет evals — заранее известные
тест-кейсы, где правильный ответ известен. Здесь то же самое для узлов графа.

Каждый тест берёт ЗАВЕДОМО СЛОМАННЫЙ input и проверяет, что узел его ловит.
Если узел молча пропускает — тест красный, значит защитный слой мёртв.

Именно так был пойман баг v131/v133: verifier с забытым `import ast` возвращал
0 проблем на явном Board.tick() (несуществующий метод). Тест ниже делает это
автоматически — теперь такое не проскочит незамеченным.
"""
import os
import tempfile

import pytest


# ════════════════════════════════════════════════════════════════════
# 1. VERIFIER — статический анализ AST (без LLM)
# ════════════════════════════════════════════════════════════════════

class TestVerifierHealth:
    """Verifier должен ловить сломанный код ДО запуска."""

    def _run_validators(self, files: dict[str, str]) -> dict:
        """
        files: {filename: source}. Запускает все три валидатора на временном
        каталоге со всеми указанными файлами.
        """
        from app.graph.nodes.verifier import (
            _validate_methods,
            _validate_names,
            _validate_imports,
        )
        with tempfile.TemporaryDirectory() as d:
            for name, src in files.items():
                open(os.path.join(d, name), "w", encoding="utf-8").write(src)
            return {
                "methods":  _validate_methods(d),
                "names":    _validate_names(d),
                "imports":  _validate_imports(d),
            }

    def test_catches_undefined_method_call(self):
        """
        Board.tick() не существует → _validate_methods должен поймать.
        Это ровно тот кейс, который молча проходил в v131 (import ast отсутствовал).
        """
        res = self._run_validators({
            "board.py": (
                "class Board:\n"
                "    def reset(self): return 1\n"  # tick НЕ объявлен
            ),
            "game.py": (
                "from board import Board\n"
                "class Game:\n"
                "    def __init__(self): self.board = Board()\n"
                "    def step(self):\n"
                "        self.board.tick()   # tick НЕ существует у Board!\n"
            ),
        })
        all_problems = res["methods"] + res["names"] + res["imports"]
        assert all_problems, (
            "Verifier вернул 0 проблем на явном Board.tick() (несуществующий метод). "
            "Скорее всего, import ast снова отсутствует или _validate_methods сломан. "
            "Это ровно баг из лога v131."
        )

    def test_catches_known_module_without_import(self):
        """
        pygame используется без 'import pygame' — _validate_names должен поймать.
        _validate_names консервативен: ловит только known_modules и имена из
        других файлов проекта (не все bare names — чтобы не было ложных тревог).
        """
        res = self._run_validators({
            "game.py": (
                "class Game:\n"
                "    def handle_event(self, e):\n"
                "        if e.type == pygame.KEYDOWN:   # pygame не импортирован!\n"
                "            return True\n"
            ),
        })
        all_problems = res["methods"] + res["names"] + res["imports"]
        assert all_problems, (
            "Verifier не поймал 'pygame' без импорта — _validate_names мёртв "
            "или not 'pygame' in _known_modules."
        )

    def test_catches_cross_file_missing_import(self):
        """
        FIGURE_COLORS определён в constants.py, используется в renderer.py
        без импорта → _validate_names должен поймать (имя в project_defined).
        """
        res = self._run_validators({
            "constants.py": "FIGURE_COLORS = [(255,0,0), (0,255,0)]\n",
            "renderer.py": (
                "class Renderer:\n"
                "    def draw(self):\n"
                "        return FIGURE_COLORS[0]   # не импортировано!\n"
            ),
        })
        all_problems = res["methods"] + res["names"] + res["imports"]
        assert all_problems, (
            "Verifier не поймал FIGURE_COLORS без импорта — "
            "_validate_names не ловит cross-file missing imports."
        )

    def test_passes_valid_code(self):
        """Верификатор НЕ должен флагировать корректный код."""
        res = self._run_validators({
            "board.py": (
                "class Board:\n"
                "    def reset(self): return 1\n"
                "    def tick(self): return 2\n"
            ),
            "game.py": (
                "from board import Board\n"
                "class Game:\n"
                "    def __init__(self): self.board = Board()\n"
                "    def step(self): self.board.tick()   # tick существует — OK\n"
            ),
        })
        # _validate_methods не должен флагировать существующий метод
        assert not res["methods"], (
            f"Verifier ложно флагировал корректный метод: {res['methods']}"
        )

    def test_ast_import_present(self):
        """
        Прямая защита от повторения бага: import ast должен быть в verifier.py.
        Если кто-то снова удалит — тест сразу красный, без запуска всего пайплайна.
        """
        import ast as _ast_stdlib
        import app.graph.nodes.verifier as v_module
        assert hasattr(v_module, "ast"), (
            "import ast отсутствует в verifier.py — все AST-валидаторы мертвы! "
            "Добавь 'import ast' в шапку файла."
        )
        assert v_module.ast is _ast_stdlib, (
            "verifier.ast — это не stdlib ast. Что-то импортировано не то."
        )


# ════════════════════════════════════════════════════════════════════
# 2. WRITE_FILE GUARD — undefined-name regression (v133 fix #4)
# ════════════════════════════════════════════════════════════════════

class TestWriteFileGuardHealth:
    """
    #4-гард в write_file должен блокировать правки, вводящие новые
    undefined имена (known_modules без import), и пропускать легитимные фиксы.

    Примечание: _PROJECTS_DIR в tools замораживается при импорте модуля,
    поэтому тесты работают с реальным settings.projects_dir.
    """

    @pytest.fixture
    def guard_proj(self):
        """Создаёт и чистит временный проект в реальном projects_dir."""
        from app.core.config import settings
        from app.core import active_project as ap

        proj_name = "_health_guard_test"
        proj_path = os.path.join(settings.projects_dir, proj_name)
        os.makedirs(proj_path, exist_ok=True)
        yield proj_name, proj_path
        # cleanup
        import shutil
        shutil.rmtree(proj_path, ignore_errors=True)

    async def test_blocks_known_module_without_import(self, guard_proj):
        """
        Правка добавляет вызов pygame без импорта → гард должен заблокировать.
        pygame входит в _known_modules pyflakes → уверенный undefined.
        """
        from app.tools.write_file import WriteFileTool
        from app.schemas.tool import WriteFileParams
        from app.core import active_project as ap

        proj_name, proj_path = guard_proj
        rel = f"{proj_name}/renderer.py"

        good = (
            "class Renderer:\n"
            "    def __init__(self, screen): self.screen = screen; self.score = 0\n"
            "    def draw(self): return self.score\n"
        )
        open(os.path.join(proj_path, "renderer.py"), "w", encoding="utf-8").write(good)

        bad = (
            "class Renderer:\n"
            "    def __init__(self, screen): self.screen = screen; self.score = 0\n"
            "    def draw(self): return self.score\n"
            "    def draw_bg(self):\n"
            "        self.screen.fill(pygame.Color('black'))   # pygame не импортирован!\n"
        )

        ap.set_fix_mode(True)
        ap.mark_file_read(rel)
        try:
            result = await WriteFileTool().execute(WriteFileParams(path=rel, content=bad))
            result = result if isinstance(result, str) else str(result)
            assert result.startswith("[ERROR]"), (
                "Гард НЕ заблокировал правку с 'pygame' без импорта. "
                f"Ответ: {result[:200]}"
            )
            assert "pygame" in result, "Гард не назвал проблемное имя в ответе."
            on_disk = open(os.path.join(proj_path, "renderer.py"), encoding="utf-8").read()
            assert on_disk == good, (
                "Гард отклонил, но файл всё равно перезаписан — рабочая версия испорчена!"
            )
        finally:
            ap.set_fix_mode(False)

    async def test_passes_self_attribute_fix(self, guard_proj):
        """
        Легитимный фикс: добавляем self.score = 0 в __init__.
        self.score — атрибут, pyflakes его не флагует → гард пропускает.
        """
        from app.tools.write_file import WriteFileTool
        from app.schemas.tool import WriteFileParams
        from app.core import active_project as ap

        proj_name, proj_path = guard_proj
        rel = f"{proj_name}/renderer2.py"

        original = (
            "class Renderer:\n"
            "    def __init__(self, cfg): self.cfg = cfg\n"
            "    def draw(self): return self.score   # self.score не задан в __init__\n"
        )
        fixed = (
            "class Renderer:\n"
            "    def __init__(self, cfg): self.cfg = cfg; self.score = 0\n"
            "    def draw(self): return self.score   # теперь OK\n"
        )
        open(os.path.join(proj_path, "renderer2.py"), "w", encoding="utf-8").write(original)

        ap.set_fix_mode(True)
        ap.mark_file_read(rel)
        try:
            result = await WriteFileTool().execute(WriteFileParams(path=rel, content=fixed))
            result = result if isinstance(result, str) else str(result)
            assert not result.startswith("[ERROR]"), (
                f"Гард ложно заблокировал легитимный фикс self.score: {result[:200]}"
            )
            on_disk = open(os.path.join(proj_path, "renderer2.py"), encoding="utf-8").read()
            assert "self.score = 0" in on_disk, "Файл не обновился после легитимного фикса."
        finally:
            ap.set_fix_mode(False)


# ════════════════════════════════════════════════════════════════════
# 3. READ_FILE — строка из traceback не прячется в середине файла
# ════════════════════════════════════════════════════════════════════

class TestReadFileHealth:
    """
    read_file должен показывать строку из traceback даже если файл > 6000 символов.
    В v131 порог 6000/окно 4500+1200 прятал строку 125 renderer.py (7196 симв.).
    """

    @pytest.fixture
    def read_proj(self):
        from app.core.config import settings
        proj_name = "_health_read_test"
        proj_path = os.path.join(settings.projects_dir, proj_name)
        os.makedirs(proj_path, exist_ok=True)
        yield proj_name, proj_path
        import shutil; shutil.rmtree(proj_path, ignore_errors=True)

    async def test_bug_line_visible_in_large_file(self, read_proj):
        """
        Файл ~8000+ символов, маркер гарантированно в [5000..size-1500]
        (старый skip-диапазон v131). Проверяем что v133+ видит его целиком.
        """
        from app.tools.read_file import ReadFileTool
        from app.schemas.tool import ReadFileParams

        proj_name, proj_path = read_proj

        head = "".join(f"# head {i:04d} " + "A" * 60 + "\n" for i in range(70))
        assert len(head) > 5000, "head слишком короткий — тест некорректен"

        mid = (
            "class Renderer:\n"
            "    def draw_game_over(self):\n"
            "        text = f'Score: {self.score_HEALTH_MARKER}'   # bug line\n"
            "        return text\n"
        )
        tail = "".join(f"# tail {i:04d} " + "B" * 60 + "\n" for i in range(40))
        src = head + mid + tail
        size = len(src)
        bug_pos = src.index("score_HEALTH_MARKER")

        assert 4500 <= bug_pos <= size - 1200, (
            f"Тест некорректен: маркер на {bug_pos}, старый skip [{4500}..{size-1200}]"
        )

        open(os.path.join(proj_path, "renderer.py"), "w", encoding="utf-8").write(src)

        result = await ReadFileTool().execute(
            ReadFileParams(path=f"{proj_name}/renderer.py")
        )
        result = result if isinstance(result, str) else str(result)

        assert "score_HEALTH_MARKER" in result, (
            f"read_file спрятал строку с багом (файл {size} симв., "
            f"маркер на позиции {bug_pos} = {int(bug_pos/size*100)}%). "
            f"Порог цельного чтения снова слишком мал — Кодер чинит вслепую."
        )


# ════════════════════════════════════════════════════════════════════
# 4. ИМПОРТЫ — критичные зависимости на месте
# ════════════════════════════════════════════════════════════════════

class TestImportHealth:
    """
    Быстрые проверки что критичные импорты существуют.
    Загораются сразу при регрессии, без запуска пайплайна.
    """

    def test_confirm_update_importable_from_single(self):
        """
        single.py должен иметь _confirm_update.
        В v131-v133 его не было → NameError на пути подтверждения.
        """
        import app.graph.nodes.single as single_mod
        assert hasattr(single_mod, "_confirm_update"), (
            "_confirm_update не импортирован в single.py → "
            "путь подтверждения упадёт с NameError."
        )

    def test_verifier_ast_not_missing(self):
        """Прямая защита: import ast не должен пропасть из verifier.py."""
        import ast as _ast_stdlib
        import app.graph.nodes.verifier as v
        assert hasattr(v, "ast") and v.ast is _ast_stdlib, (
            "import ast пропал из verifier.py — все 3 валидатора мертвы!"
        )

    def test_verifier_validators_are_callable(self):
        """Все три валидатора существуют, синхронные и вызываемые."""
        import inspect
        from app.graph.nodes.verifier import (
            _validate_methods, _validate_names, _validate_imports,
        )
        for fn in (_validate_methods, _validate_names, _validate_imports):
            assert callable(fn), f"{fn.__name__} не callable"
            assert not inspect.iscoroutinefunction(fn), (
                f"{fn.__name__} стал async — smoke вызывает его синхронно"
            )
