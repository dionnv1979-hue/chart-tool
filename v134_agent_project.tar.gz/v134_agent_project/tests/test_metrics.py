"""
Тесты MetricsCollector — agent_timer, sandbox_timer, record_tool, snapshot.
"""
import asyncio

import pytest

from app.core.metrics import MetricsCollector


class TestMetricsCollector:
    async def test_agent_timer_records(self):
        m = MetricsCollector()
        async with m.agent_timer("coder", "sess1", "single") as ctx:
            ctx.tokens(500)
            ctx.steps(2)
            await asyncio.sleep(0.005)

        snap = m.snapshot()
        assert snap["totals"]["agent_runs"] == 1
        assert "coder" in snap["agents"]
        assert snap["agents"]["coder"]["count"] == 1
        assert snap["agents"]["coder"]["avg_tokens"] == 500
        assert snap["agents"]["coder"]["avg_steps"] == 2.0
        assert snap["agents"]["coder"]["avg_ms"] >= 0

    async def test_agent_timer_marks_failure_on_exception(self):
        m = MetricsCollector()
        with pytest.raises(RuntimeError):
            async with m.agent_timer("coder", "sess1", "single"):
                raise RuntimeError("boom")

        snap = m.snapshot()
        assert snap["agents"]["coder"]["count"] == 1

    async def test_record_tool(self):
        m = MetricsCollector()
        m.record_tool("run_python", 120, success=True, dangerous=False)
        m.record_tool("write_file", 80, success=False, dangerous=True)

        snap = m.snapshot()
        assert snap["tools"]["run_python"]["count"] == 1
        assert snap["tools"]["run_python"]["avg_ms"] == 120
        assert snap["tools"]["run_python"]["errors"] == 0
        assert snap["tools"]["write_file"]["errors"] == 1
        assert snap["totals"]["tool_calls"] == 2

    async def test_sandbox_timer_records_flags(self):
        m = MetricsCollector()
        async with m.sandbox_timer(docker=True) as sb:
            sb.timeout()

        snap = m.snapshot()
        assert snap["sandbox"]["count"] == 1
        assert snap["sandbox"]["timeouts"] == 1
        assert snap["sandbox"]["docker_runs"] == 1
        assert snap["sandbox"]["blocked"] == 0

    async def test_snapshot_empty(self):
        m = MetricsCollector()
        snap = m.snapshot()
        assert snap["totals"]["agent_runs"] == 0
        assert snap["totals"]["tool_calls"] == 0
        assert snap["agents"] == {}
        assert snap["tools"] == {}

    async def test_window_limit(self):
        """MetricsCollector с window=3 не должен хранить больше 3 записей."""
        m = MetricsCollector(window=3)
        for i in range(5):
            m.record_tool(f"tool_{i}", 100, success=True, dangerous=False)

        snap = m.snapshot()
        # Только последние 3 инструмента
        assert snap["totals"]["tool_calls"] == 3
