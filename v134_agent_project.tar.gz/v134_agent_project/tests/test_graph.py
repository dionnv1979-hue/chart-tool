"""
Тесты LangGraph routing functions.
Роутеры не зависят от внешних сервисов — чистая логика.
Запуск: pytest tests/test_graph.py -v
"""

from app.graph.routes import (
    route_after_critic,
    route_single_or_pipeline,
    route_after_any_agent,
    route_after_human_approval,
)
from app.graph.state import WorkflowState


def make_state(**kwargs) -> WorkflowState:
    """Хелпер для создания тестового state."""
    defaults = {
        "session_id": "test",
        "user_message": "Test",
        "mode": "single",
        "results": [],
        "current_context": "",
        "current_code": "",
        "debate_round": 0,
        "critic_approved": False,
        "pending_action_id": None,
        "pending_tool": None,
        "pending_params": None,
        "pending_agent": None,
        "pending_thought": "",
        "pending_steps": [],
        "resume_prompt": None,
        "resume_step": 0,
        "final_response": None,
        "final_type": "done",
        "error_message": None,
        "next_node": None,
    }
    defaults.update(kwargs)
    return WorkflowState(**defaults)


class TestRouteSingleOrPipeline:

    def test_single_mode(self):
        state = make_state(mode="single")
        assert route_single_or_pipeline(state) == "single_agent"

    def test_multi_mode(self):
        state = make_state(mode="multi")
        assert route_single_or_pipeline(state) == "manager"

    def test_debate_mode(self):
        state = make_state(mode="debate")
        assert route_single_or_pipeline(state) == "coder"

    def test_default_mode(self):
        # Если mode не установлен — default в state TypedDict
        state = make_state()  # mode="single"
        assert route_single_or_pipeline(state) == "single_agent"


class TestRouteAfterCritic:

    def test_approved_goes_to_tester(self):
        state = make_state(critic_approved=True, debate_round=1)
        assert route_after_critic(state) == "tester"

    def test_not_approved_low_rounds_goes_to_coder(self):
        state = make_state(critic_approved=False, debate_round=1)
        # debate_max_rounds по умолчанию 3 → раунд 1 → ещё есть место
        assert route_after_critic(state) == "coder"

    def test_not_approved_max_rounds_goes_to_tester(self):
        from app.core.config import settings
        max_r = settings.debate_max_rounds
        state = make_state(critic_approved=False, debate_round=max_r)
        assert route_after_critic(state) == "tester"

    def test_approved_at_max_rounds_goes_to_tester(self):
        from app.core.config import settings
        max_r = settings.debate_max_rounds
        state = make_state(critic_approved=True, debate_round=max_r)
        assert route_after_critic(state) == "tester"


class TestRouteAfterAnyAgent:

    def test_pending_action_goes_to_human_approval(self):
        state = make_state(pending_action_id="action_123")
        assert route_after_any_agent(state) == "human_approval"

    def test_no_pending_uses_next_node(self):
        state = make_state(pending_action_id=None, next_node="architect")
        assert route_after_any_agent(state) == "architect"

    def test_no_pending_no_next_node(self):
        state = make_state(pending_action_id=None, next_node=None)
        assert route_after_any_agent(state) == "end"


class TestRouteAfterHumanApproval:

    def test_pending_action_awaits(self):
        state = make_state(pending_action_id="action_123")
        assert route_after_human_approval(state) == "await_confirmation"

    def test_no_pending_goes_to_save_project(self):
        state = make_state(pending_action_id=None)
        assert route_after_human_approval(state) == "save_project"
