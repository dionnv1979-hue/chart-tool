"""
Pytest конфигурация и shared fixtures.

pytest-asyncio в режиме auto: все async def тесты автоматически становятся
asyncio-тестами без декоратора. Никакого asyncio.get_event_loop().
"""
import inspect
import pytest


def pytest_collection_modifyitems(config, items):
    """Авто-маркировка async тестов как asyncio."""
    for item in items:
        if hasattr(item, "function") and inspect.iscoroutinefunction(item.function):
            item.add_marker(pytest.mark.asyncio)


@pytest.fixture
def tmp_projects_dir(tmp_path, monkeypatch):
    """
    Перенаправляет projects_dir в tmp_path.
    Использует monkeypatch.setattr (не хрупкий __dict__-патч).
    """
    from app.core.config import settings
    monkeypatch.setattr(settings, "projects_dir", str(tmp_path))
    return tmp_path


@pytest.fixture(autouse=True, scope="session")
def _discover_tools():
    """Регистрирует все инструменты один раз для всей сессии тестов."""
    from app.tools import discover_tools
    discover_tools()
    yield
