"""
LangGraph workflow builder.
Собирает граф из узлов и рёбер.
Граф компилируется один раз и переиспользуется для всех запросов.

Топология:
    START → router → single_agent | manager | coder(debate)
    manager → architect → coder → verifier → critic
    verifier: hard reject (coverage<50%) → coder напрямую, без LLM критика
    critic → coder (если не APPROVED и раунды не исчерпаны)
    critic → tester (если APPROVED или исчерпаны раунды)
    tester: реальный запуск (smoke-тест) → human_approval | coder (если упал)
    tester → human_approval
    human_approval → save_project | [await_confirm]
    save_project → END
    single_agent → human_approval (если confirm нужен) | END
"""
from langgraph.graph import StateGraph, END, START
from langgraph.checkpoint.memory import MemorySaver

from app.core.logger import get_logger
from app.graph.nodes import (
    make_single_agent_node,
    make_manager_node,
    make_architect_node,
    make_coder_node,
    make_critic_node,
    make_tester_node,
    make_human_approval_node,
    make_save_project_node,
    make_verifier_node,
)
from app.graph.routes import (
    route_after_critic,
    route_single_or_pipeline,
    route_after_any_agent,
    route_after_human_approval,
    route_after_verifier,
)
from app.graph.state import WorkflowState
from app.services.ollama_service import OllamaService
from app.services.tool_service import ToolService

logger = get_logger(__name__)


def build_workflow(
    ollama: OllamaService,
    tools: ToolService,
    pending_repo_factory,
) -> StateGraph:
    """
    Строит и компилирует LangGraph workflow.

    Args:
        ollama: OllamaService (синглтон)
        tools: ToolService (синглтон)
        pending_repo_factory: callable → PendingActionRepository

    Returns:
        Скомпилированный граф (CompiledGraph)
    """
    graph = StateGraph(WorkflowState)

    # ── Регистрация узлов ─────────────────────────────────────────────────
    graph.add_node("single_agent", make_single_agent_node(ollama, tools))
    graph.add_node("manager", make_manager_node(ollama, tools))
    graph.add_node("architect", make_architect_node(ollama, tools))
    graph.add_node("coder", make_coder_node(ollama, tools))
    graph.add_node("verifier", make_verifier_node())   # программная проверка факта
    graph.add_node("critic", make_critic_node(ollama, tools))
    graph.add_node("tester", make_tester_node(ollama, tools))
    graph.add_node("human_approval", make_human_approval_node(pending_repo_factory))
    graph.add_node("save_project", make_save_project_node(ollama, tools))

    # ── Рёбра от START ────────────────────────────────────────────────────
    # Начальный conditional edge выбирает маршрут по mode
    graph.add_conditional_edges(
        START,
        route_single_or_pipeline,
        {
            "single_agent": "single_agent",
            "manager": "manager",
            "coder": "coder",      # debate режим начинается с coder
        },
    )

    # ── Pipeline рёбра ────────────────────────────────────────────────────
    # manager → architect (если нет confirm)
    graph.add_conditional_edges(
        "manager",
        route_after_any_agent,
        {
            "human_approval": "human_approval",
            "architect": "architect",
            "end": END,
        },
    )

    # architect → coder
    graph.add_conditional_edges(
        "architect",
        route_after_any_agent,
        {
            "human_approval": "human_approval",
            "coder": "coder",
            "end": END,
        },
    )

    # coder → verifier (сначала программная проверка факта)
    graph.add_conditional_edges(
        "coder",
        route_after_any_agent,
        {
            "human_approval": "human_approval",
            "critic": "verifier",   # всегда через верификатор
            "end": END,
        },
    )

    # verifier → critic | coder (если hard reject — минуем LLM критика)
    graph.add_conditional_edges(
        "verifier",
        route_after_verifier,
        {
            "critic": "critic",
            "coder": "coder",   # hard reject: сразу обратно к кодеру
        },
    )

    # critic → coder | tester (зависит от APPROVED и раундов)
    graph.add_conditional_edges(
        "critic",
        route_after_critic,
        {
            "coder": "coder",
            "tester": "tester",
        },
    )

    # tester → human_approval | coder (если smoke-тест провалился)
    graph.add_conditional_edges(
        "tester",
        route_after_any_agent,
        {
            "human_approval": "human_approval",
            "save_project": "save_project",
            "coder": "coder",   # реальный запуск провалился → чинить
            "end": END,
        },
    )

    # single_agent → human_approval | END
    graph.add_conditional_edges(
        "single_agent",
        route_after_any_agent,
        {
            "human_approval": "human_approval",
            "end": END,
        },
    )

    # human_approval → save_project | await (workflow останавливается)
    graph.add_conditional_edges(
        "human_approval",
        route_after_human_approval,
        {
            "save_project": "save_project",
            "await_confirmation": END,  # Workflow завершается, возобновляется через /confirm
        },
    )

    # save_project → END
    graph.add_edge("save_project", END)

    logger.info("LangGraph workflow built successfully")
    return graph


def compile_workflow(
    ollama: OllamaService,
    tools: ToolService,
    pending_repo_factory,
):
    """
    Компилирует workflow с in-memory checkpointer.
    MemorySaver позволяет сохранять state между вызовами (для resume).
    """
    graph = build_workflow(ollama, tools, pending_repo_factory)
    checkpointer = MemorySaver()
    compiled = graph.compile(checkpointer=checkpointer)
    logger.info("LangGraph workflow compiled with MemorySaver")
    return compiled


# Синглтон скомпилированного графа
_compiled_workflow = None


def get_workflow(
    ollama: OllamaService | None = None,
    tools: ToolService | None = None,
    pending_repo_factory=None,
):
    """
    Возвращает скомпилированный workflow.
    При первом вызове требует все аргументы.
    При последующих — возвращает кешированный.
    """
    global _compiled_workflow
    if _compiled_workflow is None:
        if ollama is None or tools is None or pending_repo_factory is None:
            raise RuntimeError(
                "Workflow не инициализирован. "
                "Вызовите get_workflow() с аргументами при старте приложения."
            )
        _compiled_workflow = compile_workflow(ollama, tools, pending_repo_factory)
    return _compiled_workflow
