"""Nodes package — узлы LangGraph workflow."""
import hashlib
import json
import os
import re
import time

from app.agents.base import BaseAgent
from app.agents.prompts import AGENTS
from app.agents.registry import create_agent, critic_is_approved
from app.core.logger import get_logger
from app.core.config import settings
from app.core import events as _events
from app.core.workspace import promote, list_staging_projects
from app.graph.state import WorkflowState
from app.schemas.chat import AgentResultSchema, ToolStepSchema
from app.schemas.tool import SaveProjectParams
from app.services.ollama_service import OllamaService
from app.services.tool_service import ToolService

logger = get_logger(__name__)
from app.graph.nodes.helpers import _load_agent_models, _append_result
from app.graph.nodes.save import _confirm_update

def make_manager_node(ollama: OllamaService, tools: ToolService):
    async def node(state: WorkflowState) -> dict:
        # #5: сбрасываем каноническое имя в начале каждого прогона пайплайна —
        # чтобы имя предыдущего проекта не протекло в новый.
        from app.core.active_project import set_active_project, set_fix_mode
        set_active_project(state.get("project_name") or None)
        set_fix_mode(False)  # свежая сборка — строгий regression guard

        # Берём из state (загружено один раз в начале pipeline)
        agent_models = state.get("agent_models") or {}
        agent = create_agent("manager", ollama, tools, model_override=agent_models.get("manager"),
                             params=(state.get("agent_params") or {}).get("manager"))
        run = await agent.run(
            user_msg=state["user_message"],
            history_text=state.get("history_text", ""),
            session_id=state["session_id"],
            images=state.get("images") or None,
        )
        if run.needs_confirm():
            return _confirm_update(run, "multi_confirm")
        return {
            "current_context": run.response,
            "results": _append_result(
                state, run.to_agent_result_schema(label="Менеджер — план")
            ),
            "pending_action_id": None,
            "next_node": "architect",
        }
    return node


# ── architect ─────────────────────────────────────────────────────────────────

def make_architect_node(ollama: OllamaService, tools: ToolService):
    async def node(state: WorkflowState) -> dict:
        # Берём из state (загружено один раз в начале pipeline)
        agent_models = state.get("agent_models") or {}
        agent = create_agent("architect", ollama, tools, model_override=agent_models.get("architect"),
                             params=(state.get("agent_params") or {}).get("architect"))

        # ── Скилл из библиотеки: проверенная структура похожей задачи ──────
        _skill_block = ""
        try:
            from app.learning.skill_library import recall_skill
            _skill_block = recall_skill(state["user_message"])
            if _skill_block:
                _skill_block = f"\n{_skill_block}\n"
        except Exception:
            pass

        run = await agent.run(
            user_msg=state["user_message"],
            history_text=state.get("history_text", ""),
            session_id=state["session_id"],
            extra_context=(
                f"\n\n=== ПЛАН МЕНЕДЖЕРА ===\n{state.get('current_context', '')}\n"
                + _skill_block
                + (f"\n{state.get('project_context')}\n" if state.get('project_context') else "")
            ),
        )
        if run.needs_confirm():
            return _confirm_update(run, "multi_confirm")

        # #5: фиксируем каноническое имя проекта СРАЗУ после Архитектора —
        # из строки PROJECT_NAME. Дальше Кодер/инструменты приводят все пути
        # к этому имени, дубликаты папок (Tetris vs TetrisGame) исключены.
        import re as _re
        from app.core.active_project import set_active_project
        from app.graph.nodes.verifier import _parse_required_files
        pname = state.get("project_name") or ""
        m = _re.search(r"PROJECT_NAME:\s*([\w\-\.]{2,50})", run.response)
        if m:
            pname = m.group(1).strip()
        if pname:
            set_active_project(pname)

        # ── ЗАМОРОЗКА АРХИТЕКТУРЫ ──────────────────────────────────────────
        # Список файлов фиксируется ОДИН раз из плана Архитектора и дальше не
        # меняется. Иначе Кодер каждый раунд переизобретает структуру
        # (required=10→9→15), и coverage становится бессмысленным.
        frozen_files = _parse_required_files(run.response)

        # ── Гард доработки: новый файл, дублирующий существующий по смыслу
        # имени (input_handler.py при живом input_manager.py), создаёт
        # параллельный модуль и рассинхрон API (кейс из лога). Требуем
        # расширять СУЩЕСТВУЮЩИЙ файл.
        if frozen_files and state.get("project_context"):
            try:
                import difflib as _dl
                from app.core.active_project import get_active_project
                _ap = get_active_project()
                if _ap:
                    _pdir = os.path.join(settings.projects_dir, _ap)
                    _existing = {f for f in os.listdir(_pdir)
                                 if f.endswith(".py")} if os.path.isdir(_pdir) else set()
                    _dupes = []
                    for _nf in frozen_files:
                        _nb = os.path.basename(_nf)
                        if _nb in _existing:
                            continue
                        for _ex in _existing:
                            _r = _dl.SequenceMatcher(
                                None, os.path.splitext(_nb)[0],
                                os.path.splitext(_ex)[0]).ratio()
                            if _r >= 0.72:
                                _dupes.append((_nb, _ex))
                                break
                    if _dupes:
                        _dup_txt = "; ".join(f"{n} ≈ {e}" for n, e in _dupes)
                        logger.warning(f"Architect duplicate-module guard: {_dup_txt}")
                        run = await agent.run(
                            user_msg=state["user_message"],
                            history_text=state.get("history_text", ""),
                            session_id=state["session_id"],
                            extra_context=(
                                f"⛔ ТВОЙ ПЛАН СОЗДАЁТ ДУБЛИ существующих модулей: "
                                f"{_dup_txt}.\n"
                                f"Это рассинхронизирует API (два модуля одной "
                                f"ответственности). ПЕРЕДЕЛАЙ ПЛАН: расширяй/правь "
                                f"СУЩЕСТВУЮЩИЙ файл (включи его имя в список), "
                                f"НЕ вводи параллельный. Существующие файлы: "
                                f"{', '.join(sorted(_existing))}\n\n"
                                + (state.get("project_context") or "")
                            ),
                        )
                        if run.needs_confirm():
                            return _confirm_update(run, "multi_confirm")
                        frozen_files = _parse_required_files(run.response) or frozen_files
            except Exception as _e:
                logger.warning(f"duplicate-module guard skipped: {_e}")
        logger.info(
            f"Архитектура зафиксирована: {len(frozen_files)} файлов — {frozen_files}"
        )

        # ── Санкция за отсутствующий REQUIRED_FILES_JSON ──────────────────
        # Без этого маркера verifier не может считать coverage, LLM-гейт
        # открыт, неполный проект проходит к тестеру. Если Архитектор
        # не написал маркер — возвращаем его один раз с явным требованием.
        # Делаем это ТОЛЬКО если в ответе вообще нет файлов (не просто нет
        # JSON-маркера — regex-fallback мог найти список). Один retry.
        _arch_retry = state.get("_arch_retry", 0)
        if not frozen_files and _arch_retry == 0:
            logger.warning("Архитектор не указал ни одного файла — запрашиваем повтор")
            retry_ctx = (
                f"\n\n=== ПЛАН МЕНЕДЖЕРА ===\n{state.get('current_context', '')}\n\n"
                f"❌ ОШИБКА: в предыдущем ответе не найден список файлов.\n"
                f"ОБЯЗАТЕЛЬНО добавь в конце ответа:\n"
                f'REQUIRED_FILES_JSON: ["файл1.py", "файл2.py", ...]\n'
                f"(точный машиночитаемый список ВСЕХ файлов проекта)\n"
            )
            run2 = await agent.run(
                user_msg=state["user_message"],
                history_text=state.get("history_text", ""),
                session_id=state["session_id"],
                extra_context=retry_ctx,
            )
            if run2.needs_confirm():
                return _confirm_update(run2, "multi_confirm")
            frozen_files = _parse_required_files(run2.response)
            if frozen_files:
                run = run2  # используем повторный ответ
                m2 = _re.search(r"PROJECT_NAME:\s*([\w\-\.]{2,50})", run2.response)
                if m2:
                    pname = m2.group(1).strip()
            logger.info(f"Архитектор retry: {len(frozen_files)} файлов — {frozen_files}")

        # ── Чеклист файлов (TodoWrite-стиль): write_file будет отмечать
        # прогресс, Кодер видит "3/8, осталось: ..." в каждом tool result.
        if frozen_files:
            try:
                from app.core.active_project import set_checklist
                set_checklist(frozen_files)
                await _events.emit(state["session_id"], "checklist",
                    done=0, total=len(frozen_files),
                    remaining=[f.split("/")[-1] for f in frozen_files])
            except Exception:
                pass

        return {
            "current_context": run.response,
            "project_name": pname,
            "required_files": frozen_files,   # заморожено, verifier/save используют это
            "architecture_locked": bool(frozen_files),
            "_arch_retry": _arch_retry + 1,
            "results": _append_result(
                state, run.to_agent_result_schema(label="Архитектор — структура")
            ),
            "pending_action_id": None,
            "next_node": "coder",
        }
    return node


# ── coder ─────────────────────────────────────────────────────────────────────

def make_coder_node(ollama: OllamaService, tools: ToolService):
    async def node(state: WorkflowState) -> dict:
        mode = state.get("mode", "single")
        debate_round = state.get("debate_round", 0)
        test_round = state.get("test_round", 0)
        context = state.get("current_context", "")

        label = (
            f"Кодер — правка {debate_round + 1}" if mode == "debate" and debate_round > 0
            else "Кодер — первая версия" if mode == "debate"
            else f"Кодер — починка (раунд {test_round})" if test_round > 0
            else "Кодер"
        )

        # ── Repair-prefix: фокусированный контекст для раундов починки ────
        # В repair-раунде основной системный промпт содержит шум ("напиши 8 файлов",
        # "правильный порядок" и т.п.) — нерелевантный когда задача одна: исправить
        # конкретную строку. Добавляем короткий prefix с ошибкой прямо перед ответом.
        repair_prefix = ""
        if test_round > 0:
            last_err = state.get("last_error_text", "")
            if last_err:
                err_tail = last_err[-800:]
                # Эскалация: ошибка не изменилась с прошлого раунда —
                # значит прошлый "фикс" не применился или применён не туда.
                _same_err = ""
                _prev_sig = state.get("prev_round_sig", "")
                _cur_sig = state.get("last_error_sig", "")
                if _prev_sig and _cur_sig and _prev_sig == _cur_sig:
                    _same_err = (
                        "⚠️ ЭТА ЖЕ ОШИБКА БЫЛА В ПРОШЛОМ РАУНДЕ — твой фикс "
                        "НЕ СРАБОТАЛ. Причины: правил не тот файл (смотри ПУТЬ в "
                        "traceback!), str_replace не применился, или имя "
                        "используется ещё в нескольких местах (grep_files по имени "
                        "из ошибки покажет ВСЕ).\n"
                    )
                repair_prefix = (
                    f"=== РЕЖИМ ПОЧИНКИ (раунд {test_round}) ===\n"
                    f"{_same_err}"
                    f"Проект написан. Исправь ПЕРВОПРИЧИНУ ошибки.\n"
                    f"Ошибки класса NameError/ImportError почти всегда "
                    f"МНОЖЕСТВЕННЫЕ: если ниже дан полный список (pyflakes) — "
                    f"почини ВСЕ пункты ЗА ЭТОТ РАУНД, файл за файлом. Не чини "
                    f"по одному имени!\n"
                    f"Правки точечные (str_replace), но столько, сколько нужно. "
                    f"НЕ переписывай файлы целиком, НЕ пиши новые с нуля.\n"
                    f"ДОКАЗАТЕЛЬСТВО ФИКСА (red→green): для логических багов "
                    f"(не SyntaxError/NameError) сначала test_fix.py, "
                    f"воспроизводящий баг (упадёт), потом фикс, тест зелёный, "
                    f"тест оставь в проекте.\n"
                    f"Ошибка запуска:\n{err_tail}\n"
                    f"Алгоритм: (1) определи файл и строку по трейсбэку, "
                    f"(2) read_file чтобы увидеть контекст, "
                    f"(3) str_replace чтобы исправить только эту строку.\n"
                    f"{'='*44}\n\n"
                )

        # ── Уроки из прошлых проектов (только первый раунд, не repair) ─────
        # В repair-раундах контекст и так заполнен ошибкой — уроки шумят.
        _lessons_block = ""
        if test_round == 0 and debate_round == 0:
            try:
                from app.learning.lessons import recall_lessons
                _lessons_block = recall_lessons(state["user_message"])
                if _lessons_block:
                    _lessons_block += "\n"
            except Exception:
                pass
            # Контракт существующего проекта: known packages, последний фикс
            if state.get("project_context"):
                _lessons_block = state["project_context"] + "\n" + _lessons_block

        # Берём из state (загружено один раз в начале pipeline)
        agent_models = state.get("agent_models") or {}
        agent = create_agent("coder", ollama, tools, model_override=agent_models.get("coder"),
                             params=(state.get("agent_params") or {}).get("coder"))
        run = await agent.run(
            user_msg=state["user_message"],
            history_text=state.get("history_text", ""),
            session_id=state["session_id"],
            extra_context=(
                repair_prefix
                + _lessons_block
                + (
                    (f"[ЗАФИКСИРОВАНО] Имя проекта: {state.get('project_name','')}\n"
                     f"write_file path={state.get('project_name','')+'/'}<файл.py>, save_project name={state.get('project_name','')}\n"
                     f"НЕ меняй имя проекта!\n\n")
                    if state.get("project_name") else ""
                )
                + (f"=== КОНТЕКСТ ===\n{context}\n" if context else "")
            ),
        )
        if run.needs_confirm():
            return _confirm_update(run, "multi_confirm")

        # ── Гард: repair-раунд БЕЗ ЕДИНОЙ ПРАВКИ = потерянный раунд ────────
        # (лог: Кодер читал файлы, написал текст "нужно добавить..." и вышел).
        # Один принудительный повтор с жёстким префиксом.
        if test_round > 0:
            _edit_tools = {"str_replace", "write_file"}
            _used = {st.tool for st in (run.steps or [])}
            if not (_edit_tools & _used):
                logger.warning(f"Coder repair round {test_round}: НИ ОДНОЙ правки "
                               f"(tools={_used or '∅'}) — принудительный повтор")
                run = await agent.run(
                    user_msg=state["user_message"],
                    history_text=state.get("history_text", ""),
                    session_id=state["session_id"],
                    extra_context=(
                        "⛔ ТЫ НЕ СДЕЛАЛ НИ ОДНОЙ ПРАВКИ. Слова не чинят код.\n"
                        "ПРЯМО СЕЙЧАС: str_replace с конкретным old_str/new_str "
                        "по ошибке ниже. Файл бери из ПУТИ в traceback.\n\n"
                        + repair_prefix
                    ),
                )
                if run.needs_confirm():
                    return _confirm_update(run, "multi_confirm")

        # Сигнатура текущей ошибки — для эскалации "тот же баг" в след. раунде
        # (используем готовый last_error_sig тестера — стабильная нормализация)
        _sig_update = {}
        if test_round > 0 and state.get("last_error_sig"):
            _sig_update["prev_round_sig"] = state["last_error_sig"]

        return {
            "current_code": run.response,
            "results": _append_result(
                state, run.to_agent_result_schema(label=label, round_n=debate_round + 1)
            ),
            "pending_action_id": None,
            "next_node": "critic",
            **_sig_update,
        }
    return node


# ── critic ────────────────────────────────────────────────────────────────────

def make_critic_node(ollama: OllamaService, tools: ToolService):
    async def node(state: WorkflowState) -> dict:
        debate_round = state.get("debate_round", 0)
        current_code = state.get("current_code", "")

        extra = (
            f"\n\n=== КОД КОДЕРА (раунд {debate_round + 1}) ===\n"
            f"{current_code[:3000]}\n\n"
            f"Проверь: есть ли РЕАЛЬНЫЙ код выше?\n"
            f"- Если нет кода (только текст/отказ) — пиши REJECTED\n"
            f"- Если GUI/сетевой/серверный код — визуально проверь структуру, пиши APPROVED если логика верна\n"
            f"- Если чистая логика — можешь запустить run_python\n"
        )

        # Верификатор уже проверил факты — вставляем как жёсткий контекст
        fact_report = state.get("verifier_fact_report", "")
        if fact_report:
            extra = (
                f"\n\n=== ПРОГРАММНАЯ ФАКТ-ПРОВЕРКА (результат верификатора) ===\n"
                f"{fact_report}\n\n"
                f"ВАЖНО: эти данные получены программно (os.walk + regex), не со слов модели.\n"
                f"Если покрытие < 80% или есть отсутствующие файлы — это ФАКТ, не мнение.\n"
                f"─────────────────────────────────────────────────\n"
            ) + extra

        # Если уже был реальный запуск (повторный заход после fix) — даём вердикт
        tester_report = state.get("tester_report", "")
        if tester_report:
            extra = (
                f"\n\n=== РЕЗУЛЬТАТ РЕАЛЬНОГО ЗАПУСКА ===\n{tester_report}\n"
                f"─────────────────────────────────────────────────\n"
            ) + extra
            # Если запуск ПРОВАЛЕН — Критик должен дать корневую причину, а не
            # просто читать файлы. Это направляет Кодера на точечный фикс.
            if state.get("tests_passed") is False or "ПРОВАЛЕН" in tester_report:
                extra += (
                    f"\n=== ЗАДАЧА КРИТИКА: КОРНЕВАЯ ПРИЧИНА ===\n"
                    f"Проект НЕ запускается. Не пересказывай ошибку — найди ПРИЧИНУ.\n"
                    f"Ответь кратко и по делу в таком виде:\n"
                    f"ПРИЧИНА: <что именно сломано, одна фраза>\n"
                    f"ФАЙЛ: <какой файл чинить>\n"
                    f"ФИКС: <конкретное действие — какую строку/импорт исправить>\n"
                    f"Затем вердикт REJECTED (раз запуск падает).\n"
                    f"Не предлагай переписывать весь проект — только точечный фикс.\n"
                )
            elif "проверен только СТАРТ" in tester_report or "ЗАПУСК OK" in tester_report:
                # Smoke проверил только запуск (GUI). Критик ОБЯЗАН проверить
                # код игрового цикла на ошибки времени выполнения, которых
                # smoke не видит (несовпадение сигнатур update/draw, доступ к
                # неинициализированным полям и т.п.).
                extra += (
                    f"\n=== ВАЖНО: smoke проверил только СТАРТ, не игровой цикл ===\n"
                    f"Прочитай main.py и модули, которые он вызывает в цикле "
                    f"(update/draw/handle_events). Проверь ОСОБЕННО:\n"
                    f"• совпадают ли аргументы вызова с сигнатурой метода "
                    f"(напр. game.update() vs def update(self, dt) — не хватает dt)\n"
                    f"• не используются ли поля до инициализации\n"
                    f"• совпадают ли имена методов между файлами\n"
                    f"Если нашёл такое — REJECTED + ПРИЧИНА/ФАЙЛ/ФИКС. "
                    f"Если код цикла корректен — можешь одобрить.\n"
                )

        # Берём из state (загружено один раз в начале pipeline)
        agent_models = state.get("agent_models") or {}
        agent = create_agent("critic", ollama, tools, model_override=agent_models.get("critic"),
                             params=(state.get("agent_params") or {}).get("critic"))
        # Критик должен знать план Архитектора чтобы сравнить с тем что есть
        arch_plan = state.get("current_context", "")
        pname = state.get("project_name", "")
        critic_ctx = extra
        if arch_plan:
            critic_ctx = (
                f"[ПЛАН АРХИТЕКТОРА — что ДОЛЖНО быть в проекте]:\n{arch_plan[:2000]}\n\n"
                + (f"[ИМЯ ПРОЕКТА]: {pname}\n\n" if pname else "")
                + extra
            )
        run = await agent.run(
            user_msg=state["user_message"],
            history_text=state.get("history_text", ""),
            session_id=state["session_id"],
            extra_context=critic_ctx,
        )
        if run.needs_confirm():
            return _confirm_update(run, "multi_confirm")

        llm_approved = critic_is_approved(run.response)  # мнение LLM

        # ── ФАКТЫ ГЕЙТЯТ МНЕНИЕ LLM (совет из аудита) ─────────────────────
        # LLM может галлюцинировать APPROVED при неполном проекте. Поэтому
        # одобрение требует И мнения LLM, И программных фактов:
        #   - verifier_coverage >= 0.9 (почти все файлы из плана на месте)
        #   - tests_passed != False (реальный запуск не падал; None/True допустимо)
        # LLM по-прежнему может ЗАРУБИТЬ хороший по фактам проект за качество —
        # факты только не дают пропустить ПЛОХОЙ. Если фактов ещё нет
        # (первый раунд, verifier не отработал) — полагаемся на LLM как раньше.
        coverage = state.get("verifier_coverage")
        tests_passed = state.get("tests_passed")  # может быть None если тестер ещё не было

        approved = llm_approved
        gate_reason = ""
        if llm_approved and coverage is not None and coverage < 0.9:
            approved = False
            gate_reason = f"coverage {coverage*100:.0f}% < 90%"
        if llm_approved and tests_passed is False:
            approved = False
            gate_reason = (gate_reason + "; " if gate_reason else "") + "реальный запуск провалился"

        if llm_approved and not approved:
            logger.info(
                f"Критик: LLM сказал APPROVED, но факты заблокировали ({gate_reason}) "
                f"→ не одобрено, возврат к Кодеру"
            )

        return {
            "critic_approved": approved,
            "current_context": run.response if not approved else state.get("current_context", ""),
            "debate_round": debate_round + 1,
            "results": _append_result(
                state,
                run.to_agent_result_schema(
                    label=f"Критик — раунд {debate_round + 1}",
                    round_n=debate_round + 1,
                ),
            ),
            "pending_action_id": None,
        }
    return node


# ── tester ────────────────────────────────────────────────────────────────────

def make_tester_node(ollama: OllamaService, tools: ToolService):
    async def node(state: WorkflowState) -> dict:
        from app.graph.nodes.smoke_test import smoke_test
        from app.graph.nodes.verifier import resolve_project_dir

        # ── ПРОГРАММНЫЙ SMOKE-ТЕСТ (источник правды, не слова модели) ──────
        # Находим папку проекта на диске и реально ЗАПУСКАЕМ точку входа.
        pname = state.get("project_name", "")
        project_dir, _disk_files = resolve_project_dir(pname)

        smoke = None
        if project_dir:
            try:
                smoke = await smoke_test(project_dir)
                logger.info(
                    f"Tester smoke: passed={smoke.passed} entry={smoke.entry} "
                    f"crashed_fast={smoke.crashed_fast}"
                )
                # Логируем НАСТОЯЩИЙ traceback при падении — раньше его не было
                # видно в логе, приходилось гадать что именно сломано.
                if not smoke.passed and smoke.error_detail:
                    logger.error(
                        f"Tester smoke ОШИБКА запуска ({smoke.entry}):\n"
                        f"{smoke.error_detail[-1500:]}"
                    )
                # ── E2E: если СТАРТ прошёл — гоняем игровой цикл (ловит баги
                # рантайма цикла, которые smoke по таймауту не видит: update()
                # missing dt и т.п.). При падении цикла превращаем в smoke-fail.
                if smoke.passed and smoke.entry and not smoke.entry.startswith("("):
                    try:
                        from app.graph.nodes.e2e_test import e2e_test
                        entry_path = os.path.join(project_dir, smoke.entry)
                        agent_models_e2e = state.get("agent_models") or {}
                        # vision-модель: берём из настроек тестера если она vision-capable
                        vmodel = agent_models_e2e.get("tester")
                        if vmodel and not ollama.supports_vision(vmodel):
                            vmodel = None
                        e2e = await e2e_test(
                            project_dir, entry_path,
                            task=state.get("user_message", ""),
                            ollama=ollama, vision_model=vmodel,
                        )
                        logger.info(f"Tester E2E: passed={e2e.passed} level={e2e.level}")
                        if not e2e.passed:
                            logger.error(f"E2E ПРОВАЛ цикла:\n{e2e.error_detail[-1500:]}")
                            # НЕ crashed_fast: проект СТАРТОВАЛ и крутился, упал
                            # уже в игре. Помечаем gameplay_crash — иначе Кодеру
                            # уходит ложное «проект не запускается», и он лезет
                            # чинить main.py/старт вместо реального места падения.
                            smoke.passed = False
                            smoke.gameplay_crash = True
                            smoke.crashed_fast = False
                            smoke.error_detail = e2e.error_detail
                            smoke.summary = e2e.summary
                        else:
                            # Дополняем сводку результатом E2E (для критика/юзера)
                            smoke.summary = smoke.summary + "\n\n" + e2e.summary
                    except Exception as _e2e_err:
                        logger.warning(f"E2E пропущен (некритично): {_e2e_err}")
            except Exception as e:
                logger.warning(f"Tester smoke-test error: {e}")

        # tests_passed определяется ПРОГРАММНО по запуску, а не по тексту модели.
        # Если папку не нашли (нечего запускать) — не блокируем (универсальность:
        # сниппеты/ответы без проекта проходят), но и не помечаем passed ложно.
        if smoke is not None:
            tests_ok = smoke.passed
            smoke_summary = smoke.summary
        else:
            tests_ok = True  # нет проекта для запуска — не наша зона ответственности
            smoke_summary = "(нет папки проекта для запуска — smoke-тест пропущен)"

        test_round = state.get("test_round", 0)

        # Память фиксов: если проект ЗАРАБОТАЛ после раундов починки — запоминаем
        # КОНКРЕТНЫЙ рецепт по типу ошибки (не общую фразу). Опыт переносится
        # в будущие проекты. Если ошибка непонятна — память не пишется (пустая
        # память честнее мусорной).
        if smoke is not None and smoke.passed and test_round > 0:
            prev_err_text = state.get("last_error_text", "")
            if prev_err_text:
                try:
                    from app.memory.fix_memory import remember_fix
                    remember_fix(prev_err_text)  # рецепт строится внутри по типу
                except Exception:
                    pass

        max_test_rounds = settings.debate_max_rounds
        hard_fail = (
            smoke is not None
            and (smoke.crashed_fast or smoke.gameplay_crash)
            and not tests_ok
        )

        # Дешёвые детерминированные ошибки (забытый импорт, неопределённое имя)
        # чинятся одной строкой. Им даём БОЛЬШЕ попыток, чем логическим багам:
        # обидно упереться в лимит из-за забытого 'import sys' (случай из лога).
        _err_now = (smoke.error_detail or "") if smoke else ""
        _is_cheap = any(k in _err_now for k in (
            "NameError", "ImportError", "ModuleNotFoundError", "is not defined",
        ))
        effective_max = (max_test_rounds + 3) if _is_cheap else max_test_rounds

        # ── БЫСТРЫЙ ПУТЬ: smoke упал и есть раунды → СРАЗУ к Кодеру ────────
        # Не тратим дорогой LLM-проход Тестера на «осмотр» — у нас уже есть
        # программный traceback. Раньше Тестер читал файлы 60-90с впустую,
        # потом всё равно возвращал Кодеру. Теперь — сразу с трейсбэком.
        if hard_fail and test_round < effective_max:
            err = smoke.error_detail or ""
            err_tail = err[-1200:] if len(err) > 1200 else err
            import re as _re_err
            file_hint = ""
            m = _re_err.findall(r'File "([^"]+)", line (\d+)', err)
            # ── TRACEBACK ROUTER: какие файлы РЕАЛЬНО участвуют в ошибке ──────
            # Из traceback вытаскиваем все файлы проекта (не stdlib/site-packages).
            # Кодер должен трогать ТОЛЬКО их, а не читать board.py/scoring.py/...
            tb_files: list[str] = []
            for _fp, _ln in m:
                base = os.path.basename(_fp)
                # только файлы проекта (в пути есть имя проекта или Projects)
                if ("Projects" in _fp or (pname and pname in _fp)) and base not in tb_files:
                    tb_files.append(base)
            if m:
                fname, fline = m[-1]
                file_hint = f"\nМесто падения: {os.path.basename(fname)}, строка {fline}\n"
            router_hint = ""
            if tb_files:
                router_hint = (
                    f"\n📍 ФАЙЛЫ В ОШИБКЕ (трогай ТОЛЬКО их): {', '.join(tb_files)}\n"
                    f"НЕ читай и НЕ открывай другие файлы проекта — причина в этих.\n"
                )

            # ── Конкретная подсказка по ТИПУ ошибки (универсально для Python) ──
            # Модель часто видит traceback, но не понимает КАК чинить. Даём
            # точную стратегию под распространённые ошибки.
            specific = ""
            # ImportError: cannot import name 'X' from 'module'
            mi = _re_err.search(r"cannot import name '(\w+)' from '([\w\.]+)'", err)
            if mi:
                missing_name, from_mod = mi.group(1), mi.group(2)
                mod_file = from_mod.split(".")[-1] + ".py"
                specific = (
                    f"\n🎯 ТИП: ImportError — имя '{missing_name}' не найдено в модуле {from_mod}.\n"
                    f"ДВА варианта фикса (выбери правильный, посмотрев оба файла):\n"
                    f"  A) Если '{missing_name}' ДОЛЖНО быть в {mod_file} — открой {mod_file} "
                    f"и проверь, как реально называется класс/функция/переменная "
                    f"(возможно опечатка или другое имя), затем поправь ИМПОРТ под него.\n"
                    f"  B) Если импорт лишний — убери '{missing_name}' из строки import.\n"
                    f"Сначала read_file({mod_file}) и посмотри что там реально определено, "
                    f"ПОТОМ правь импорт через str_replace.\n"
                )
            else:
                mn = _re_err.search(r"name '(\w+)' is not defined", err)
                mmod = _re_err.search(r"No module named '([\w\.]+)'", err)
                ma = _re_err.search(r"module '[\w\.]+' has no attribute '(\w+)'", err)
                if mmod:
                    _missing_mod = mmod.group(1)
                    _root = _missing_mod.split(".")[0].lower()
                    _known_pkgs = {
                        "pygame", "numpy", "pandas", "requests", "flask", "django",
                        "fastapi", "pillow", "pil", "scipy", "matplotlib", "torch",
                        "tensorflow", "cv2", "opencv", "pydantic", "sqlalchemy",
                        "aiohttp", "httpx", "redis", "pytest", "selenium", "bs4",
                    }
                    if _root in _known_pkgs:
                        # Сторонний пакет — это установка, НЕ правка кода
                        specific = (
                            f"\n🎯 ТИП: ModuleNotFoundError — СТОРОННИЙ пакет "
                            f"'{_missing_mod}' не установлен.\n"
                            f"ЭТО НЕ ОШИБКА КОДА. Установи пакет: "
                            f"pip_install(package=\"{_root}\").\n"
                            f"НЕ правь код, НЕ трогай импорты — они верные. "
                            f"Просто установи пакет и проект запустится.\n"
                        )
                    else:
                        specific = (
                            f"\n🎯 ТИП: ModuleNotFoundError — модуль '{_missing_mod}' "
                            f"не найден. Это ВНУТРЕННИЙ модуль проекта.\n"
                            f"Проверь путь импорта: если файл в папке (core/, ui/), "
                            f"импортируй 'from core.{_missing_mod} import ...'. "
                            f"Или проверь опечатку в имени.\n"
                        )
                elif mn:
                    specific = (
                        f"\n🎯 ТИП: NameError — '{mn.group(1)}' используется, но не определён/не импортирован.\n"
                        f"Это правится ДОБАВЛЕНИЕМ одной строки — используй str_replace:\n"
                        f"найди существующую строку рядом с местом ошибки и добавь перед/после "
                        f"неё определение (напр. для цвета: {mn.group(1)} = (0, 0, 0)) "
                        f"или импорт. НЕ переписывай весь файл через write_file ради одной строки.\n"
                    )
                elif ma:
                    specific = (
                        f"\n🎯 ТИП: AttributeError — атрибут '{ma.group(1)}' отсутствует.\n"
                        f"Проверь точное имя метода/поля в исходном классе.\n"
                    )
                elif "SyntaxError" in err or "IndentationError" in err:
                    specific = (
                        f"\n🎯 ТИП: SyntaxError/IndentationError — синтаксис в файле падения.\n"
                        f"Открой строку из 'Место падения' и поправь синтаксис/отступ.\n"
                    )

            # ── ERROR MEMORY: если та же ОШИБКА повторяется — усиливаем подсказку ──
            # Сигнатура = тип ошибки + последняя строка (без путей/чисел).
            err_last_line = ""
            for _l in reversed(err.strip().splitlines()):
                if _l.strip() and not _l.strip().startswith("File "):
                    err_last_line = _l.strip()
                    break
            # Тип ошибки (TypeError/NameError/...) + имя класса/функции если есть
            _etype = err_last_line.split(":")[0] if ":" in err_last_line else err_last_line
            _ename_m = _re_err.search(r"(\w+)\.__init__|name '(\w+)'|import name '(\w+)'", err_last_line)
            _ename = next((g for g in (_ename_m.groups() if _ename_m else []) if g), "")
            error_sig = f"{_etype}"
            prev_sig = state.get("last_error_sig", "")
            recurring_hint = ""
            if prev_sig and prev_sig == error_sig and _etype:
                recurring_hint = (
                    f"\n⚠️ ПОВТОРНАЯ ОШИБКА ТИПА {_etype}! Прошлый фикс породил такую же.\n"
                    f"Это значит однотипная проблема в нескольких местах (напр. "
                    f"несколько классов с одинаковой ошибкой сигнатуры в одном файле).\n"
                    f"Найди и исправь ВСЕ такие случаи за один проход, а не по одному.\n"
                )

            # Память удачных фиксов: если такую ошибку уже чинили — подсказываем.
            try:
                from app.memory.fix_memory import recall_fix
                memory_hint = recall_fix(err)
            except Exception:
                memory_hint = ""

            _is_gameplay = bool(smoke and getattr(smoke, "gameplay_crash", False))
            if _is_gameplay:
                _header = (
                    f"⚠️ Проект ЗАПУСКАЕТСЯ и доходит до основного цикла работы, "
                    f"но ПАДАЕТ во время выполнения (runtime, реальный E2E-прогон "
                    f"{smoke.entry}). Стартовый код и точка входа РАБОТАЮТ — НЕ трогай "
                    f"main.py/инициализацию. Ошибка:\n\n"
                )
                _read_rule = (
                    f"1. read_file ТОЛЬКО файла из 'Место падения' (1 чтение). "
                    f"Если строка попала в пропущенную середину — перечитай файл "
                    f"и укажи номер строки.\n"
                )
            else:
                _header = (
                    f"❌ Проект НЕ запускается — реальный запуск ({smoke.entry}) дал ошибку:\n\n"
                )
                _read_rule = "1. read_file ТОЛЬКО файлов из списка выше (максимум 2 чтения)\n"
            fix_ctx = (
                f"{_header}"
                f"{err_tail or '(stderr пуст — проверь импорты и точку входа)'}\n"
                f"{file_hint}"
                f"{router_hint}"
                f"{recurring_hint}"
                f"{memory_hint}"
                f"{specific}\n"
                f"ПОРЯДОК ДЕЙСТВИЙ (быстро, без блужданий):\n"
                f"{_read_rule}"
                f"2. найди точную причину (несовпадение имён/сигнатур — частый случай)\n"
                f"3. если та же ошибка в нескольких местах ОДНОГО файла — почини ВСЕ сразу\n"
                f"4. почини через str_replace ОДНОЙ точечной правкой; write_file "
                f"для полного перезаписа — только если str_replace не находит строку. "
                f"НЕ вводи новых имён, которых нет в файле — используй только "
                f"существующие поля, аргументы и импорты, иначе будет новая ошибка.\n"
                f"5. НЕ читай другие файлы, НЕ создавай новые, НЕ пиши проект заново.\n"
                f"После фикса проект запустят снова автоматически."
            )
            logger.warning(
                f"Tester GATE (быстрый путь): smoke FAILED → сразу к Кодеру "
                f"(раунд {test_round + 1}/{effective_max}), traceback передан"
            )
            # Включаем режим починки — regression guard смягчается, чтобы точечный
            # фикс мог переписать файл (но не выпотрошить его полностью).
            from app.core.active_project import set_fix_mode
            set_fix_mode(True)
            return {
                "results": _append_result(
                    state,
                    AgentResultSchema(
                        agent="tester",
                        label=f"Тестер — запуск провален (раунд {test_round + 1})",
                        response=smoke_summary,
                        type="error",
                    ),
                ),
                "current_context": fix_ctx,
                "tests_passed": False,
                "tester_report": smoke_summary,
                "test_round": test_round + 1,
                "last_error_sig": error_sig,
                "last_error_text": (err or "")[-600:],
                "critic_approved": False,
                "pending_action_id": None,
                "next_node": "coder",
            }

        # ── LLM-тестер: подробный разбор (только когда smoke прошёл или
        #    раунды исчерпаны — тут LLM добавляет ценность, а не тратит время) ──
        extra = (
            f"\n\n=== РЕЗУЛЬТАТ РЕАЛЬНОГО ЗАПУСКА (программный smoke-тест) ===\n"
            f"{smoke_summary}\n\n"
            f"Это ФАКТ — проект реально запущен на Python, не твоё мнение.\n"
        )
        if smoke is not None and not smoke.passed:
            extra += (
                f"\nПроект НЕ работает после {test_round} раундов починки. "
                f"Кратко перечисли что осталось сломано.\n"
            )
        else:
            extra += (
                f"\nПроект запускается. Если видишь явные пробелы в функционале "
                f"из ТЗ — отметь их кратко. Иначе подтверди готовность.\n"
            )

        # Берём из state (загружено один раз в начале pipeline)
        agent_models = state.get("agent_models") or {}
        agent = create_agent("tester", ollama, tools, model_override=agent_models.get("tester"),
                             params=(state.get("agent_params") or {}).get("tester"))
        run = await agent.run(
            user_msg=state["user_message"],
            history_text=state.get("history_text", ""),
            session_id=state["session_id"],
            extra_context=extra,
        )
        if run.needs_confirm():
            return _confirm_update(run, "multi_confirm")

        # ── Гард: Тестер без ЕДИНОГО запуска = осмотр, а не тестирование ────
        # (лог: list_files упал → тестер написал 5000 символов ТЕКСТА и вышел;
        # AttributeError при нажатии клавиши ушёл пользователю).
        _run_tools = {"run_python", "run_code", "run_script"}
        _used = {st.tool for st in (run.steps or [])}
        if not (_run_tools & _used):
            logger.warning(f"Tester: НИ ОДНОГО запуска (tools={_used or '∅'}) — "
                           f"принудительный повтор")
            run = await agent.run(
                user_msg=state["user_message"],
                history_text=state.get("history_text", ""),
                session_id=state["session_id"],
                extra_context=(
                    "⛔ ТЫ НЕ ЗАПУСТИЛ НИ ОДНОГО ТЕСТА. Чтение кода — не "
                    "тестирование. ПРЯМО СЕЙЧАС: напиши динамический тест "
                    "(гравитация: 30 тиков → позиция изменилась; управление: "
                    "handle_action → координата изменилась) и запусти его "
                    "run_python с project_dir. Без mainloop!\n\n" + extra
                ),
            )
            if run.needs_confirm():
                return _confirm_update(run, "multi_confirm")
            _used2 = {st.tool for st in (run.steps or [])}
            if not (_run_tools & _used2):
                run.response = ("⚠️ ТЕСТЕР НЕ ВЫПОЛНИЛ НИ ОДНОГО ЗАПУСКА — отчёт "
                                "ниже является только чтением кода, поведение "
                                "НЕ проверено.\n\n") + (run.response or "")

        # Итоговый отчёт тестера = факт запуска + разбор модели
        tester_report = f"{smoke_summary}\n\n{run.response[:1500]}"

        if hard_fail:
            # Раунды исчерпаны, проект всё ещё падает — честно помечаем и идём
            # дальше (save сообщит пользователю про неудачу запуска).
            logger.warning(
                f"Tester GATE: smoke всё ещё FAILED после {test_round} раундов — "
                f"передаём дальше с пометкой неудачи."
            )


        return {
            "results": _append_result(
                state,
                AgentResultSchema(
                    agent="tester",
                    label="Тестер — реальный запуск",
                    response=tester_report,
                    type="success" if tests_ok else "error",
                ),
            ),
            "current_context": tester_report,
            "tests_passed": tests_ok,
            "tester_report": smoke_summary,
            # Полный traceback (не только summary) — Критик получает реальную ошибку,
            # не сокращённую. Без этого Критик угадывал причину из 700 символов.
            "last_error_text": (
                (smoke.error_detail or "")[-2000:] if smoke and not smoke.passed else ""
            ),
            "pending_action_id": None,
            "next_node": "human_approval",
        }
    return node


# ── human_approval ────────────────────────────────────────────────────────────