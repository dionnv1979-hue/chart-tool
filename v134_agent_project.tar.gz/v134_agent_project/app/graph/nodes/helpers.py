"""Nodes package — узлы LangGraph workflow."""
import hashlib
import json
import os
import re
import time

from app.agents.base import BaseAgent
from app.agents.prompts import AGENTS
from app.agents.registry import create_agent, critic_is_approved
from app.core.logger import get_logger
from app.core.workspace import promote, list_staging_projects
from app.graph.state import WorkflowState
from app.schemas.chat import AgentResultSchema, ToolStepSchema
from app.schemas.tool import SaveProjectParams
from app.services.ollama_service import OllamaService
from app.services.tool_service import ToolService

logger = get_logger(__name__)


async def _load_agent_models() -> dict[str, str]:
    """
    Загружает override моделей из Settings БД одним запросом.
    Возвращает {agent_key: model_name} только для тех агентов у которых
    есть override в БД. Остальные используют дефолт из AgentConfig.
    """
    try:
        from app.memory.database import get_session_factory
        from app.memory.repository import SettingRepository
        from app.agents.prompts import AGENTS
        async with get_session_factory()() as db:
            repo = SettingRepository(db)
            # Загружаем все setting значения одним вызовом get_all()
            # вместо N отдельных запросов
            all_settings = await repo.get_all()
            overrides = {}
            for key in AGENTS:
                setting_key = f"agent_model:{key}"
                if setting_key in all_settings and all_settings[setting_key]:
                    overrides[key] = all_settings[setting_key]
            return overrides
    except Exception as e:
        logger.warning(f"Could not load agent model overrides: {e}")
        return {}


async def _load_agent_params() -> dict:
    """
    Переопределения параметров агентов из Settings UI.
    Ключи в БД: agent_temp:<key>, agent_npredict:<key>, agent_steps:<key>.
    Возвращает {agent_key: {"temperature": float, "num_predict": int,
    "max_steps": int}} — только заданные поля. Невалидные значения скипаются.
    """
    try:
        from app.memory.database import get_session_factory
        from app.memory.repository import SettingRepository
        from app.agents.prompts import AGENTS
        async with get_session_factory()() as db:
            repo = SettingRepository(db)
            all_settings = await repo.get_all()
            out: dict[str, dict] = {}
            for key in AGENTS:
                p: dict = {}
                v = all_settings.get(f"agent_temp:{key}")
                if v:
                    try:
                        t = float(v)
                        if 0.0 <= t <= 2.0:
                            p["temperature"] = t
                    except ValueError:
                        pass
                v = all_settings.get(f"agent_npredict:{key}")
                if v:
                    try:
                        n = int(v)
                        if 256 <= n <= 65536:
                            p["num_predict"] = n
                    except ValueError:
                        pass
                v = all_settings.get(f"agent_steps:{key}")
                if v:
                    try:
                        s = int(v)
                        if 1 <= s <= 50:
                            p["max_steps"] = s
                    except ValueError:
                        pass
                if p:
                    out[key] = p
            return out
    except Exception as e:
        logger.warning(f"Could not load agent params: {e}")
        return {}


def _append_result(state: WorkflowState, result: AgentResultSchema) -> list:
    return list(state.get("results", [])) + [result]


# ── single_agent ──────────────────────────────────────────────────────────────