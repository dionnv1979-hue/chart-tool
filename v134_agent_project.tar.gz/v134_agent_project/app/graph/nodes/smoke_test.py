"""
Программный smoke-тест проекта (#tester).

Проблема (из лога): Тестер ЧИТАЛ файлы вместо ЗАПУСКА, а tests_passed
определялся по слову "passed" в ответе модели. Проект сохранялся даже при
тесты=False. Дыра: «файлы есть» ≠ «программа работает».

Решение: программно (без LLM) запускаем точку входа проекта и/или импортируем
каждый модуль. Реальный returncode / исключение → реальный вердикт.

Универсально под любые проекты:
  - находит точку входа (main.py / app.py / __main__ / run.py / первый файл
    с `if __name__ == "__main__"`);
  - GUI/сервер (pygame, tkinter, flask, while True) держат процесс → TIMEOUT
    трактуется как УСПЕХ (запустилось без падения на старте);
  - быстрое падение с ненулевым кодом (ImportError, SyntaxError) → FAIL;
  - если точки входа нет — проверяем импортируемость всех модулей.

Возвращает структурированный вердикт, который save-гейт использует для решения.
"""
from __future__ import annotations

import asyncio
import os
import subprocess
import sys
from dataclasses import dataclass

from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)

# Имена-кандидаты для точки входа, по приоритету
_ENTRY_CANDIDATES = ("main.py", "app.py", "run.py", "__main__.py", "start.py", "game.py")
# Кандидаты других языков: (имя, kind). kind определяет команду запуска.
_ENTRY_CANDIDATES_ML = (
    ("main.js", "js"), ("index.js", "js"), ("app.js", "js"), ("server.js", "js"),
    ("main.mjs", "js"), ("main.go", "go"), ("index.html", "html"),
)

# Сколько ждём запуска. GUI/сервер дольше этого → считаем что стартовало.
_SMOKE_TIMEOUT = 20


@dataclass
class SmokeResult:
    """Результат smoke-теста."""

    passed: bool
    entry: str               # что запускали (или '' если импорт-чек)
    summary: str             # человекочитаемый вердикт для контекста
    crashed_fast: bool = False  # быстрое падение на СТАРТЕ (точно сломано)
    gameplay_crash: bool = False  # стартовал и работал, упал в runtime-цикле (E2E)
    error_detail: str = ""   # stderr/traceback при падении


def _find_entry(project_dir: str) -> str | None:
    """Находим точку входа проекта (обратная совместимость: только путь)."""
    path, _ = _find_entry_ex(project_dir)
    return path


def _find_entry_ex(project_dir: str) -> tuple[str | None, str]:
    """
    Мультиязычный поиск точки входа: (путь, kind).
    kind: 'py' | 'js' | 'go' | 'html' | ''. Приоритет — Python (исторически
    основной), затем JS/Go/HTML. package.json с полем main тоже понимаем.
    """
    if not os.path.isdir(project_dir):
        return None, ""
    listing = os.listdir(project_dir)
    names = {f.lower(): f for f in listing if f.endswith(".py")}
    # 1) Python по приоритетному списку имён
    for cand in _ENTRY_CANDIDATES:
        if cand in names:
            return os.path.join(project_dir, names[cand]), "py"
    # 2) первый .py с блоком запуска __main__
    for fname in names.values():
        try:
            with open(os.path.join(project_dir, fname), encoding="utf-8", errors="replace") as f:
                if "__main__" in f.read():
                    return os.path.join(project_dir, fname), "py"
        except OSError:
            continue
    # 3) Другие языки по списку кандидатов
    lower_all = {f.lower(): f for f in listing}
    for cand, kind in _ENTRY_CANDIDATES_ML:
        if cand in lower_all:
            return os.path.join(project_dir, lower_all[cand]), kind
    # 4) package.json → поле main
    if "package.json" in lower_all:
        try:
            import json as _json
            with open(os.path.join(project_dir, lower_all["package.json"]),
                      encoding="utf-8") as f:
                main = (_json.load(f).get("main") or "").strip()
            if main and os.path.isfile(os.path.join(project_dir, main)):
                return os.path.join(project_dir, main), "js"
        except Exception:
            pass
    return None, ""


def _list_modules(project_dir: str) -> list[str]:
    """Все .py модули проекта (для импорт-чека если нет точки входа)."""
    mods = []
    for fname in os.listdir(project_dir):
        if fname.endswith(".py") and fname != "__init__.py":
            mods.append(fname[:-3])
    return mods


async def _run(cmd: list[str], cwd: str, timeout: int) -> tuple[int | None, str, str]:
    """Запуск подпроцесса. returncode=None означает timeout (процесс жив)."""
    loop = asyncio.get_running_loop()
    try:
        result = await loop.run_in_executor(
            None,
            lambda: subprocess.run(
                cmd, capture_output=True, text=True, timeout=timeout, cwd=cwd
            ),
        )
        # stderr: держим ХВОСТ (там тип ошибки/файл/строка у Python), не начало.
        _err = result.stderr or ""
        return (result.returncode, (result.stdout or "")[:2000],
                _err[-8000:] if len(_err) > 8000 else _err)
    except subprocess.TimeoutExpired as e:
        # Процесс работал дольше timeout → жив (GUI/сервер/loop)
        out = (e.stdout or b"")
        err = (e.stderr or b"")
        if isinstance(out, bytes):
            out = out.decode("utf-8", "replace")
        if isinstance(err, bytes):
            err = err.decode("utf-8", "replace")
        return None, out[:2000], (err[-8000:] if len(err) > 8000 else err)


async def _augment_with_pyflakes(project_dir: str, error_detail: str) -> str:
    """
    При NameError/ImportError: smoke видит только ПЕРВУЮ ошибку (программа
    падает на ней), а их обычно МНОГО (забыты импорты констант во всех файлах).
    pyflakes статически находит ВСЕ undefined names за раз → Кодер чинит
    одним раундом вместо шести. Нет pyflakes — молча пропуск.
    """
    # ── AttributeError-помощник: 'X' object has no attribute 'y' →
    # найдём класс X в проекте, перечислим РЕАЛЬНЫЕ методы и ближайший
    # по имени (кейс: game_engine звал board.is_collision, в Board был
    # check_collision — рассинхрон API после частичного переписывания).
    import re as _re_attr
    am = _re_attr.search(r"AttributeError: '(\w+)' object has no attribute '(\w+)'",
                         error_detail)
    if am:
        _cls, _attr = am.group(1), am.group(2)
        try:
            import ast as _ast_h, difflib as _dl
            for _fn in sorted(os.listdir(project_dir)):
                if not _fn.endswith(".py"):
                    continue
                _src = open(os.path.join(project_dir, _fn),
                            encoding="utf-8", errors="ignore").read()
                if f"class {_cls}" not in _src:
                    continue
                _tree = _ast_h.parse(_src)
                for _nd in _ast_h.walk(_tree):
                    if isinstance(_nd, _ast_h.ClassDef) and _nd.name == _cls:
                        _methods = sorted({m.name for m in _nd.body
                                           if isinstance(m, (_ast_h.FunctionDef,
                                                             _ast_h.AsyncFunctionDef))})
                        _close = _dl.get_close_matches(_attr, _methods, n=2, cutoff=0.5)
                        error_detail += (
                            f"\n\n=== ПОДСКАЗКА ПО API (программно) ===\n"
                            f"Класс {_cls} ({_fn}) НЕ имеет '{_attr}'. "
                            f"Реальные методы: {', '.join(_methods[:15])}\n"
                            + (f"Ближайшее по имени: {', '.join(_close)} — "
                               f"вероятно нужно вызывать его, ИЛИ добавить "
                               f"метод '{_attr}' в класс {_cls}.\n" if _close else "")
                            + f"Согласуй API между файлом-вызовом и {_fn}."
                        )
                        break
                break
        except Exception:
            pass

    if not ("NameError" in error_detail or "ImportError" in error_detail
            or "ModuleNotFoundError" in error_detail):
        return error_detail
    # ── Детект затенения stdlib: "partially initialized module 'X'" + X.py
    # в проекте + X ∈ stdlib → точный рецепт (Кодер сам этот класс не решает:
    # нужно ПЕРЕИМЕНОВАНИЕ, кейс types.py съел 6 раундов).
    import re as _re
    m = _re.search(r"partially initialized module '(\w+)'", error_detail)
    if m:
        _mod = m.group(1)
        if (_mod in sys.stdlib_module_names
                and os.path.isfile(os.path.join(project_dir, f"{_mod}.py"))):
            error_detail += (
                f"\n\n=== КОРЕНЬ ПРОБЛЕМЫ (определено программно) ===\n"
                f"Файл проекта '{_mod}.py' ЗАТЕНЯЕТ стандартный модуль Python "
                f"'{_mod}' — все библиотеки получают твой файл вместо системного.\n"
                f"РЕШЕНИЕ (строго в этом порядке):\n"
                f"1. rename_file({{path: \"{_mod}.py\", new_name: \"game_{_mod}.py\"}})\n"
                f"2. grep_files({{pattern: \"{_mod}\"}}) — найди все импорты\n"
                f"3. str_replace в каждом файле: 'from {_mod} import' → "
                f"'from game_{_mod} import', 'import {_mod}' → 'import game_{_mod}'\n"
                f"Правка импортов ВНУТРИ {_mod}.py не поможет — нужно именно "
                f"переименование."
            )
    try:
        py_files = [os.path.join(project_dir, f) for f in sorted(os.listdir(project_dir))
                    if f.endswith(".py")][:20]
        if not py_files:
            return error_detail
        rc, stdout, stderr = await _run(
            [sys.executable, "-m", "pyflakes"] + py_files, project_dir, 20,
        )
        out = (stdout or "") + (stderr or "")
        if "No module named" in out:
            return error_detail  # pyflakes не установлен — пропуск
        undefined = []
        for line in out.splitlines():
            if "undefined name" in line:
                short = line.replace(project_dir, "").lstrip("\\/")
                undefined.append(short.strip())
        if not undefined:
            return error_detail
        listing = "\n".join(undefined[:40])
        more = f"\n… и ещё {len(undefined) - 40}" if len(undefined) > 40 else ""
        return (
            f"{error_detail}\n\n"
            f"=== ПОЛНЫЙ СПИСОК неопределённых имён (pyflakes, ВСЕ файлы) ===\n"
            f"{listing}{more}\n"
            f"ПОЧИНИ ВСЕ ЗА ЭТОТ РАУНД: добавь недостающие импорты в КАЖДЫЙ "
            f"файл из списка (обычно from config import ...). Не чини по одному."
        )
    except Exception:
        return error_detail


async def _run_project_tests(project_dir: str) -> "SmokeResult | None":
    """
    Regression-дисциплина Claude Code: существующие тесты проекта
    (tests.py, test_*.py, tests/) запускаются КАЖДЫЙ прогон. Багфикс,
    ломающий старое поведение, ловится здесь, а не у пользователя.
    Возврат: None = тестов нет или все зелёные; SmokeResult = провал.
    """
    test_files = []
    try:
        for fn in sorted(os.listdir(project_dir)):
            low = fn.lower()
            if low == "tests.py" or (low.startswith("test_") and low.endswith(".py")):
                test_files.append(fn)
        tests_dir = os.path.join(project_dir, "tests")
        if os.path.isdir(tests_dir):
            for fn in sorted(os.listdir(tests_dir)):
                if fn.lower().endswith(".py") and fn != "__init__.py":
                    test_files.append(os.path.join("tests", fn))
    except OSError:
        return None
    if not test_files:
        return None

    failures = []
    for tf in test_files[:6]:  # лимит на случай мусора
        rc, stdout, stderr = await _run(
            [sys.executable, tf], project_dir, 30,
        )
        out = (stderr or "") + (stdout or "")
        if rc is None:
            failures.append(f"{tf}: TIMEOUT 30с (тест запускает GUI/mainloop? "
                            f"Тесты обязаны быть headless)")
        elif rc != 0:
            failures.append(f"{tf} (код {rc}):\n{out[-500:]}")
    if not failures:
        logger.info(f"Regression: {len(test_files)} тест-файлов зелёные")
        return None
    detail = "\n\n".join(failures)
    return SmokeResult(
        passed=False,
        entry="",
        crashed_fast=True,  # гейтится сразу к Кодеру с трейсбэком
        error_detail=detail,
        summary=(
            f"❌ РЕГРЕССИЯ: существующие тесты проекта падают "
            f"({len(failures)} из {len(test_files)} файлов).\n"
            f"Твои изменения сломали проверенное поведение:\n{detail[-800:]}"
        ),
    )


def _has_gui_markers(project_dir: str) -> bool:
    """Есть ли в исходниках признаки GUI (tkinter/pygame/arcade/pyglet).
    Нужно для детекции 'окно мелькнуло и закрылось': GUI-программа,
    завершившаяся мгновенно с rc=0 — это дефект, а не успех."""
    try:
        for fn in os.listdir(project_dir):
            if not fn.endswith(".py"):
                continue
            try:
                with open(os.path.join(project_dir, fn),
                          encoding="utf-8", errors="ignore") as f:
                    head = f.read(4000)
                if ("import tkinter" in head or "from tkinter" in head
                        or "import pygame" in head or "import arcade" in head
                        or "import pyglet" in head):
                    return True
            except OSError:
                continue
    except OSError:
        pass
    return False


async def smoke_test(project_dir: str) -> SmokeResult:
    """
    Запустить программный smoke-тест проекта.

    Логика вердикта:
      - Точка входа упала быстро с кодом != 0 → FAIL (crashed_fast=True)
      - Точка входа работает дольше timeout (GUI/сервер) → PASS (запустилось)
      - Точка входа завершилась с кодом 0 → PASS
      - Нет точки входа → импорт-чек всех модулей: любой ImportError/SyntaxError → FAIL
    """
    project_dir = os.path.realpath(project_dir)
    if not os.path.isdir(project_dir):
        return SmokeResult(False, "", f"Папка проекта не найдена: {project_dir}")

    entry, entry_kind = _find_entry_ex(project_dir)

    if entry:
        rel = os.path.basename(entry)
        # ── Команда запуска по языку ────────────────────────────────────────
        if entry_kind == "html":
            # Статика: процесс не нужен. Проверен факт наличия index.html.
            return SmokeResult(
                passed=True, entry=rel,
                summary=(f"✅ Статический проект: `{rel}` найден. "
                         f"Запуск процесса не требуется — открой в браузере."),
            )
        if entry_kind == "js":
            import shutil as _sh
            node = _sh.which("node")
            if not node:
                return SmokeResult(
                    passed=True, entry=rel,
                    summary=(f"⚠️ Entry `{rel}` (JavaScript), но node не установлен — "
                             f"smoke-запуск ПРОПУЩЕН. Установи Node.js для полной проверки."),
                )
            cmd = [node, entry]
        elif entry_kind == "go":
            import shutil as _sh
            gobin = _sh.which("go")
            if not gobin:
                return SmokeResult(
                    passed=True, entry=rel,
                    summary=(f"⚠️ Entry `{rel}` (Go), но go не установлен — "
                             f"smoke-запуск ПРОПУЩЕН."),
                )
            cmd = [gobin, "run", entry]
        else:
            cmd = [sys.executable, entry]
        import time as _time
        _t0 = _time.time()
        rc, stdout, stderr = await _run(cmd, project_dir, _SMOKE_TIMEOUT)
        _elapsed = _time.time() - _t0

        if rc is None:
            # Процесс жив дольше timeout — GUI/сервер/loop запустился.
            # НО: проверяем stderr — программа могла выбросить traceback в фоне
            # (поток упал, окно осталось). Если есть traceback — это FAIL.
            if stderr and ("Traceback (most recent call last)" in stderr
                           or "Error:" in stderr):
                detail_tail = stderr[-700:] if len(stderr) > 700 else stderr
                _aug = await _augment_with_pyflakes(project_dir, stderr)
                return SmokeResult(
                    passed=False,
                    entry=rel,
                    crashed_fast=True,
                    error_detail=_aug,
                    summary=(
                        f"❌ ТЕСТ ПРОВАЛЕН: `{rel}` запустился, но выбросил ошибку:\n"
                        f"{detail_tail}"
                    ),
                )
            _reg = await _run_project_tests(project_dir)
            if _reg is not None:
                return _reg
            return SmokeResult(
                passed=True,
                entry=rel,
                summary=(
                    f"✅ ЗАПУСК OK: `{rel}` стартовал без падения (>{_SMOKE_TIMEOUT}с, "
                    f"GUI/сервер/loop).\n"
                    f"⚠️ ВНИМАНИЕ: проверен только СТАРТ. Интерактив (нажатия клавиш, "
                    f"игровой цикл после старта) НЕ протестирован — там могут быть "
                    f"ошибки времени выполнения (напр. неверные аргументы в update/draw)."
                ),
            )
        if rc == 0:
            # GUI-программа, завершившаяся мгновенно — это "окно мелькнуло
            # и закрылось": mainloop/игровой цикл не удержал управление
            # (sys.exit/return до старта цикла, или цикл вовсе не вызван).
            if _elapsed < 3.0 and entry_kind == "py" and _has_gui_markers(project_dir):
                return SmokeResult(
                    passed=False,
                    entry=rel,
                    crashed_fast=True,
                    error_detail=(
                        f"GUI-приложение завершилось за {_elapsed:.1f}с с кодом 0 — "
                        f"окно закрылось сразу после старта. Игровой цикл "
                        f"(mainloop/while running) не запущен или завершается "
                        f"мгновенно. stdout: {stdout[-400:]}"
                    ),
                    summary=(
                        f"❌ ДЕФЕКТ: `{rel}` (GUI) завершился за {_elapsed:.1f}с — "
                        f"окно мелькнуло и закрылось.\n"
                        f"Проверь: mainloop()/игровой цикл вызывается В КОНЦЕ main, "
                        f"ни один модуль не вызывает sys.exit() до него, "
                        f"и нет return перед стартом цикла."
                    ),
                )
            _reg = await _run_project_tests(project_dir)
            if _reg is not None:
                return _reg
            return SmokeResult(
                passed=True,
                entry=rel,
                summary=f"✅ ТЕСТ ПРОЙДЕН: `{rel}` завершился успешно (код 0).\n{stdout[:300]}",
            )
        # Ненулевой код — реальное падение
        detail = stderr or stdout or "(нет вывода)"
        # В summary показываем КОНЕЦ трейсбэка — там тип ошибки, файл и строка
        # (у Python суть в конце, не в начале).
        detail_tail = detail[-700:] if len(detail) > 700 else detail
        detail = await _augment_with_pyflakes(project_dir, detail)
        return SmokeResult(
            passed=False,
            entry=rel,
            crashed_fast=True,
            error_detail=detail,
            summary=(
                f"❌ ТЕСТ ПРОВАЛЕН: `{rel}` упал с кодом {rc}.\n"
                f"Ошибка (конец трейсбэка):\n{detail_tail}"
            ),
        )

    # ── Нет точки входа → проверяем импортируемость каждого модуля ──
    modules = _list_modules(project_dir)
    if not modules:
        # Не Python-проект (JS без main, статика, конфиги)? Не валим в repair —
        # есть ли вообще файлы кода/разметки:
        try:
            _other = [f for f in os.listdir(project_dir)
                      if f.lower().endswith((".js", ".mjs", ".html", ".css",
                                             ".go", ".rs", ".java", ".ts"))]
        except OSError:
            _other = []
        if _other:
            return SmokeResult(
                passed=True, entry="",
                summary=(f"⚠️ Точка входа не определена (не-Python проект: "
                         f"{', '.join(_other[:5])}). Smoke-запуск пропущен — "
                         f"проверь вручную."),
            )
        return SmokeResult(False, "", "❌ В проекте нет файлов кода для запуска.")

    failed = []
    for mod in modules:
        # python -c "import mod" с cwd=project_dir
        rc, _out, err = await _run(
            [sys.executable, "-c", f"import {mod}"], project_dir, 10
        )
        if rc not in (0, None):
            # Берём последнюю строку трейсбэка — суть ошибки
            last = err.strip().splitlines()[-1] if err.strip() else f"код {rc}"
            failed.append(f"{mod}: {last}")

    if failed:
        return SmokeResult(
            passed=False,
            entry="(import-check)",
            crashed_fast=True,
            error_detail="\n".join(failed),
            summary=(
                "❌ ТЕСТ ПРОВАЛЕН: модули не импортируются:\n"
                + "\n".join(f"  • {f}" for f in failed[:8])
            ),
        )

    return SmokeResult(
        passed=True,
        entry="(import-check)",
        summary=f"✅ ТЕСТ ПРОЙДЕН: все {len(modules)} модулей импортируются без ошибок.",
    )


__all__ = ["smoke_test", "SmokeResult"]
