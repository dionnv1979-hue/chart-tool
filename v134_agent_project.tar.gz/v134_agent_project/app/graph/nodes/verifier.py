"""
Verifier — программная проверка факта между Кодером и Критиком.

НЕ использует LLM. Только os.walk + regex.

Алгоритм:
  1. Парсим план Архитектора → required_files (список имён файлов)
  2. Сканируем Projects/ и staging/ → found_files (реальные файлы на диске)
  3. Также смотрим current_code (ответ Кодера) → in_memory_files
  4. Строим факт-отчёт:
       Архитектор требовал: 8 файлов
       Найдено на диске:    3 файла  ← staging/ или Projects/
       Найдено в ответе:    5 файлов ← current_code от Кодера
       Покрытие:            5/8 (62%)
       Отсутствуют:         game.py, ui.py, config.py
  5. Если coverage < HARD_REJECT_THRESHOLD → немедленный REJECT без LLM
  6. Если coverage >= порога → передаём факт-отчёт Критику как контекст

Критик получает ФАКТЫ, а не просто читает мнение Кодера.
"""
import ast
import json
import os
import re

from app.agents.base import BaseAgent
from app.core.config import settings
from app.core.logger import get_logger
from app.core.workspace import get_staging_dir
from app.graph.state import WorkflowState
from app.schemas.chat import AgentResultSchema
from app.graph.nodes.helpers import _append_result

logger = get_logger(__name__)

# Если покрытие меньше этого — REJECT немедленно, без LLM Критика
HARD_REJECT_THRESHOLD = 0.5

# Расширения файлов которые считаем «кодом»
CODE_EXTENSIONS = {
    ".py", ".js", ".ts", ".go", ".rs", ".java", ".cpp", ".c",
    ".html", ".css", ".rb", ".php", ".sh", ".sql", ".jsx", ".tsx",
    ".vue", ".svelte", ".kt", ".swift", ".dart",
}


def _parse_required_files(arch_text: str) -> list[str]:
    """
    Извлекаем список файлов из плана Архитектора.

    Стратегия (от надёжной к гибкой):
      1. JSON-маркер: ищем блок REQUIRED_FILES_JSON: [...] — точный список без догадок.
      2. Regex fallback: строки вида "- file.py: описание" — на случай если модель
         проигнорировала JSON-секцию или написала план в произвольном формате.

    Обе стратегии возвращают дедуплицированные basename-имена файлов.
    """
    if not arch_text:
        return []

    # ── Стратегия 1: JSON-маркер ─────────────────────────────────────────
    # Ищем блок:
    #   REQUIRED_FILES_JSON:
    #   ["main.py", "game.py", "ui.py"]
    # или в одну строку:
    #   REQUIRED_FILES_JSON: ["main.py", "game.py"]
    json_match = re.search(
        r'REQUIRED_FILES_JSON\s*:\s*(\[[\s\S]*?\])',
        arch_text,
        re.IGNORECASE,
    )
    if json_match:
        try:
            raw = json.loads(json_match.group(1))
            if isinstance(raw, list):
                seen: set[str] = set()
                result: list[str] = []
                for item in raw:
                    if not isinstance(item, str):
                        continue
                    name = os.path.basename(item.strip())
                    ext = os.path.splitext(name)[1].lower()
                    if name and ext in CODE_EXTENSIONS and name not in seen:
                        seen.add(name)
                        result.append(name)
                if result:
                    return result
                # Если список пустой или все нефайловые — падаем на regex
        except (json.JSONDecodeError, ValueError):
            pass  # JSON кривой — пробуем regex

    # ── Стратегия 2: Regex fallback ──────────────────────────────────────
    # Охватывает распространённые форматы:
    #   - game.py: описание        (список с двоеточием)
    #   - ui.py — описание         (список с тире)
    #   - ui.py — описание         (список с длинным тире)
    #   **game.py** - описание     (markdown bold)
    #   game.py (описание)         (в скобках)
    #   Создать файл game.py       (произвольный текст рядом с именем файла)
    ext_list = "|".join(e.lstrip(".") for e in CODE_EXTENSIONS)
    # Паттерн 2a: классический список Архитектора "- file.py: ..."
    pattern_list = rf"-\s+([\w\-\./]+\.(?:{ext_list}))\s*[:\-—]"
    # Паттерн 2b: любое вхождение имени файла с известным расширением
    #   (ловит "Создать файл game.py", "Файл ui.py нужен для...", "**config.py**")
    pattern_any = rf'(?<![/\\])\b([\w\-]+\.(?:{ext_list}))\b'

    matches_list = re.findall(pattern_list, arch_text, re.IGNORECASE)
    if matches_list:
        # Классический формат найден — используем его (более точный)
        basenames = [os.path.basename(m) for m in matches_list]
    else:
        # Нашли файлы в произвольном тексте
        basenames = re.findall(pattern_any, arch_text, re.IGNORECASE)

    seen = set()
    result = []
    for f in basenames:
        name = os.path.basename(f)
        if name and name not in seen:
            seen.add(name)
            result.append(name)
    return result


def _scan_disk_files(project_name: str) -> set[str]:
    """
    Сканируем диск — Projects/ и staging/ — в поиске файлов проекта.
    Возвращаем множество basename файлов.
    """
    found = set()
    projects_dir = os.path.realpath(settings.projects_dir)
    staging_dir = get_staging_dir()

    search_roots = []

    # Если знаем имя проекта — ищем в конкретных папках
    if project_name:
        candidates = [
            os.path.join(projects_dir, project_name),
            os.path.join(staging_dir, project_name),
        ]
        for path in candidates:
            if os.path.isdir(path):
                search_roots.append(path)

    # Также сканируем staging полностью (там может быть другое имя)
    if os.path.isdir(staging_dir):
        for entry in os.scandir(staging_dir):
            if entry.is_dir() and entry.path not in search_roots:
                # Только свежие папки (< 2 часа)
                try:
                    if (os.path.getmtime(entry.path)) > (__import__("time").time() - 7200):
                        search_roots.append(entry.path)
                except OSError:
                    pass

    for root in search_roots:
        for dirpath, _, filenames in os.walk(root):
            for fname in filenames:
                ext = os.path.splitext(fname)[1].lower()
                if ext in CODE_EXTENSIONS:
                    found.add(fname)

    return found


def _validate_methods(project_dir: str) -> list[str]:
    """
    Статически ловит AttributeError вида 'X object has no attribute Y' для
    методов: код зовёт self.piece.get_rotated_shape(), но такого метода НЕТ
    ни в одном классе проекта → краш при запуске.

    Подход (очень консервативный, ноль ложных тревог):
      1. Собираем ВСЕ имена методов/атрибутов, определённых в классах проекта
         (def-методы + self.x = ... присваивания) и все имена функций.
      2. Находим вызовы вида <что-то>.имя(...) внутри проекта.
      3. Ругаемся ТОЛЬКО если имя метода не определено НИГДЕ в проекте И не
         похоже на стандартное (dunder, известные методы списков/строк/dict,
         pygame/stdlib API). Если хоть один класс определяет это имя — молчим.

    Это ловит именно рассинхрон имён между классами (renderer зовёт
    get_rotated_shape, а в Tetromino его нет), не трогая сторонние вызовы.
    """
    problems: list[str] = []
    if not project_dir or not os.path.isdir(project_dir):
        return problems

    py_files: list[tuple[str, str]] = []
    for dirpath, dirs, filenames in os.walk(project_dir):
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git", "staging", ".staging")]
        for fname in filenames:
            if fname.endswith(".py"):
                py_files.append((os.path.join(dirpath, fname),
                                 os.path.relpath(os.path.join(dirpath, fname), project_dir)))

    # 1. Все определённые в проекте имена + карта классов и их методов
    defined: set[str] = set()
    class_methods: dict[str, set[str]] = {}   # ClassName -> {методы}
    project_classes: set[str] = set()
    trees: list[tuple[str, ast.AST]] = []
    for abs_p, rel_p in py_files:
        try:
            tree = ast.parse(open(abs_p, encoding="utf-8").read())
        except Exception:
            continue
        trees.append((rel_p, tree))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                defined.add(node.name)
            elif isinstance(node, ast.ClassDef):
                defined.add(node.name)
                project_classes.add(node.name)
                methods = set()
                for item in ast.walk(node):
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        methods.add(item.name)
                class_methods[node.name] = methods
            elif isinstance(node, ast.Assign):
                for t in node.targets:
                    if isinstance(t, ast.Attribute):
                        defined.add(t.attr)

    # 2. Карта: self.attr -> ProjectClass (по присваиванию self.x = ProjectClass(...))
    #    Только так мы ТОЧНО знаем тип объекта и не ругаемся на сторонние (pygame).
    self_attr_class: dict[str, str] = {}
    for rel_p, tree in trees:
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for t in node.targets:
                    if (isinstance(t, ast.Attribute)
                            and isinstance(t.value, ast.Name) and t.value.id == "self"):
                        val = node.value
                        if isinstance(val, ast.Call) and isinstance(val.func, ast.Name):
                            cls = val.func.id
                            if cls in project_classes:
                                self_attr_class[t.attr] = cls

    # 3. Проверяем вызовы self.<attr>.method() где тип attr — ИЗВЕСТНЫЙ класс проекта
    #    и метода НЕТ в этом классе. Это исключает pygame/сторонние (их тип неизвестен).
    seen = set()
    for rel_p, tree in trees:
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            if not isinstance(func, ast.Attribute):
                continue
            mname = func.attr
            if mname.startswith("__"):
                continue
            base = func.value
            # Только self.<attr>.method() где attr — объект известного класса проекта
            if (isinstance(base, ast.Attribute)
                    and isinstance(base.value, ast.Name) and base.value.id == "self"):
                attr = base.attr
                cls = self_attr_class.get(attr)
                if cls and cls in class_methods:
                    # Тип объекта известен точно. Метода нет в его классе → баг.
                    if mname not in class_methods[cls] and mname not in seen:
                        seen.add(mname)
                        problems.append(
                            f"{os.path.basename(rel_p)}: вызывается self.{attr}.{mname}(), "
                            f"но класс {cls} не имеет метода '{mname}' → AttributeError. "
                            f"Добавь метод '{mname}' в класс {cls} или поправь имя вызова."
                        )
    return problems[:8]


def _validate_names(project_dir: str) -> list[str]:
    """
    Ловит NameError ДО запуска: имя используется в файле, но нигде в нём не
    определено, не импортировано, не является параметром/встроенным.

    Главный кейс из логов (рассинхрон Кодера между файлами):
      • game.py использует pygame.KEYDOWN, но забыл 'import pygame' → NameError
      • game.py использует FIGURE_COLORS, но забыл 'from constants import ...'

    Очень консервативно (ноль ложных тревог):
      • учитываем builtins, импорты, def/class, присваивания, параметры,
        comprehension-переменные, global/nonlocal, walrus, with..as, except..as,
        for-таргеты;
      • если в файле есть 'from X import *' — ПРОПУСКАЕМ файл (имена могут прийти
        оттуда, не можем знать);
      • ругаемся только на имена, которые ЯВНО где-то определены в ДРУГОМ файле
        проекта ИЛИ являются известным модулем (pygame и т.п.) — то есть это
        точно забытый импорт, а не случайная опечатка.
    """
    import builtins as _bi
    problems: list[str] = []
    if not project_dir or not os.path.isdir(project_dir):
        return problems

    _builtin_names = set(dir(_bi)) | {
        "self", "cls", "__name__", "__file__", "__doc__", "__class__",
        "True", "False", "None", "__import__", "__spec__", "__loader__",
    }
    _known_modules = {
        "pygame", "numpy", "np", "pandas", "pd", "random", "math", "os", "sys",
        "time", "json", "re", "collections", "itertools", "functools", "typing",
        "dataclasses", "enum", "datetime", "pathlib", "asyncio", "threading",
    }

    # 1. Карта всех имён, определённых где-либо в проекте (для фильтра «это наше»)
    project_defined: set[str] = set()
    files = []
    for dirpath, dirs, filenames in os.walk(project_dir):
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git", "staging", ".staging")]
        for fname in filenames:
            if fname.endswith(".py"):
                files.append(os.path.join(dirpath, fname))
    parsed = []
    for abs_p in files:
        try:
            tree = ast.parse(open(abs_p, encoding="utf-8").read())
        except Exception:
            continue
        parsed.append((abs_p, tree))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                project_defined.add(node.name)
            elif isinstance(node, ast.Assign):
                for t in node.targets:
                    if isinstance(t, ast.Name):
                        project_defined.add(t.id)

    # 2. Для каждого файла собираем определённые имена и проверяем использования
    for abs_p, tree in parsed:
        # Пропускаем файлы со star-import — там имена могут прийти откуда угодно
        has_star = any(
            isinstance(n, ast.ImportFrom) and any(a.name == "*" for a in n.names)
            for n in ast.walk(tree)
        )
        if has_star:
            continue

        local_defined: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    local_defined.add((a.asname or a.name).split(".")[0])
            elif isinstance(node, ast.ImportFrom):
                for a in node.names:
                    local_defined.add(a.asname or a.name)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                local_defined.add(node.name)
                for arg in list(node.args.args) + list(node.args.kwonlyargs) + list(node.args.posonlyargs):
                    local_defined.add(arg.arg)
                if node.args.vararg: local_defined.add(node.args.vararg.arg)
                if node.args.kwarg: local_defined.add(node.args.kwarg.arg)
            elif isinstance(node, ast.ClassDef):
                local_defined.add(node.name)
            elif isinstance(node, ast.Assign):
                for tgt in node.targets:        # ТОЛЬКО левая часть, не RHS
                    for t in ast.walk(tgt):
                        if isinstance(t, ast.Name):
                            local_defined.add(t.id)
            elif isinstance(node, (ast.For, ast.AsyncFor)):
                for t in ast.walk(node.target):
                    if isinstance(t, ast.Name):
                        local_defined.add(t.id)
            elif isinstance(node, (ast.comprehension,)):
                for t in ast.walk(node.target):
                    if isinstance(t, ast.Name):
                        local_defined.add(t.id)
            elif isinstance(node, ast.withitem) and node.optional_vars:
                for t in ast.walk(node.optional_vars):
                    if isinstance(t, ast.Name):
                        local_defined.add(t.id)
            elif isinstance(node, ast.ExceptHandler) and node.name:
                local_defined.add(node.name)
            elif isinstance(node, (ast.Global, ast.Nonlocal)):
                for nm in node.names:
                    local_defined.add(nm)
            elif isinstance(node, ast.NamedExpr) and isinstance(node.target, ast.Name):
                local_defined.add(node.target.id)
            elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
                local_defined.add(node.target.id)

        # Проверяем все загрузки имён (ctx=Load)
        flagged = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                nm = node.id
                if nm in local_defined or nm in _builtin_names or nm in flagged:
                    continue
                # Ругаемся ТОЛЬКО если имя точно «наше» (определено в другом файле
                # проекта) или это известный модуль (забыт import). Иначе — молчим
                # (может быть глобал/опечатка/динамика — не наша зона, без ложных).
                if nm in project_defined or nm in _known_modules:
                    flagged.add(nm)
                    rel = os.path.basename(abs_p)
                    if nm in _known_modules:
                        problems.append(
                            f"{rel}: используется '{nm}', но нет 'import {nm}' "
                            f"в этом файле → NameError. Добавь импорт."
                        )
                    else:
                        problems.append(
                            f"{rel}: используется '{nm}', но он не импортирован/не "
                            f"определён в этом файле → NameError. Добавь импорт "
                            f"(возможно 'from constants import {nm}' или из нужного модуля)."
                        )
    return problems[:8]


def _validate_imports(project_dir: str) -> list[str]:
    """
    Статическая проверка импортов: для каждого .py в проекте парсим import'ы и
    проверяем, что внутрипроектные модули реально существуют на диске.

    Ловит классический баг рассинхрона Архитектор↔Кодер:
       from board import Board       # а файл лежит в core/board.py
    → ModuleNotFoundError ещё до запуска, за миллисекунды.

    Консервативно: ругаемся ТОЛЬКО когда имя похоже на внутренний модуль
    (есть файл с таким basename где-то в проекте, но путь импорта не сходится).
    Сторонние пакеты (pygame, numpy...) и stdlib не трогаем — без ложных тревог.

    Возвращает список проблем вида "game.py: 'from board import X' — модуль
    лежит в core/board.py, импорт должен учитывать пакет".
    """
    problems: list[str] = []
    if not project_dir or not os.path.isdir(project_dir):
        return problems

    # 1. Карта: basename модуля (без .py) -> относительный путь пакета
    #    напр. 'board' -> 'core/board', 'main' -> 'main'
    module_paths: dict[str, list[str]] = {}
    py_files: list[tuple[str, str]] = []  # (abs_path, rel_path)
    for dirpath, dirs, filenames in os.walk(project_dir):
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".git", "staging", ".staging")]
        for fname in filenames:
            if not fname.endswith(".py"):
                continue
            abs_p = os.path.join(dirpath, fname)
            rel_p = os.path.relpath(abs_p, project_dir).replace(os.sep, "/")
            py_files.append((abs_p, rel_p))
            mod_name = fname[:-3]
            dotted = rel_p[:-3].replace("/", ".")  # core/board.py -> core.board
            module_paths.setdefault(mod_name, []).append(dotted)

    # Множество всех валидных dotted-путей внутри проекта
    valid_dotted = set()
    for paths in module_paths.values():
        valid_dotted.update(paths)
    # Папки-пакеты (core, ui, ...) тоже валидны как префиксы
    package_dirs = set()
    for dotted in valid_dotted:
        parts = dotted.split(".")
        for i in range(1, len(parts)):
            package_dirs.add(".".join(parts[:i]))

    # 2. Для каждого файла парсим import'ы
    for abs_p, rel_p in py_files:
        try:
            src = open(abs_p, encoding="utf-8").read()
            tree = ast.parse(src)
        except Exception:
            continue
        for node in ast.walk(tree):
            mod = None
            if isinstance(node, ast.ImportFrom):
                if node.level and node.level > 0:
                    continue  # относительный импорт (from .board) — не трогаем
                mod = node.module
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    _check_one(alias.name, rel_p, module_paths, valid_dotted,
                               package_dirs, problems)
                continue
            if not mod:
                continue
            _check_one(mod, rel_p, module_paths, valid_dotted, package_dirs, problems)

    # Уникализируем, ограничиваем
    seen = set()
    uniq = []
    for p in problems:
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    return uniq[:10]


def _check_one(mod: str, rel_p: str, module_paths: dict, valid_dotted: set,
               package_dirs: set, problems: list) -> None:
    """Проверяем один импортируемый модуль на внутрипроектную состоятельность."""
    if not mod:
        return
    top = mod.split(".")[0]
    base = mod.split(".")[-1]
    # Уже валидный путь внутри проекта или пакет-папка — ок
    if mod in valid_dotted or mod in package_dirs:
        return
    # Это вообще внутренний модуль? Считаем внутренним, если basename совпадает
    # с каким-то файлом проекта. Иначе это сторонний пакет (pygame и т.п.) — ок.
    candidates = module_paths.get(base) or module_paths.get(top)
    if not candidates:
        return  # не наш модуль — сторонний/stdlib, не трогаем
    # Импортируемое имя НЕ совпадает ни с одним реальным путём → рассинхрон
    # (напр. 'board', а файл 'core.board')
    if mod not in candidates and top not in package_dirs:
        right = candidates[0]
        problems.append(
            f"{rel_p}: импорт '{mod}' не находит модуль — файл лежит как "
            f"'{right}'. Используй 'from {right} import ...' "
            f"(учитывай папку-пакет), либо клади файл в корень."
        )


def resolve_project_dir(project_name: str) -> tuple[str | None, set[str]]:
    """
    Найти папку проекта на диске и вернуть (путь_к_папке, множество basename файлов кода).

    Используется и верификатором, и save_project — ЕДИНЫЙ источник правды.
    Приоритет поиска:
      1) Projects/<project_name>
      2) staging/<project_name>
      3) самая свежая (< 2 ч) папка с файлами кода в Projects/ или staging/
         (Кодер мог сохранить под другим именем)

    Если ничего не найдено — (None, set()).
    """
    projects_dir = os.path.realpath(settings.projects_dir)
    staging_dir = get_staging_dir()

    def _code_files(path: str) -> set[str]:
        found = set()
        for dirpath, _, filenames in os.walk(path):
            # пропускаем служебные папки
            if any(part in (".staging", "__pycache__", ".git") for part in dirpath.split(os.sep)):
                if os.path.basename(dirpath) in ("__pycache__", ".git"):
                    continue
            for fname in filenames:
                if os.path.splitext(fname)[1].lower() in CODE_EXTENSIONS:
                    found.add(fname)
        return found

    # 1) и 2) — точное имя
    if project_name:
        for base in (projects_dir, staging_dir):
            cand = os.path.join(base, project_name)
            if os.path.isdir(cand):
                files = _code_files(cand)
                if files:
                    return cand, files

    # 3) — свежая папка под другим именем
    import time as _t
    now = _t.time()
    best = None  # (mtime, path, files)
    for base in (projects_dir, staging_dir):
        if not os.path.isdir(base):
            continue
        try:
            for name in os.listdir(base):
                full = os.path.join(base, name)
                if not os.path.isdir(full) or name.startswith("."):
                    continue
                try:
                    mtime = os.path.getmtime(full)
                except OSError:
                    continue
                if (now - mtime) > 7200:  # старше 2 часов — не наш прогон
                    continue
                files = _code_files(full)
                if files and (best is None or mtime > best[0]):
                    best = (mtime, full, files)
        except OSError:
            continue

    if best:
        return best[1], best[2]
    return None, set()


def _scan_memory_files(current_code: str) -> set[str]:
    """
    Сканируем ответ Кодера (current_code) на наличие файлов.
    Используем тот же extract_all_files что и save_project.
    """
    if not current_code:
        return set()
    try:
        files = BaseAgent.extract_all_files(current_code)
        return {os.path.basename(k) for k in files.keys()}
    except Exception:
        return set()


def _build_fact_report(
    required: list[str],
    on_disk: set[str],
    in_memory: set[str],
    project_name: str,
) -> tuple[float, str, list[str]]:
    """
    Строим читаемый факт-отчёт.

    Returns:
        (coverage, report_text, missing_files)
    """
    all_found = on_disk | in_memory
    if not required:
        # Архитектор не дал список — coverage неизвестно
        report = (
            "📋 ФАКТ-ПРОВЕРКА\n"
            "─────────────────────────────\n"
            "Архитектор не указал явный список файлов.\n"
            f"На диске найдено: {len(on_disk)} файлов кода\n"
            f"В ответе Кодера:  {len(in_memory)} файлов кода\n"
            "─────────────────────────────\n"
            "Проверяй полноту по смыслу задачи.\n"
        )
        return 1.0, report, []

    covered = [f for f in required if f in all_found]
    on_disk_covered = [f for f in required if f in on_disk]
    in_memory_only = [f for f in required if f in in_memory and f not in on_disk]
    missing = [f for f in required if f not in all_found]
    coverage = len(covered) / len(required)

    status_icon = "✅" if coverage >= 0.8 else ("⚠️" if coverage >= HARD_REJECT_THRESHOLD else "❌")

    lines = [
        "📋 ФАКТ-ПРОВЕРКА (программная, не мнение модели)",
        "─────────────────────────────────────────────────",
        f"Архитектор требовал:  {len(required)} файлов",
        f"Найдено на диске:     {len(on_disk_covered)} файлов",
        f"Только в ответе:      {len(in_memory_only)} файлов  ← ещё не сохранены",
        f"Итого покрытие:       {len(covered)}/{len(required)} ({coverage*100:.0f}%)  {status_icon}",
        "─────────────────────────────────────────────────",
    ]

    if on_disk_covered:
        lines.append(f"На диске есть: {', '.join(on_disk_covered)}")
    if in_memory_only:
        lines.append(f"Только в ответе (не сохранены): {', '.join(in_memory_only)}")
    if missing:
        lines.append(f"ОТСУТСТВУЮТ:   {', '.join(missing)}")
        lines.append("")
        lines.append("=> Эти файлы Архитектор требовал, но Кодер не написал.")

    if project_name:
        lines.append(f"\nИмя проекта: {project_name}")

    return coverage, "\n".join(lines), missing


def make_verifier_node():
    """
    Программная проверка факта между Кодером и Критиком.
    Не использует LLM — только os.walk + regex.
    """
    async def node(state: WorkflowState) -> dict:
        arch_text = ""
        current_code = state.get("current_code", "")
        project_name = state.get("project_name", "")

        # Достаём план Архитектора из results
        results = state.get("results", [])
        def _agent(r): return r.agent if hasattr(r, "agent") else r.get("agent", "")
        def _resp(r):  return r.response if hasattr(r, "response") else r.get("response", "")

        for r in results:
            if _agent(r) == "architect":
                arch_text = _resp(r)
                break

        # Если project_name ещё не в state — пробуем извлечь из arch_text
        if not project_name and arch_text:
            m = re.search(r"PROJECT_NAME:\s*([\w\-\.]{2,50})", arch_text)
            if m:
                project_name = m.group(1).strip()

        # ── Факт-сбор ─────────────────────────────────────────────────────
        # Список файлов берём ЗАМОРОЖЕННЫЙ из state (зафиксирован Архитектором).
        # Только если его нет — парсим из текста (обратная совместимость).
        required = state.get("required_files") or _parse_required_files(arch_text)
        on_disk  = _scan_disk_files(project_name)
        in_memory = _scan_memory_files(current_code)

        coverage, fact_report, missing = _build_fact_report(
            required, on_disk, in_memory, project_name
        )

        logger.info(
            f"Verifier: required={len(required)}, "
            f"disk={len(on_disk)}, memory={len(in_memory)}, "
            f"coverage={coverage*100:.0f}%"
        )

        # ── Жёсткий REJECT если меньше порога ────────────────────────────
        # Статические проверки (полнота + импорты) дешёвые и детерминированные,
        # поэтому им даём ОТДЕЛЬНЫЙ бюджет раундов (static_round), не общий с
        # дорогими раундами рантайм-починки (debate_round). Иначе, как было в
        # логе: incomplete + import-фиксы съедали общий счётчик, и до проверки
        # импортов дело не доходило (current_round уже ≥ max).
        current_round = state.get("debate_round", 0)
        max_rounds = settings.debate_max_rounds
        static_round = state.get("static_round", 0)
        static_max = max(max_rounds + 2, 5)  # статике — больше попыток (дёшево)

        # Порог возврата к Кодеру: если не хватает файлов из ПЛАНА — нет смысла
        # запускать заведомо неполный проект (будет ModuleNotFoundError).
        # Возвращаем Кодеру дописать недостающее. Допускаем крошечный допуск
        # (1 файл на больших планах может оказаться лишним), но в остальном
        # требуем почти полное покрытие. Лимит раундов не даёт зациклиться.
        incomplete = bool(required) and coverage < 0.95 and missing

        if incomplete and static_round < static_max:
            miss_list = ", ".join(missing[:10])
            reject_msg = (
                f"{fact_report}\n\n"
                f"REJECTED — проект НЕПОЛНЫЙ (coverage {coverage*100:.0f}%, "
                f"не хватает {len(missing)} файлов).\n"
                f"ОТСУТСТВУЮТ: {miss_list}\n\n"
                f"ДЕЙСТВИЕ: запиши недостающие файлы на диск.\n"
                f"write_file({{path:\"{project_name or 'ИмяПроекта'}/<файл>\", content:\"...полный код...\"}})\n"
                f"для КАЖДОГО отсутствующего файла, затем save_project.\n"
                f"Запускать проект без них нет смысла — будет ModuleNotFoundError.\n"
                f"НЕ трать шаги на todo_tracker/run_python/check_package — пиши файлы."
            )
            logger.warning(
                f"Verifier REJECT (неполный): coverage {coverage*100:.0f}%, "
                f"нет {len(missing)} файлов {miss_list} "
                f"(статический раунд {static_round + 1}/{static_max})"
            )
            return {
                "critic_approved": False,
                "verifier_fact_report": fact_report,
                "verifier_coverage": coverage,
                "verifier_missing": missing,
                "static_round": static_round + 1,
                "current_context": reject_msg,
                "results": _append_result(
                    state,
                    AgentResultSchema(
                        agent="critic",
                        label=f"Верификатор — статический раунд {static_round + 1}",
                        response=reject_msg,
                        type="error",
                        round_n=static_round + 1,
                    ),
                ),
                "pending_action_id": None,
                "next_node": "critic_skip",
            }

        # Если статические раунды исчерпаны но покрытие всё ещё низкое — НЕ
        # зацикливаемся, отдаём факт Критику (он вынесет финальный вердикт).
        if incomplete:
            logger.warning(
                f"Verifier: coverage {coverage*100:.0f}% неполное, но статические "
                f"раунды исчерпаны ({static_round}/{static_max}) — к Критику без цикла."
            )

        # ── ВАЛИДАЦИЯ ИМПОРТОВ (статически, до запуска) ───────────────────
        # Покрытие 100%, но проект может не импортироваться: классический баг
        # 'from board import Board' когда файл лежит в core/board.py. Ловим за
        # миллисекунды и возвращаем Кодеру с точным указанием, ДО тестера.
        if not incomplete or coverage >= 0.95:
            proj_dir, _ = resolve_project_dir(project_name)
            import_problems = _validate_imports(proj_dir) if proj_dir else []
            # Также статически ловим AttributeError (вызов метода, которого нет
            # в классе) — баг вроде piece.get_rotated_shape(). Объединяем с импортами.
            method_problems = _validate_methods(proj_dir) if proj_dir else []
            # Ловим NameError статически: забытый import pygame, забытая константа
            # FIGURE_COLORS и т.п. (рассинхрон Кодера между файлами).
            name_problems = _validate_names(proj_dir) if proj_dir else []
            import_problems = import_problems + method_problems + name_problems
            if import_problems and static_round < static_max:
                probs = "\n".join(f"• {p}" for p in import_problems)
                imp_msg = (
                    f"{fact_report}\n\n"
                    f"REJECTED — все файлы на месте, но ИМПОРТЫ не сходятся "
                    f"(проект не запустится с ModuleNotFoundError):\n{probs}\n\n"
                    f"ДЕЙСТВИЕ: почини импорты через str_replace в указанных файлах.\n"
                    f"Если Архитектор задал папки (core/, ui/), импорт должен это "
                    f"учитывать: 'from core.board import Board', а не 'from board ...'.\n"
                    f"Это точечная правка строки импорта — НЕ переписывай файлы целиком."
                )
                logger.warning(
                    f"Verifier REJECT (импорты): {len(import_problems)} проблем "
                    f"(статический раунд {static_round + 1}/{static_max})"
                )
                # Включаем fix-mode: точечная правка импортов
                try:
                    from app.core.active_project import set_fix_mode
                    set_fix_mode(True)
                except Exception:
                    pass
                return {
                    "critic_approved": False,
                    "verifier_fact_report": fact_report,
                    "verifier_coverage": coverage,
                    "verifier_missing": missing,
                    "static_round": static_round + 1,
                    "current_context": imp_msg,
                    "results": _append_result(
                        state,
                        AgentResultSchema(
                            agent="critic",
                            label=f"Верификатор импортов — раунд {static_round + 1}",
                            response=imp_msg,
                            type="error",
                            round_n=static_round + 1,
                        ),
                    ),
                    "pending_action_id": None,
                    "next_node": "critic_skip",
                }

        # ── Передаём факт-отчёт Критику ───────────────────────────────────
        # Критик получит его как часть extra_context
        return {
            "verifier_fact_report": fact_report,
            "verifier_coverage": coverage,
            "verifier_missing": missing,
            "next_node": "critic",
        }

    return node
