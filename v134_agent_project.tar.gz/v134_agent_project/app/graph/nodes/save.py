"""Nodes package — узлы LangGraph workflow."""
import hashlib
import json
import os
import re
import time

from app.agents.base import BaseAgent
from app.agents.prompts import AGENTS
from app.agents.registry import create_agent, critic_is_approved
from app.core.logger import get_logger
from app.core.workspace import promote, list_staging_projects
from app.graph.state import WorkflowState
from app.schemas.chat import AgentResultSchema, ToolStepSchema
from app.schemas.tool import SaveProjectParams
from app.services.ollama_service import OllamaService
from app.services.tool_service import ToolService

logger = get_logger(__name__)
from app.graph.nodes.helpers import _append_result
from app.graph.nodes.verifier import resolve_project_dir, _parse_required_files

def make_human_approval_node(pending_repo_factory):
    async def node(state: WorkflowState) -> dict:
        action_id = state.get("pending_action_id")
        if not action_id:
            return {"next_node": "save_project"}

        pending_repo = pending_repo_factory()
        await pending_repo.save(
            action_id=action_id,
            session_id=state["session_id"],
            agent=state.get("pending_agent", ""),
            tool=state.get("pending_tool", ""),
            params=state.get("pending_params", {}),
            prompt_text=state.get("resume_prompt", ""),
            response_so_far=state.get("final_response", ""),
            steps=[s.model_dump() for s in state.get("pending_steps", [])],
            current_step=state.get("resume_step", 0),
            graph_state=dict(state),
        )
        logger.info(
            f"Approval saved: {action_id} tool={state.get('pending_tool')} "
            f"session={state['session_id']}"
        )
        return {"final_type": state.get("final_type", "confirm")}
    return node


# ── save_project ──────────────────────────────────────────────────────────────

def make_save_project_node(ollama: OllamaService, tools: ToolService):
    async def node(state: WorkflowState) -> dict:
        mode = state.get("mode", "multi")
        if mode != "multi":
            return {"final_type": "debate", "final_response": "Дебаты завершены."}

        results = state.get("results", [])
        user_msg = state["user_message"]

        all_files: dict[str, str] = {}
        arch_text = ""

        arch_project_name = None  # имя из PROJECT_NAME: ... строки Архитектора

        # LangGraph при resume десериализует AgentResultSchema как dict —
        # нормализуем чтобы всегда работать с объектами через .get()
        def _agent(r): return r.agent if hasattr(r, "agent") else r.get("agent", "")
        def _resp(r):  return r.response if hasattr(r, "response") else r.get("response", "")

        for r in results:
            if _agent(r) == "coder":
                all_files.update(BaseAgent.extract_all_files(_resp(r)))
            if _agent(r) == "architect" and not arch_text:
                arch_text = _resp(r)
                # Ищем PROJECT_NAME: <ИмяПроекта> в ответе Архитектора
                m = re.search(r"PROJECT_NAME:\s*([\w\-\.]{2,50})", arch_text)
                if m:
                    arch_project_name = m.group(1).strip()
                    logger.info(f"Project name from Architect: {arch_project_name!r}")

        # ── Проверяем staging — если Кодер уже сохранил туда файлы ──────────
        # В этом случае promote() переносит их в финальную папку
        staging_projects = list_staging_projects()
        if staging_projects:
            # Берём первый staging проект (обычно один за задачу)
            staging_name = staging_projects[0]
            promote_result = promote(staging_name)
            if promote_result["ok"]:
                logger.info(f"Promoted from staging: {staging_name} ({len(promote_result['files'])} files)")
                # ── Чистим .bak после успешного сохранения ──────────────────
                # write_file пишет .bak перед каждой правкой — больше не нужны.
                try:
                    _proj_path = promote_result.get("path", "")
                    if _proj_path and os.path.isdir(_proj_path):
                        _removed = 0
                        for _root, _, _files in os.walk(_proj_path):
                            for _f in _files:
                                if _f.endswith(".bak"):
                                    try:
                                        os.unlink(os.path.join(_root, _f))
                                        _removed += 1
                                    except OSError:
                                        pass
                        if _removed:
                            logger.info(f"Cleaned {_removed} .bak file(s) from {_proj_path}")
                except Exception as _e:
                    logger.warning(f".bak cleanup failed (non-critical): {_e}")
                return {
                    "final_type": "multi_done",
                    "final_response": (
                        f"✅ [OK] Проект '{staging_name}' → {promote_result['path']}\n"
                        + "\n".join(f"  {f}" for f in promote_result["files"][:10])
                    ),
                    "results": results,
                }

        # Fallback: если из results ничего не извлекли — берём current_code
        # (Кодер пишет код в ответе, не вызывает save_project сам в multi-mode)
        if not all_files:
            current_code = state.get("current_code", "")
            if current_code:
                all_files.update(BaseAgent.extract_all_files(current_code))
                logger.info(f"save_project: extracted files from current_code state")

        # Тесты из ответа тестера (если есть)
        for r in results:
            if _agent(r) == "tester":
                tests = BaseAgent.extract_code(_resp(r))
                if tests and "import unittest" in tests:
                    all_files["tests.py"] = tests
                break

        # Умное извлечение имени: приоритет именам собственным и техническим терминам
        def _extract_name(msg: str) -> str:
            first = msg.split('\n')[0].strip()
            clean = re.sub(r'PS [A-Z]:\\.*?>', '', first)
            clean = re.sub(r'[A-Z]:\\[^\s]+', '', clean)
            clean = re.sub(r'[«»""„\[\]()]', '', clean).strip()
            STOP = {
                'создай','сделай','напиши','разработай','реализуй','сгенерируй',
                'добавь','помоги','сделать','написать','создать',
                'create','make','build','write','generate','develop','implement',
                'и','или','с','для','на','в','по','из','к','у','за','от','до',
                'a','an','the','and','or','with','for','of','in','on','to',
                'современную','современный','красивым','красивый','увлекательную',
                'увлекательный','простую','простой','полную','полный',
                'интерфейсом','интерфейс','плавной','плавный','яркий','яркую',
                'удобный','удобную','мощный','мощную','быстрый','быструю',
                'игру','игра','приложение','программу','программа',
                'систему','система','инструмент','утилиту','утилита','скрипт',
                'modern','beautiful','simple','full','complete','advanced',
            }
            words = re.findall(r'[а-яёА-ЯЁa-zA-Z0-9][а-яёА-ЯЁa-zA-Z0-9\-]*', clean)
            proper = [w for w in words if w[0].isupper() and w.lower() not in STOP and len(w) > 2]
            abbr = [w for w in words if w.upper() == w and len(w) >= 2 and not w.isdigit()]
            eng = [w for w in words if re.match(r'[a-zA-Z]', w) and w.lower() not in STOP and len(w) > 3]
            cyr = [w for w in words if re.match(r'[а-яёА-ЯЁ]', w) and w.lower() not in STOP and len(w) > 3]
            result = []
            for pool in [proper, abbr, eng, cyr]:
                for w in pool:
                    if w not in result: result.append(w)
                    if len(result) >= 3: break
                if len(result) >= 3: break
            if not result:
                result = [w for w in words if w.lower() not in STOP][:3] or words[:3]
            name = '_'.join(result[:3])[:40]
            return re.sub(r'[^\w]', '_', name) or 'project'
        # Приоритет: имя от Архитектора > извлечённое из запроса
        # Приоритет: 1) project_name из state (зафиксирован architect node)
        #           2) regex PROJECT_NAME из results
        #           3) извлечение из промпта пользователя
        safe_name = (
            state.get("project_name")
            or arch_project_name
            or _extract_name(user_msg)
        )
        # ── ДИСК — ЕДИНЫЙ ИСТОЧНИК ПРАВДЫ ───────────────────────────────────
        # Кодер чаще всего пишет файлы через write_file/save_project ПРЯМО на диск,
        # а не текстом в ответе. Поэтому считаем покрытие по реальным файлам на
        # диске (так же как это делает верификатор), а текст — лишь дополнение.
        import time as _t, shutil as _sh
        from app.core.config import settings as _settings

        disk_dir, disk_files = resolve_project_dir(safe_name)
        files_already_on_disk = bool(disk_files)

        # Если папка нашлась под ДРУГИМ именем — переименуем в safe_name
        if disk_dir and os.path.basename(disk_dir) != safe_name:
            try:
                projects_dir = _settings.projects_dir
                target_dir = os.path.join(projects_dir, safe_name)
                # переносим только если целевой папки ещё нет и источник в Projects/
                if (not os.path.exists(target_dir)
                        and os.path.commonpath([os.path.realpath(disk_dir),
                                                 os.path.realpath(projects_dir)])
                            == os.path.realpath(projects_dir)):
                    _sh.move(disk_dir, target_dir)
                    logger.info(
                        f"save_project: переименовали {os.path.basename(disk_dir)!r} "
                        f"→ {safe_name!r} ({len(disk_files)} файлов кода)"
                    )
                    disk_dir = target_dir
            except (OSError, ValueError) as e:
                logger.warning(f"save_project: не удалось переименовать: {e}")

        # Объединённое множество написанных файлов: текст ответа ∪ диск
        created_names = {os.path.basename(f) for f in all_files} | disk_files

        # ── ПРОГРАММНАЯ ПРОВЕРКА ПОЛНОТЫ ПРОЕКТА (по диску ∪ тексту) ─────────────
        real_code_files = [
            f for f in all_files
            if f.endswith((".py", ".js", ".ts", ".go", ".rs", ".java", ".cpp", ".c",
                          ".html", ".css", ".rb", ".php", ".sh", ".sql"))
        ]

        # Список обязательных файлов из плана Архитектора (тот же парсер, что у верификатора)
        required_files = state.get("required_files") or _parse_required_files(arch_text)
        if required_files:
            logger.info(f"Архитектор требует {len(required_files)} файлов: {required_files}")

        # Считаем coverage по ОБЪЕДИНЕНИЮ (диск — главный, текст — дополнение)
        coverage = 1.0
        missing: list[str] = []
        if required_files:
            covered = [f for f in required_files if f in created_names]
            coverage = len(covered) / len(required_files)
            missing = [f for f in required_files if f not in created_names]
            logger.info(
                f"save_project coverage: {len(covered)}/{len(required_files)} "
                f"({coverage*100:.0f}%) | на диске={len(disk_files)} | "
                f"в тексте={len(real_code_files)} | папка={disk_dir}"
            )

            # Блокируем ТОЛЬКО если файлов реально мало И на диске их тоже нет.
            # (раньше блокировка срабатывала даже когда диск был полон — главный баг v73)
            if coverage < 0.8:
                error_msg = (
                    f"⚠️ Проект неполный: написано {len(covered)}/{len(required_files)} файлов "
                    f"({coverage*100:.0f}% от плана).\n\n"
                    f"Отсутствуют: {', '.join(missing)}\n\n"
                    f"Кодер должен написать все обязательные файлы из плана Архитектора.\n"
                    f"Попробуй снова — опиши задачу заново или используй кнопку повтора."
                )
                logger.warning(
                    f"save_project BLOCKED: coverage {coverage*100:.0f}% < 80% "
                    f"({len(covered)}/{len(required_files)} файлов, диск={len(disk_files)})"
                )
                return {
                    "results": _append_result(
                        state,
                        AgentResultSchema(
                            agent="manager",
                            label="Сохранение",
                            response=error_msg,
                            type="error",
                        ),
                    ),
                    "final_response": error_msg,
                    "final_type": "error",
                    "pending_action_id": None,
                    "next_node": "__end__",
                }
            elif missing:
                logger.info(f"save_project: coverage {coverage*100:.0f}%, пропущены: {missing}")

        # Если ни одного файла нигде — честная ошибка
        if not real_code_files and not files_already_on_disk:
            error_msg = (
                "⚠️ Модель не написала ни одного файла кода.\n\n"
                "Возможные причины:\n"
                "• Ollama зависла (timeout на запросе)\n"
                "• Модель потеряла контекст на длинной задаче\n\n"
                "Что попробовать:\n"
                "• Перезапустить запрос\n"
                "• Разбить задачу на меньшие части\n"
                "• Попробовать другую модель в Настройках"
            )
            logger.warning("save_project: кодер не написал ни одного файла")
            return {
                "results": _append_result(
                    state,
                    AgentResultSchema(
                        agent="manager",
                        label="Сохранение",
                        response=error_msg,
                        type="error",
                    ),
                ),
                "final_response": error_msg,
                "final_type": "error",
                "pending_action_id": None,
                "next_node": "__end__",
            }

        from app.schemas.tool import SaveProjectParams

        # ── Итоговый статус всех условий выполнения ──────────────────────────
        _critic_ok = state.get("critic_approved", False)
        _tests_ok  = state.get("tests_passed", False)
        logger.info(
            f"Условия завершения: "
            f"файлы={coverage*100:.0f}%/{len(required_files) if required_files else '?'} | "
            f"критик={_critic_ok} | тесты={_tests_ok}"
        )

        final_dir = disk_dir or os.path.join(_settings.projects_dir, safe_name)

        if files_already_on_disk:
            # ── Случай 1: файлы уже на диске (Кодер сохранил через инструмент) ──
            # Диск — источник правды. Дописываем ТОЛЬКО те файлы из текста ответа,
            # которых на диске ещё нет (не перезатираем рабочие версии на диске).
            new_from_text = {
                path: content
                for path, content in all_files.items()
                if os.path.basename(path) not in disk_files
            }
            if new_from_text:
                proj = SaveProjectParams(name=safe_name, files=new_from_text)
                await tools.execute("save_project", proj.model_dump(), skip_approval=True)
                logger.info(
                    f"save_project: дописано {len(new_from_text)} новых файлов "
                    f"к {len(disk_files)} на диске"
                )

            # README — только если его ещё нет на диске
            try:
                readme_path = os.path.join(final_dir, "README.md")
                if not os.path.exists(readme_path):
                    with open(readme_path, "w", encoding="utf-8") as f:
                        f.write(f"# {safe_name}\n\n{arch_text[:500]}")
            except OSError:
                pass

            # Реальная картина диска ПОСЛЕ всех дозаписей (не из текста ответа!)
            _final_dir2, final_disk_files = resolve_project_dir(safe_name)
            shown_files = sorted(final_disk_files or disk_files)
            result = type("R", (), {
                "output": f"[OK] Проект {safe_name!r} → {final_dir} ({len(shown_files)} файлов)"
            })()
        else:
            # ── Случай 2: файлов на диске нет — сохраняем из текста ответа ──
            if all_files:
                all_files["README.md"] = f"# {safe_name}\n\n{arch_text[:500]}"
            proj = SaveProjectParams(name=safe_name, files=all_files)
            result = await tools.execute("save_project", proj.model_dump(), skip_approval=True)
            shown_files = list(all_files.keys())

        final_msg = f"✅ {result.output}\n\nФайлы: {shown_files}"

        # ── AGENT_CONTEXT.md — машиночитаемый контракт проекта ───────────────
        # Персистируется рядом с кодом. При повторном запросе ("добавь звук")
        # Архитектор и Кодер читают этот файл вместо планирования с нуля.
        # Записываем ТОЛЬКО при успешном сохранении (tests_ok или хотя бы файлы есть).
        try:
            ctx_path = os.path.join(final_dir, "AGENT_CONTEXT.md")
            # STRUCTURE — с ФАКТИЧЕСКОГО диска, не из required (required при
            # доработке содержит лишь изменяемые файлы; контракт обязан хранить
            # ПОЛНУЮ картину, иначе следующий прогон планирует по обрезку.
            try:
                _disk_py = sorted(f for f in os.listdir(final_dir)
                                  if f.endswith(".py"))
            except OSError:
                _disk_py = []
            if _disk_py:
                _req_files_line = ", ".join(_disk_py)
            else:
                _req_files_line = (", ".join(required_files) if required_files
                                   else ", ".join(sorted(created_names)[:20]))
            # Последняя ошибка которую чинили (из fix_memory / state)
            _last_fix = ""
            _last_err = state.get("last_error_text", "")
            if _last_err:
                try:
                    from app.memory.fix_memory import error_signature, _build_recipe
                    _sig = error_signature(_last_err)
                    _recipe = _build_recipe(_last_err)
                    if _sig and _recipe:
                        _last_fix = f"\nLAST_FIX: [{_sig}] → {_recipe[:120]}"
                except Exception:
                    pass
            _packages = ""
            _installed = state.get("installed_packages") or []
            if _installed:
                _packages = f"\nKNOWN_PACKAGES: {', '.join(_installed)}"
            # Точка входа из smoke-теста
            _entry = ""
            if state.get("tester_report") and "запущен" in state.get("tester_report", "").lower():
                from app.graph.nodes.smoke_test import _find_entry
                _found_entry = _find_entry(final_dir)
                if _found_entry:
                    _entry = f"\nENTRY: {os.path.basename(_found_entry)}"
            ctx_content = (
                f"# AGENT_CONTEXT — {safe_name}\n"
                f"<!-- Машиночитаемый контракт. Не редактируй вручную. -->\n\n"
                f"PROJECT_NAME: {safe_name}\n"
                f"STRUCTURE: {_req_files_line}"
                f"{_entry}"
                f"{_packages}"
                f"{_last_fix}\n\n"
                f"## Описание задачи\n{user_msg[:300]}\n\n"
                f"## Архитектурный план\n{arch_text[:600]}\n"
            )
            with open(ctx_path, "w", encoding="utf-8") as _f:
                _f.write(ctx_content)
            logger.info(f"AGENT_CONTEXT.md записан: {ctx_path}")
        except Exception as _ctx_err:
            logger.warning(f"AGENT_CONTEXT.md не записан (некритично): {_ctx_err}")

        # ── Самообучение: скилл + очередь рефлексии ──────────────────────────
        # Дёшево (запись JSON, без LLM). LLM-рефлексия произойдёт в простое.
        try:
            from app.learning.skill_library import record_success
            from app.learning.reflection import enqueue_session
            _pkgs = state.get("installed_packages") or []
            if _tests_ok:
                # Только ДОКАЗАННЫЕ структуры попадают в библиотеку скиллов
                _entry_name = ""
                try:
                    from app.graph.nodes.smoke_test import _find_entry as _fe
                    _ep = _fe(final_dir)
                    if _ep:
                        _entry_name = os.path.basename(_ep)
                except Exception:
                    pass
                record_success(
                    task_text=user_msg,
                    project_name=safe_name,
                    files=required_files or sorted(created_names)[:20],
                    packages=_pkgs,
                    entry=_entry_name,
                )
            # Рефлексия — для ВСЕХ прогонов: из провалов уроки даже ценнее
            _err_hist = []
            if state.get("last_error_text"):
                _err_hist.append(state["last_error_text"])
            enqueue_session(
                session_id=state.get("session_id", "?"),
                user_message=user_msg,
                required_files=required_files or [],
                tests_passed=bool(_tests_ok),
                error_history=_err_hist,
                packages=_pkgs,
            )
        except Exception as _learn_err:
            logger.warning(f"learning hooks skipped (некритично): {_learn_err}")

        # Честно сообщаем статус проверок — если запуск так и не прошёл,
        # пользователь должен знать (проект сохранён, но не запускается).
        # НЕ предлагаем «запусти ещё раз» — система уже отработала раунды починки
        # и не справилась; перекладывать это на пользователя нечестно. Даём факт.
        _tester_report = state.get("tester_report", "")
        if not _tests_ok and _tester_report and "ПРОВАЛЕН" in _tester_report:
            # Вытащим краткую суть ошибки (последняя содержательная строка)
            _err_line = ""
            for _ln in reversed(_tester_report.strip().splitlines()):
                _s = _ln.strip()
                if _s and ("Error" in _s or "error" in _s):
                    _err_line = _s
                    break
            final_msg += (
                f"\n\n⚠️ Проект сохранён, но не запускается после {state.get('test_round', 0)} "
                f"раундов автоисправления.\n"
            )
            if _err_line:
                final_msg += f"Осталась ошибка: {_err_line[:200]}\n"
            final_msg += (
                f"Это предел текущей модели на этой задаче. Варианты: открыть "
                f"указанный файл и поправить вручную, либо назначить Кодеру более "
                f"сильную модель в настройках и повторить."
            )
        elif _tests_ok and _tester_report:
            final_msg += f"\n\n{_tester_report[:200]}"

        results_with_save = _append_result(
            state,
            AgentResultSchema(
                type="done", agent="manager",
                response=final_msg, label="Проект сохранён",
            ),
        )
        return {
            "results": results_with_save,
            "final_type": "multi_done",
            "final_response": final_msg,
        }
    return node


# ── Helpers ───────────────────────────────────────────────────────────────────

def _confirm_update(run, final_type: str) -> dict:
    """Стандартный update state при получении confirm от агента."""
    return {
        "pending_action_id": run.pending_action_id,
        "pending_tool": run.pending_tool,
        "pending_params": run.pending_params,
        "pending_agent": run.agent_key,
        "pending_thought": run.pending_thought,
        "pending_steps": run.steps,
        "resume_prompt": run.resume_prompt,
        "resume_step": len(run.steps),
        "final_type": final_type,
        "next_node": "human_approval",
    }