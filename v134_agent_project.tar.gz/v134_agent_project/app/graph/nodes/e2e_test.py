"""
E2E-тестирование проекта (End-to-End), 3 уровня с деградацией.

Зачем: smoke-тест проверяет только СТАРТ (окно открылось, не упало за N сек).
Он НЕ видит ошибки игрового цикла — классический баг `update() missing dt`
проявляется только когда цикл реально крутится. E2E прогоняет цикл и ловит это.

Три уровня (каждый — надстройка, при недоступности откатывается на нижний):

  Уровень 1 — Headless Harness (всегда):
    Запускает точку входа с SMOKE_TEST=1 и preload-инъекцией событий, без окна
    (dummy SDL). Цикл реально крутится несколько кадров → ошибки рантайма
    (несовпадение сигнатур, доступ к None) всплывают как настоящий traceback.

  Уровень 2 — Goal Checklist (если есть задача):
    Из текста задачи строится чеклист ожиданий (окно/счёт/game over). Проверяем
    программные сигналы: код выхода, маркеры в stdout, наличие traceback.

  Уровень 3 — Vision (если доступна vision-модель):
    Делает скриншот окна и спрашивает модель, что на экране, сверяет с чеклистом.

Универсально (фокус Python): работает для pygame/tkinter/CLI; для Flask —
тестовый запрос. Если уровень недоступен — тихо опускаемся на нижний, НЕ ломая
прогон ложным провалом.
"""
from __future__ import annotations

import asyncio
import os
import re
import subprocess
import sys
from dataclasses import dataclass, field

from app.core.logger import get_logger

logger = get_logger(__name__)

# Сколько кадров/секунд гоняем цикл в harness-режиме
_E2E_FRAMES = 30
_E2E_TIMEOUT = 25


@dataclass
class E2EResult:
    """Результат E2E-теста."""

    passed: bool
    level: int                       # какой уровень реально отработал (1/2/3)
    summary: str                     # человекочитаемый вердикт
    error_detail: str = ""           # traceback при падении цикла
    checklist: list = field(default_factory=list)   # пункты проверки (ур.2/3)
    vision_report: str = ""          # что увидела vision-модель (ур.3)


# ──────────────────────────────────────────────────────────────────────────
# PRELOAD — инъекция в процесс проекта. Делает запуск headless и принудительно
# прогоняет цикл, затем чисто выходит. Пишется во временный файл рядом с проектом.
# ──────────────────────────────────────────────────────────────────────────
_PRELOAD_SRC = r'''
# Авто-инъекция E2E: headless + ограничение цикла + перехват ошибок цикла.
import os, sys, threading, time, traceback, builtins

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ["SMOKE_TEST"] = "1"   # кооперативный флаг: код может сам ограничить цикл

_E2E_MAX_SECONDS = float(os.environ.get("E2E_MAX_SECONDS", "8"))
_E2E_START_TS = time.time()

# Перехват необработанных исключений в фоновых потоках и главном — пишем маркер
_orig_excepthook = sys.excepthook
def _hook(exc_type, exc, tb):
    sys.stderr.write("E2E_LOOP_ERROR\n")
    traceback.print_exception(exc_type, exc, tb)
    sys.stderr.flush()
    os._exit(7)   # отдельный код = ошибка в рантайме цикла
sys.excepthook = _hook

def _thread_hook(args):
    sys.stderr.write("E2E_LOOP_ERROR\n")
    traceback.print_exception(args.exc_type, args.exc_value, args.exc_traceback)
    sys.stderr.flush()
    os._exit(7)
try:
    threading.excepthook = _thread_hook
except Exception:
    pass

# Watchdog: через N секунд шлём QUIT (pygame) и затем жёстко выходим кодом 0
def _watchdog():
    time.sleep(_E2E_MAX_SECONDS)
    try:
        import pygame
        for _ in range(5):
            try:
                pygame.event.post(pygame.event.Event(pygame.QUIT))
            except Exception:
                break
            time.sleep(0.1)
    except Exception:
        pass
    time.sleep(1.0)
    # Если процесс ещё жив — цикл не завершился по QUIT, но и не упал → старт OK
    sys.stderr.write("E2E_TIMEOUT_OK\n"); sys.stderr.flush()
    os._exit(0)

threading.Thread(target=_watchdog, daemon=True).start()

# Инъектор событий: периодически шлём типичные клавиши, чтобы цикл прошёл дальше
# меню (ENTER/SPACE) и подвигал объекты (стрелки). Это и заставляет update()
# реально вызываться — там и всплывают баги сигнатур.
def _feeder():
    time.sleep(1.0)
    try:
        import pygame
        keys = []
        for kn in ("K_RETURN", "K_SPACE", "K_LEFT", "K_RIGHT", "K_DOWN", "K_UP"):
            k = getattr(pygame, kn, None)
            if k is not None:
                keys.append(k)
        for _ in range(20):
            if time.time() - _E2E_START_TS > _E2E_MAX_SECONDS:
                break
            for k in keys:
                try:
                    pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=k))
                    pygame.event.post(pygame.event.Event(pygame.KEYUP, key=k))
                except Exception:
                    return
            time.sleep(0.2)
    except Exception:
        pass

threading.Thread(target=_feeder, daemon=True).start()
'''


def _write_preload(project_dir: str) -> str:
    """Пишем preload рядом с проектом, возвращаем путь."""
    path = os.path.join(project_dir, "_e2e_preload.py")
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(_PRELOAD_SRC)
    except OSError:
        return ""
    return path


def _cleanup_preload(project_dir: str) -> None:
    for name in ("_e2e_preload.py",):
        p = os.path.join(project_dir, name)
        try:
            if os.path.exists(p):
                os.remove(p)
        except OSError:
            pass


async def _run(cmd: list[str], cwd: str, timeout: int, env: dict | None = None):
    """Запуск подпроцесса. returncode=None означает timeout (процесс жив)."""
    loop = asyncio.get_running_loop()
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    try:
        result = await loop.run_in_executor(
            None,
            lambda: subprocess.run(
                cmd, capture_output=True, text=True, timeout=timeout,
                cwd=cwd, env=run_env,
            ),
        )
        return result.returncode, (result.stdout or ""), (result.stderr or "")
    except subprocess.TimeoutExpired as e:
        out = e.stdout or ""
        err = e.stderr or ""
        if isinstance(out, bytes):
            out = out.decode("utf-8", "replace")
        if isinstance(err, bytes):
            err = err.decode("utf-8", "replace")
        return None, out, err


# ──────────────────────────────────────────────────────────────────────────
# Уровень 1 — Headless Harness
# ──────────────────────────────────────────────────────────────────────────
async def _level1_harness(project_dir: str, entry_file: str) -> E2EResult:
    """
    Прогоняет реальный цикл проекта headless с инъекцией событий.
    Ловит ошибки рантайма игрового цикла (главная цель E2E).
    """
    preload = _write_preload(project_dir)
    entry_rel = os.path.basename(entry_file)
    try:
        # runpy.run_path с run_name='__main__' ГАРАНТИРует выполнение блока
        # if __name__ == "__main__" (через простой exec он бы не запустился).
        code = (
            "import _e2e_preload, runpy;"
            f"runpy.run_path(r'{entry_rel}', run_name='__main__')"
        )
        rc, out, err = await _run(
            [sys.executable, "-c", code], project_dir, _E2E_TIMEOUT,
            env={"E2E_MAX_SECONDS": "8"},
        )
    finally:
        _cleanup_preload(project_dir)

    tail = err[-1500:] if len(err) > 1500 else err

    # Код 7 = наш маркер ошибки в цикле (excepthook поймал traceback)
    if rc == 7 or "E2E_LOOP_ERROR" in err:
        return E2EResult(
            passed=False, level=1,
            error_detail=err,
            summary=(
                f"❌ E2E ПРОВАЛЕН: `{entry_rel}` падает в игровом цикле "
                f"(не только на старте):\n{tail}"
            ),
        )
    # Любой другой ненулевой код, кроме 0 и нашего timeout-маркера
    if rc not in (0, None) and "E2E_TIMEOUT_OK" not in err:
        if "Traceback" in err:
            return E2EResult(
                passed=False, level=1, error_detail=err,
                summary=f"❌ E2E ПРОВАЛЕН: `{entry_rel}` упал (код {rc}):\n{tail}",
            )
    # Прошёл цикл без падения (вышел по QUIT, по таймауту, или код 0)
    return E2EResult(
        passed=True, level=1,
        summary=(
            f"✅ E2E уровень 1: `{entry_rel}` прогнал игровой цикл с симуляцией "
            f"событий (ENTER/стрелки) без ошибок рантайма."
        ),
    )


# ──────────────────────────────────────────────────────────────────────────
# Уровень 2 — Goal Checklist (программные сигналы из задачи)
# ──────────────────────────────────────────────────────────────────────────

def _frames_static(path1: str, path2: str) -> bool:
    """Пиксельный дифф двух кадров: True = экран статичен (дефект).
    Порог: < 0.3%% изменившихся пикселей (яркость дельты > 12) — живая игра
    с гравитацией/анимацией меняет заметно больше. Без LLM, мгновенно."""
    try:
        from PIL import Image, ImageChops
        im1 = Image.open(path1).convert("L")
        im2 = Image.open(path2).convert("L")
        if im1.size != im2.size:
            return False
        diff = ImageChops.difference(im1, im2)
        hist = diff.histogram()  # 256 бинов яркости дельты
        changed = sum(hist[13:])  # пиксели с дельтой > 12 (шум камеры/сглаживание ниже)
        total = im1.size[0] * im1.size[1]
        return (changed / max(total, 1)) < 0.003
    except Exception:
        return False  # не смогли сравнить — не наговариваем


def _build_checklist(task: str) -> list[str]:
    """Грубый чеклист из задачи по ключевым словам (без LLM — быстро, дёшево)."""
    t = (task or "").lower()
    checks = ["проект запускается без падения"]
    if any(w in t for w in ("игр", "game", "тетрис", "tetris", "арканоид", "змейк", "snake")):
        checks += ["игровой цикл крутится без ошибок", "обработка ввода не падает",
                   "на игровом поле видна активная фигура/объект (поле не пустое)",
                   "виден элемент счёта (Score/Очки) на экране"]
    if any(w in t for w in ("счёт", "score", "очки")):
        checks.append("счёт обновляется")
    if any(w in t for w in ("меню", "menu", "старт", "start")):
        checks.append("стартовое меню появляется")
    if any(w in t for w in ("game over", "проигрыш", "конец игры")):
        checks.append("состояние game over достижимо")
    if any(w in t for w in ("сайт", "site", "flask", "web", "сервер", "api")):
        checks.append("сервер отвечает на запрос")
    return checks


# ──────────────────────────────────────────────────────────────────────────
# Главная функция E2E — оркестрирует уровни с деградацией
# ──────────────────────────────────────────────────────────────────────────
async def e2e_test(
    project_dir: str,
    entry_file: str,
    task: str = "",
    ollama=None,
    vision_model: str | None = None,
) -> E2EResult:
    """
    Прогоняет E2E с деградацией: уровень 1 (всегда) → 2 (чеклист) → 3 (vision).
    Возвращает вердикт. Любой сбой верхнего уровня откатывается на нижний.
    """
    if not entry_file or not os.path.isdir(project_dir):
        return E2EResult(True, 0, "(нет точки входа для E2E — пропущено)")

    # ── Уровень 1: harness (критичный, ловит баги цикла) ──
    try:
        r1 = await _level1_harness(project_dir, entry_file)
    except Exception as e:
        logger.warning(f"E2E level1 error: {e}")
        return E2EResult(True, 0, f"(E2E уровень 1 не отработал: {e} — пропущено)")

    if not r1.passed:
        return r1   # цикл падает — дальше нет смысла, отдаём traceback Кодеру

    # ── Уровень 2: чеклист целей ──
    checklist = _build_checklist(task)
    r1.checklist = checklist
    r1.level = 2
    r1.summary += f"\n📋 Чеклист целей ({len(checklist)}): " + "; ".join(checklist)

    # ── Уровень 3: vision (если доступна модель) — мягкий гейт ──
    # Vision МОЖЕТ завернуть проект к Кодеру, но ТОЛЬКО при явном дефекте
    # (модель уверенно сказала, что пункт ТЗ не выполнен). При неуверенности,
    # ошибке, отсутствии дисплея/модели — тихо пропускаем (best-effort).
    if ollama is not None and vision_model:
        try:
            vis_report, vis_defects = await _level3_vision(
                project_dir, entry_file, checklist, task, ollama, vision_model
            )
            if vis_report:
                r1.level = 3
                r1.vision_report = vis_report
                r1.summary += f"\n👁 Vision-проверка:\n{vis_report}"
                if vis_defects:
                    # Явные визуальные дефекты → заворачиваем к Кодеру
                    defects_str = "; ".join(vis_defects)
                    r1.passed = False
                    r1.error_detail = (
                        f"Vision-проверка нашла визуальные дефекты (проект запускается, "
                        f"но ведёт себя не по ТЗ):\n{defects_str}\n\n"
                        f"Это НЕ краш — игра работает, но на экране что-то не так. "
                        f"Прочитай код отрисовки/логики и исправь именно эти пункты."
                    )
                    r1.summary += f"\n❌ Vision: явные дефекты — возврат к Кодеру"
        except Exception as e:
            logger.warning(f"E2E vision error (некритично): {e}")

    return r1


async def _level3_vision(project_dir, entry_file, checklist, task, ollama, vision_model):
    """
    Делает скриншот ВО ВРЕМЯ работы (после инъекции клавиш — чтобы попасть не на
    пустое меню, а на реальный экран приложения) и просит vision-модель сверить
    с чеклистом. Возвращает (отчёт, список_явных_дефектов).

    Мягкий гейт: дефект засчитывается ТОЛЬКО если модель явно пишет, что пункт
    НЕ выполнен. При неуверенности/ошибке/отсутствии дисплея — ("", []).
    Универсально: works для любого GUI; на headless без дисплея — тихо пропуск.
    """
    # Зависимости и дисплей
    try:
        import mss  # noqa
        from PIL import Image  # noqa
    except Exception:
        return ("⚠️ ВИЗУАЛЬНАЯ ПРОВЕРКА НЕДОСТУПНА: не установлены mss/pillow "
                "(pip install mss pillow). Чёрный/статичный экран НЕ проверялся — "
                "уровень E2E ограничен чеклистом.", [])
    if not (os.environ.get("DISPLAY") or sys.platform.startswith("win")):
        return ("⚠️ ВИЗУАЛЬНАЯ ПРОВЕРКА НЕДОСТУПНА: нет дисплея (headless). "
                "Статичный экран не проверялся.", [])

    import base64, tempfile
    shot_path = os.path.join(tempfile.gettempdir(), "e2e_shot.png")
    shot1_path = os.path.join(tempfile.gettempdir(), "e2e_shot1.png")
    for _p in (shot_path, shot1_path):
        try:
            if os.path.exists(_p):
                os.remove(_p)
        except OSError:
            pass

    # Capturer: запускает окно, ИНЪЕКТИРУЕТ клавиши (ENTER старт + стрелки/вращение),
    # делает скриншот УЖЕ во время игрового процесса, затем выходит.
    capturer = (
        "import threading, time, os\n"
        "def _drive():\n"
        "    time.sleep(1.2)\n"
        "    try:\n"
        "        import pygame\n"
        "        # старт игры + немного действий, чтобы попасть на игровой экран\n"
        "        seq = ['K_RETURN','K_RETURN','K_DOWN','K_LEFT','K_RIGHT','K_UP','K_SPACE']\n"
        "        for kn in seq:\n"
        "            k = getattr(pygame, kn, None)\n"
        "            if k is None: continue\n"
        "            try:\n"
        "                pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=k))\n"
        "                pygame.event.post(pygame.event.Event(pygame.KEYUP, key=k))\n"
        "            except Exception: pass\n"
        "            time.sleep(0.25)\n"
        "    except Exception: pass\n"
        "def _shot():\n"
        "    try:\n"
        "        import mss\n"
        "        with mss.mss() as s:\n"
        "            time.sleep(2.2)\n"   # кадр 1: игра уже идёт
        f"            s.shot(output=r'{shot1_path}')\n"
        "            time.sleep(2.3)\n"   # кадр 2: спустя 2.3с — гравитация обязана сдвинуть картинку
        f"            s.shot(output=r'{shot_path}')\n"
        "    except Exception: pass\n"
        "    time.sleep(0.4); os._exit(0)\n"
        "threading.Thread(target=_drive, daemon=True).start()\n"
        "threading.Thread(target=_shot, daemon=True).start()\n"
    )
    cap_file = os.path.join(project_dir, "_e2e_cap.py")
    try:
        with open(cap_file, "w", encoding="utf-8") as f:
            f.write(capturer)
        entry_rel = os.path.basename(entry_file)
        code = (
            "import _e2e_cap, runpy;"
            f"runpy.run_path(r'{entry_rel}', run_name='__main__')"
        )
        await _run([sys.executable, "-c", code], project_dir, 14)
    finally:
        try:
            os.remove(cap_file)
        except OSError:
            pass

    if not os.path.exists(shot_path):
        return "", []

    # ── Динамика: два кадра с разницей 2.3с. Идентичные кадры = игровой цикл
    # не обновляет экран (зависшая фигура, пустое поле, мёртвый рендер).
    # Это ЖЁСТКИЙ дефект — без участия vision-модели.
    hard_defects: list[str] = []
    if os.path.exists(shot1_path) and _frames_static(shot1_path, shot_path):
        hard_defects.append(
            "Экран СТАТИЧЕН: кадры на 2.2с и 4.5с после старта идентичны — "
            "игровой цикл не обновляет картинку (гравитация/анимация/перерисовка "
            "не работают, или фигура не создаётся). Проверь: tick/update вызывается "
            "периодически (after/clock), состояние меняется, рендер перерисовывает."
        )
    try:
        with open(shot_path, "rb") as f:
            img_b64 = base64.b64encode(f.read()).decode()
    except OSError:
        return ("\n".join(hard_defects), hard_defects) if hard_defects else ("", [])

    # Структурированный запрос: по каждому пункту — OK / FAIL / UNSURE.
    # FAIL засчитываем как дефект ТОЛЬКО при явном FAIL (не UNSURE).
    checklist_block = "\n".join(f"{i+1}. {c}" for i, c in enumerate(checklist))
    prompt = (
        f"Ты QA-тестер. На скриншоте — запущенное приложение по задаче:\n"
        f"\"{task[:300]}\"\n\n"
        f"Проверь КАЖДЫЙ пункт. Для каждого ответь СТРОГО в формате:\n"
        f"<номер>: <OK|FAIL|UNSURE> — <короткое пояснение>\n"
        f"OK = пункт явно выполнен; FAIL = пункт явно НЕ выполнен (видна ошибка); "
        f"UNSURE = не видно/непонятно.\n"
        f"Будь осторожен: ставь FAIL только если ТОЧНО видишь нарушение. "
        f"Если сомневаешься — UNSURE.\n\n"
        f"Пункты:\n{checklist_block}"
    )
    try:
        resp = await ollama.generate(
            prompt, images=[img_b64], model=vision_model, temperature=0.1,
        )
    except Exception:
        return ("\n".join(hard_defects), hard_defects) if hard_defects else ("", [])
    if not resp:
        return ("\n".join(hard_defects), hard_defects) if hard_defects else ("", [])

    # Парсим вердикт: дефект = строка с явным FAIL.
    defects = []
    for line in resp.splitlines():
        s = line.strip()
        # ищем "<...>: FAIL — ..." (без UNSURE/OK)
        if re.search(r"\bFAIL\b", s, re.IGNORECASE) and not re.search(r"\bUNSURE\b", s, re.IGNORECASE):
            # вытащим пояснение после FAIL
            txt = re.sub(r"^.*?FAIL\b[:\-—\s]*", "", s, flags=re.IGNORECASE).strip()
            defects.append(txt[:120] if txt else s[:120])

    # Жёсткие дефекты (статичный экран) идут ПЕРВЫМИ — они достовернее vision
    all_defects = hard_defects + defects
    report = ("\n".join(hard_defects) + "\n" + resp[:1000]).strip() if hard_defects else resp[:1000]
    return report, all_defects[:6]
