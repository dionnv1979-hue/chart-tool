"""Nodes package — узлы LangGraph workflow."""
import hashlib
import json
import os
import re
import time

from app.agents.base import BaseAgent
from app.agents.prompts import AGENTS
from app.agents.registry import create_agent, critic_is_approved
from app.core.logger import get_logger
from app.core.workspace import promote, list_staging_projects
from app.graph.state import WorkflowState
from app.schemas.chat import AgentResultSchema, ToolStepSchema
from app.schemas.tool import SaveProjectParams
from app.services.ollama_service import OllamaService
from app.services.tool_service import ToolService

logger = get_logger(__name__)
from app.graph.nodes.helpers import _load_agent_models, _append_result
from app.graph.nodes.save import _confirm_update

def make_single_agent_node(ollama: OllamaService, tools: ToolService):
    async def node(state: WorkflowState) -> dict:
        agent_key = state.get("agent_key", "single")
        # Берём из state (загружено один раз в начале pipeline)
        agent_models = state.get("agent_models") or {}
        agent = create_agent(agent_key, ollama, tools,
                             model_override=agent_models.get(agent_key),
                             params=(state.get("agent_params") or {}).get(agent_key))
        run = await agent.run(
            user_msg=state["user_message"],
            history_text=state.get("history_text", ""),
            session_id=state["session_id"],
            images=state.get("images") or None,
            extra_context=(
                f"{state.get('project_context')}\n"
                if state.get("project_context") else ""
            ),
        )
        if run.needs_confirm():
            return _confirm_update(run, "confirm")
        return {
            "final_response": run.response,
            "final_type": "done",
            "results": _append_result(state, run.to_agent_result_schema()),
            "pending_action_id": None,
        }
    return node


# ── manager ───────────────────────────────────────────────────────────────────