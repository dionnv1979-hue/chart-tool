"""
Routing functions для LangGraph conditional edges.
Каждая функция принимает state и возвращает имя следующего узла.
"""
from app.core.config import settings
from app.graph.state import WorkflowState


def route_after_verifier(state: WorkflowState) -> str:
    """
    После Верификатора:
    - next_node == "critic_skip" → верификатор сделал hard reject, идём к Кодеру
    - иначе → к Критику (с фактами в контексте)
    """
    if state.get("next_node") == "critic_skip":
        return "coder"
    return "critic"


def route_after_critic(state: WorkflowState) -> str:
    """
    После Критика:
    - APPROVED → tester
    - Не APPROVED и не достигли лимита раундов → coder (снова)
    - Достигли лимита → tester (принудительно)
    """
    if state.get("critic_approved", False):
        return "tester"

    current_round = state.get("debate_round", 0)
    max_rounds = settings.debate_max_rounds

    if current_round >= max_rounds:
        # Исчерпали раунды — всё равно идём к тестеру
        return "tester"

    return "coder"


def route_after_human_approval(state: WorkflowState) -> str:
    """
    После human_approval_node:
    - Если pending_action_id есть → ждём confirm (workflow приостановлен)
    - Если нет → продолжаем к save_project или финишу
    """
    if state.get("pending_action_id"):
        # Workflow приостановлен, ждём /confirm от пользователя
        return "await_confirmation"
    # Подтверждение получено или не нужно
    return "save_project"


def route_single_or_pipeline(state: WorkflowState) -> str:
    """
    Начальный роутинг по mode:
    - single → single_agent
    - multi  → manager
    - debate → coder (дебаты начинаются с кодера)
    """
    mode = state.get("mode", "single")
    if mode == "multi":
        return "manager"
    if mode == "debate":
        return "coder"
    return "single_agent"


def route_after_any_agent(state: WorkflowState) -> str:
    """
    Универсальный роутер после любого агента.
    Проверяет нужно ли подтверждение (pending_action_id установлен).
    """
    if state.get("pending_action_id"):
        return "human_approval"
    return state.get("next_node") or "end"
