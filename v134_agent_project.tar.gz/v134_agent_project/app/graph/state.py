"""
LangGraph State — общее состояние которое передаётся между всеми узлами графа.
TypedDict обязателен для LangGraph.
Каждое поле обновляется нужным узлом и читается следующим.
"""
from typing import Any, Literal, Optional, TypedDict

from app.schemas.chat import AgentResultSchema, ToolStepSchema


class WorkflowState(TypedDict, total=False):
    """
    Состояние workflow.
    total=False: все поля опциональны при создании, обновляются по ходу.
    """

    # ── Входные данные ─────────────────────────────────────────────────────
    session_id: str
    user_message: str
    agent_key: str       # для single режима
    mode: str            # single | multi | debate | stream
    images: list[str]    # base64 изображения из запроса пользователя
    agent_models: dict   # override моделей {agent_key: model} — загружается один раз
    agent_params: dict   # override параметров {agent_key: {temperature, num_predict, max_steps}}
    project_context: str # AGENT_CONTEXT.md существующего проекта (если задача про него)
    prev_round_sig: str  # сигнатура ошибки прошлого repair-раунда (детект повтора)
    installed_packages: list  # пакеты установленные через pip_install в этой сессии
    project_name: str         # имя проекта от Архитектора — фиксируется один раз

    # ── История (форматированная строка для промпта) ─────────────────────
    history_text: str

    # ── Результаты агентов (накапливаются по pipeline) ───────────────────
    results: list[AgentResultSchema]

    # ── Текущий контекст между агентами ──────────────────────────────────
    # Передаётся от одного агента к следующему как extra_context
    current_context: str

    # ── Код (извлечённый из ответа Кодера) ───────────────────────────────
    current_code: str

    # ── Количество раундов дебатов ────────────────────────────────────────
    debate_round: int

    # ── Флаг одобрения от Критика ─────────────────────────────────────────
    critic_approved: bool

    # ── Условия выполнения проекта ────────────────────────────────────────
    required_files: list   # список файлов из плана Архитектора (заморожен)
    architecture_locked: bool  # архитектура зафиксирована — список файлов не меняется
    files_coverage: float  # доля написанных файлов (0.0–1.0)
    tests_passed: bool     # тесты прошли (или GUI — где тест = TIMEOUT)
    test_round: int        # счётчик раундов исправления после провала запуска
    tester_report: str     # программный вердикт smoke-теста (факт запуска)
    last_error_sig: str    # сигнатура прошлой ошибки (тип+файл) для error memory
    last_error_text: str   # хвост текста прошлой ошибки для persistent fix-memory
    static_round: int      # отдельный счётчик для дешёвых статических фиксов
                           # (полнота файлов + импорты) — не путать с debate_round

    # ── Верификатор (программная проверка факта) ──────────────────────────
    verifier_fact_report: str   # факт-отчёт: что требовал Архитектор vs что есть
    verifier_coverage: float    # покрытие 0.0–1.0 (вычислено программно)
    verifier_missing: list      # список файлов которых нет на диске и в ответе


    # ── Human approval state ──────────────────────────────────────────────
    # Когда агент хочет выполнить dangerous tool — workflow останавливается
    # и создаёт pending action. После подтверждения workflow продолжается.
    pending_action_id: Optional[str]
    pending_tool: Optional[str]
    pending_params: Optional[dict[str, Any]]
    pending_agent: Optional[str]
    pending_thought: str
    pending_steps: list[ToolStepSchema]
    # Промпт для возобновления после подтверждения
    resume_prompt: Optional[str]
    resume_step: int

    # ── Финальный результат ───────────────────────────────────────────────
    # Устанавливается последним узлом перед END
    final_response: Optional[str]
    final_type: Literal["done", "confirm", "multi_done", "multi_confirm", "debate", "error"]
    error_message: Optional[str]

    # ── Graph routing helpers ─────────────────────────────────────────────
    # Следующий узел (используется в conditional edges)
    next_node: Optional[str]
