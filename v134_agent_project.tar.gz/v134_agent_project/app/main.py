"""
FastAPI приложение — точка входа.
Lifespan управляет жизненным циклом всех синглтонов:
  startup  → init_db, register_all_tools, detect_model, docker_ensure_image, init_workflow
  shutdown → close_db, close_ollama
"""
# ── HOTFIX: несовместимость langchain 0.3.20 ↔ langchain-core 0.3.7x ────────
# langchain_core.globals.get_debug() обращается к langchain.debug, которого
# нет в старом пакете langchain → AttributeError на каждом ainvoke.
# Официальный обходной путь: задать атрибуты вручную ДО импортов langgraph.
# Безопасно при любых версиях (hasattr-проверки), лишним не будет никогда.
try:
    import langchain  # noqa: E402
    if not hasattr(langchain, "debug"):
        langchain.debug = False
    if not hasattr(langchain, "verbose"):
        langchain.verbose = False
    if not hasattr(langchain, "llm_cache"):
        langchain.llm_cache = None
except ImportError:
    pass

import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

from app.api import (
    chat_router,
    sessions_router,
    models_router,
    files_router,
    status_router,
    settings_router,
    events_router,
)
from app.core.config import settings
from app.core.constants import APP_NAME, APP_VERSION, SETTINGS_KEY_MODEL
from app.core.logger import get_logger, setup_logging
from app.graph.workflow import get_workflow
from app.memory.database import close_db, get_session_factory, init_db
from app.memory.repository import PendingActionRepository, SettingRepository
from app.sandbox.docker_runner import get_docker_runner
from app.infra.redis_client import close_redis, init_redis
from app.services.ollama_service import get_ollama_service
from app.services.tool_service import get_tool_service
from app.tools import discover_tools

logger = get_logger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager.
    Всё что до yield — startup.
    Всё что после — shutdown.
    """
    # ── Logging ───────────────────────────────────────────────────────────
    setup_logging(debug=settings.app_debug)
    logger.info(f"Starting {APP_NAME} v{APP_VERSION}")

    # ── Database ──────────────────────────────────────────────────────────
    logger.info("Initializing database...")
    await init_db()

    # ── Очистка просроченных pending actions ──────────────────────────────
    # При старте удаляем pending старше 24ч — защита от роста БД.
    try:
        from app.memory.repository import PendingActionRepository
        factory_tmp = get_session_factory()
        async with factory_tmp() as db_cleanup:
            cleaned = await PendingActionRepository(db_cleanup).cleanup_expired(max_age_hours=24)
            await db_cleanup.commit()
            if cleaned > 0:
                logger.info(f"Cleaned {cleaned} expired pending actions (>24h old)")
    except Exception as e:
        logger.warning(f"Pending cleanup skipped: {e}")

    # ── Redis (опционально) ────────────────────────────────────────────────
    redis_ok = await init_redis()
    if redis_ok:
        logger.info("Redis: pending store active")
    else:
        logger.info("Redis: using SQLite pending store (fallback)")

    # ── Tool Service ──────────────────────────────────────────────────────
    tool_service = get_tool_service()
    discover_tools()
    tool_service.register_from_registry()

    # ── Ollama Service ─────────────────────────────────────────────────────
    ollama_service = get_ollama_service()

    # Пробуем загрузить сохранённую модель из БД
    factory = get_session_factory()
    async with factory() as db:
        setting_repo = SettingRepository(db)
        saved_model = await setting_repo.get(SETTINGS_KEY_MODEL)
        if saved_model:
            ollama_service.current_model = saved_model
            logger.info(f"Restored saved model: {saved_model}")
        await db.commit()

    # Детектируем/проверяем модель в Ollama
    available = await ollama_service.detect_and_set_model()
    if not available:
        logger.warning(
            "Ollama недоступен при старте. Убедитесь что запущен: ollama serve"
        )

    # ── Docker Sandbox ─────────────────────────────────────────────────────
    docker_runner = get_docker_runner()
    await docker_runner.ensure_image()
    logger.info(f"Sandbox: {docker_runner.get_sandbox_info()}")

    # ── Projects directory ─────────────────────────────────────────────────
    os.makedirs(settings.projects_dir, exist_ok=True)
    logger.info(f"Projects dir: {settings.projects_dir}")

    # ── LangGraph Workflow ─────────────────────────────────────────────────
    # pending_repo_factory создаёт репозиторий с новой сессией при каждом вызове
    # (нужно т.к. узел human_approval вызывается внутри workflow не через DI)
    def pending_repo_factory() -> PendingActionRepository:
        # Примечание: эта сессия будет управляться внутри узла
        # В продакшне следует использовать отдельный session factory
        # Для текущей архитектуры SQLite это работает корректно
        from app.memory.database import get_session_factory as _get_factory
        _factory = _get_factory()
        # Возвращаем lazy wrapper — реальная сессия откроется при вызове
        class LazyRepo:
            """
            Каждый метод открывает короткую сессию и сразу закрывает.
            Нет висящих соединений (Gemini #6 fix).
            """
            async def save(self, *args, **kwargs):
                async with _factory() as s:
                    repo = PendingActionRepository(s)
                    result = await repo.save(*args, **kwargs)
                    await s.commit()
                    return result

            async def get_and_delete(self, *args, **kwargs):
                async with _factory() as s:
                    repo = PendingActionRepository(s)
                    result = await repo.get_and_delete(*args, **kwargs)
                    await s.commit()
                    return result

        return LazyRepo()

    get_workflow(
        ollama=ollama_service,
        tools=tool_service,
        pending_repo_factory=pending_repo_factory,
    )
    logger.info("LangGraph workflow initialized")

    # Восстанавливаем auto_approve из БД
    try:
        from app.core.auto_approve import set_auto_approve as _set_aa
        _aa_factory = get_session_factory()  # используем уже импортированный
        async with _aa_factory() as _db:
            _val = await SettingRepository(_db).get("auto_approve")
            if _val and _val.lower() in ("true", "1", "yes"):
                _set_aa(True)
                logger.info("auto_approve: включён (из БД)")
    except Exception:
        pass

    logger.info(f"Application ready. http://{settings.app_host}:{settings.app_port}")

    # ── IdleWorker: самообучение в простое ─────────────────────────────────
    try:
        from app.learning import idle_worker
        idle_worker.start(ollama_service)
        logger.info("IdleWorker: самообучение в простое активно (порог 10 мин)")
    except Exception as e:
        logger.warning(f"IdleWorker не запущен (некритично): {e}")

    # ── Yield — приложение работает ────────────────────────────────────────
    yield

    # ── Shutdown ───────────────────────────────────────────────────────────
    logger.info("Shutting down...")
    try:
        from app.learning import idle_worker as _iw
        await _iw.stop()
    except Exception:
        pass
    await ollama_service.close()
    await close_redis()
    await close_db()
    logger.info("Shutdown complete")


# ── FastAPI app ───────────────────────────────────────────────────────────────
app = FastAPI(
    title=APP_NAME,
    version=APP_VERSION,
    description="Multi-Agent System powered by Ollama + LangGraph",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── CORS ──────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Роутеры ───────────────────────────────────────────────────────────────────
app.include_router(chat_router)
app.include_router(sessions_router)
app.include_router(models_router)
app.include_router(files_router)
app.include_router(status_router)
app.include_router(settings_router)
app.include_router(events_router)

# ── Статические файлы ─────────────────────────────────────────────────────────
_STATIC_DIR = os.path.join(os.path.dirname(__file__), "ui", "static")
_TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), "ui", "templates")

if os.path.isdir(_STATIC_DIR):
    app.mount("/static", StaticFiles(directory=_STATIC_DIR), name="static")

# ── HTML страница ─────────────────────────────────────────────────────────────
@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def root():
    """Отдать index.html."""
    html_path = os.path.join(_TEMPLATES_DIR, "index.html")
    if os.path.isfile(html_path):
        with open(html_path, encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse(content="<h1>UI не найден</h1>", status_code=404)


# ── Точка запуска ─────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=settings.app_host,
        port=settings.app_port,
        reload=settings.app_debug,
        log_level="debug" if settings.app_debug else "info",
    )
