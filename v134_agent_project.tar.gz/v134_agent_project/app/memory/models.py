"""
SQLAlchemy ORM модели.
Определяют схему всех таблиц БД.
Не содержат бизнес-логики — только структуру данных.
"""
from datetime import datetime
from sqlalchemy import (
    Integer, String, Text, DateTime, ForeignKey
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    """Базовый класс для всех моделей."""
    pass


class Session(Base):
    """
    Сессия диалога.
    Группирует сообщения по session_id который генерируется на фронте.
    """
    __tablename__ = "sessions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(String(64), unique=True, nullable=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    # Связи
    messages: Mapped[list["Message"]] = relationship(
        "Message", back_populates="session_obj", cascade="all, delete-orphan"
    )
    pending_actions: Mapped[list["PendingAction"]] = relationship(
        "PendingAction", back_populates="session_obj", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Session id={self.session_id}>"


class Message(Base):
    """
    Сообщение в диалоге.
    role: 'user' или 'assistant'
    agent: ключ агента из app.agents.prompts.AGENTS ('single', 'coder', etc.)
    """
    __tablename__ = "messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("sessions.session_id", ondelete="CASCADE"),
        nullable=False, index=True
    )
    role: Mapped[str] = mapped_column(String(16), nullable=False)
    agent: Mapped[str] = mapped_column(String(32), nullable=False, default="user")
    content: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    # Связь обратно к сессии
    session_obj: Mapped["Session"] = relationship("Session", back_populates="messages")

    def __repr__(self) -> str:
        return f"<Message id={self.id} role={self.role} agent={self.agent}>"


class PendingAction(Base):
    """
    Pending action — ожидает подтверждения пользователя.
    Создаётся когда агент хочет выполнить DANGEROUS_TOOL.
    Хранит весь контекст для продолжения workflow после подтверждения.
    """
    __tablename__ = "pending_actions"

    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    session_id: Mapped[str] = mapped_column(
        String(64), ForeignKey("sessions.session_id", ondelete="CASCADE"),
        nullable=False, index=True
    )
    agent: Mapped[str] = mapped_column(String(32), nullable=False)
    tool: Mapped[str] = mapped_column(String(64), nullable=False)

    # JSON-сериализованные данные
    params_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
    prompt_text: Mapped[str] = mapped_column(Text, nullable=False, default="")
    response_so_far: Mapped[str] = mapped_column(Text, nullable=False, default="")
    steps_json: Mapped[str] = mapped_column(Text, nullable=False, default="[]")
    current_step: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Контекст graph workflow для восстановления после подтверждения
    graph_state_json: Mapped[str] = mapped_column(Text, nullable=False, default="{}")

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    # Связь
    session_obj: Mapped["Session"] = relationship("Session", back_populates="pending_actions")

    def __repr__(self) -> str:
        return f"<PendingAction id={self.id} tool={self.tool}>"


class Project(Base):
    """
    Сохранённый проект.
    Создаётся когда агент вызывает save_project.
    """
    __tablename__ = "projects"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(256), nullable=False, index=True)
    path: Mapped[str] = mapped_column(Text, nullable=False)
    session_id: Mapped[str] = mapped_column(String(64), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    def __repr__(self) -> str:
        return f"<Project id={self.id} name={self.name}>"


class Setting(Base):
    """
    Настройки приложения в БД.
    key-value хранилище. Например: ('model', 'qwen3:27b').
    """
    __tablename__ = "settings"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(Text, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    def __repr__(self) -> str:
        return f"<Setting key={self.key} value={self.value[:30]}>"
