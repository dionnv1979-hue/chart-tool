"""
Persistent fix-memory — запоминает УДАЧНЫЕ исправления между прогонами.

Идея (взято из разбора OpenJarvis, единственное с реальным ROI): когда система
один раз научилась чинить ошибку (напр. 'from board' → 'from core.board'),
не нужно переучиваться в каждом новом проекте. Храним пары:
   сигнатура_ошибки  →  что_сработало
и при повторе той же ошибки подсказываем Кодеру проверенный фикс.

Хранилище — простой JSON-файл рядом с Projects (без схемы БД, без миграций).
Полностью best-effort: любая ошибка чтения/записи тихо игнорируется и НИКОГДА
не ломает основной пайплайн. Память лишь ПОДСКАЗЫВАЕТ, не принуждает.

Универсально: сигнатура строится из типа ошибки + ключевого имени, без привязки
к конкретному проекту, поэтому опыт переносится между любыми задачами.
"""
from __future__ import annotations

import json
import os
import re
import time

from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)

_MAX_ENTRIES = 200   # не даём файлу расти бесконечно


def _store_path() -> str:
    """
    Файл памяти фиксов — в ПОСТОЯННОЙ папке, не зависящей от пересборки проекта.
    Пользователь часто пересобирает agent_project, поэтому память храним отдельно:
      Windows: C:\\Users\\<user>\\Desktop\\agent_memory\\fix_memory.json
      Прочие:  ~/agent_memory/fix_memory.json
    Если папку создать нельзя — откатываемся рядом с Projects (как раньше).
    """
    try:
        home = os.path.expanduser("~")
        # На Windows кладём на Desktop (пользователь работает там)
        desktop = os.path.join(home, "Desktop")
        base = desktop if os.path.isdir(desktop) else home
        mem_dir = os.path.join(base, "agent_memory")
        os.makedirs(mem_dir, exist_ok=True)
        return os.path.join(mem_dir, "fix_memory.json")
    except Exception:
        # Фолбэк: рядом с папкой проектов
        base = os.path.dirname(os.path.realpath(settings.projects_dir))
        return os.path.join(base, "agent_fix_memory.json")


def error_signature(error_text: str) -> str:
    """
    Строим устойчивую сигнатуру ошибки: тип + ключевое имя, БЕЗ путей/чисел/адресов.
    'ModuleNotFoundError: No module named 'board'' → 'ModuleNotFoundError:board'
    'TypeError: Game.update() missing... 'dt'' → 'TypeError:Game.update:dt'
    """
    if not error_text:
        return ""
    # последняя содержательная строка traceback
    last = ""
    for ln in reversed(error_text.strip().splitlines()):
        s = ln.strip()
        if s and not s.startswith("File ") and not s.startswith("^"):
            last = s
            break
    if not last:
        return ""
    etype = last.split(":")[0].strip()
    # вытаскиваем ключевые имена в кавычках/идентификаторы
    names = re.findall(r"'([\w\.]+)'", last)
    name_part = ":".join(names[:2])
    # имя метода вида Class.method(
    m = re.search(r"(\w+\.\w+)\(\)", last)
    if m and m.group(1) not in name_part:
        name_part = (name_part + ":" + m.group(1)) if name_part else m.group(1)
    sig = f"{etype}:{name_part}" if name_part else etype
    return sig[:120]


def _load() -> dict:
    path = _store_path()
    try:
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save(data: dict) -> None:
    path = _store_path()
    try:
        # обрезаем по возрасту/размеру — оставляем самые свежие
        if len(data) > _MAX_ENTRIES:
            items = sorted(data.items(), key=lambda kv: kv[1].get("ts", 0), reverse=True)
            data = dict(items[:_MAX_ENTRIES])
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
    except Exception as e:
        logger.warning(f"fix_memory save skipped: {e}")


# Ошибки ОКРУЖЕНИЯ, а не кода — их «фикс» это pip install, а не правка кода.
# Запоминать их как удачные фиксы вредно: в следующем проекте память увела бы
# Кодера править код вместо установки пакета. Известные сторонние пакеты:
_ENV_PACKAGES = {
    "pygame", "numpy", "pandas", "requests", "flask", "django", "fastapi",
    "pillow", "pil", "scipy", "matplotlib", "torch", "tensorflow", "cv2",
    "opencv", "pydantic", "sqlalchemy", "aiohttp", "httpx", "redis", "pytest",
    "selenium", "playwright", "bs4", "beautifulsoup4", "lxml", "pyyaml",
}


def _is_environment_error(error_text: str) -> bool:
    """True если ошибка про отсутствующий СТОРОННИЙ пакет (это pip, не код)."""
    m = re.search(r"No module named '([\w\.]+)'", error_text or "")
    if not m:
        return False
    pkg = m.group(1).split(".")[0].lower()
    return pkg in _ENV_PACKAGES


def _build_recipe(error_text: str) -> str:
    """
    Строит КОНКРЕТНЫЙ рецепт фикса по типу ошибки. Возвращает "" если ошибку
    нельзя свести к понятному действию (тогда память не пишется — это честнее,
    чем хранить бесполезную общую фразу).
    """
    if not error_text:
        return ""
    last = ""
    for ln in reversed(error_text.strip().splitlines()):
        s = ln.strip()
        if s and not s.startswith("File ") and not s.startswith("^"):
            last = s
            break
    if not last:
        return ""

    # NameError: name 'random' is not defined → добавить import/определение
    m = re.search(r"name '(\w+)' is not defined", last)
    if m:
        name = m.group(1)
        # частые стандартные модули — это забытый import
        if name in {"random", "math", "os", "sys", "time", "json", "re", "pygame"}:
            return f"NameError '{name}': добавить 'import {name}' в начало файла."
        return f"NameError '{name}': добавить импорт или определение '{name}' перед использованием."

    # ImportError: cannot import name 'X' from 'Y'
    m = re.search(r"cannot import name '(\w+)' from '([\w\.]+)'", last)
    if m:
        return (f"ImportError '{m.group(1)}' из '{m.group(2)}': проверить точное имя "
                f"в модуле и поправить импорт под реальное определение.")

    # ModuleNotFoundError: внутренний модуль (сторонние отсекаются раньше)
    m = re.search(r"No module named '([\w\.]+)'", last)
    if m:
        return (f"ModuleNotFoundError '{m.group(1)}': поправить путь импорта с учётом "
                f"папки-пакета (from core.{m.group(1)} import ...) или опечатку.")

    # TypeError: X() missing N required positional argument: 'arg'
    m = re.search(r"(\w+)\(\).*missing.*argument:?\s*'?(\w+)'?", last)
    if m:
        return (f"TypeError {m.group(1)}(): не хватает аргумента '{m.group(2)}' — "
                f"передать его в вызове или задать значение по умолчанию в сигнатуре.")

    # AttributeError: 'X' object has no attribute 'y'
    m = re.search(r"has no attribute '(\w+)'", last)
    if m:
        return (f"AttributeError '{m.group(1)}': проверить точное имя метода/поля "
                f"в исходном классе (опечатка или поле не инициализировано).")

    # Непонятная ошибка — НЕ запоминаем (пустая память лучше мусорной)
    return ""


def remember_fix(error_text: str, fix_hint: str = "") -> None:
    """
    Запомнить КОНКРЕТНЫЙ рецепт фикса для такой ошибки. Best-effort.
    Если рецепт построить нельзя (ошибка непонятна) — НЕ пишем (пустая память
    честнее мусорной). fix_hint можно передать явно, иначе строится по типу.
    """
    # Не запоминаем ошибки окружения (отсутствие pygame/numpy/...) — это не
    # код-фикс, а установка пакета. Иначе память подсказывала бы неверное.
    if _is_environment_error(error_text):
        logger.info("fix_memory: пропущена ошибка окружения (не код-фикс)")
        return
    recipe = fix_hint or _build_recipe(error_text)
    if not recipe:
        logger.info("fix_memory: рецепт неясен — не записываем (пустая память лучше мусора)")
        # Но сигнатуру запоминаем как НЕРЕШЁННУЮ — IdleWorker в простое
        # поищет рецепт в интернете (web_harvest).
        try:
            from app.learning.web_harvest import remember_unsolved
            remember_unsolved(error_text)
        except Exception:
            pass
        return
    sig = error_signature(error_text)
    if not sig:
        return
    data = _load()
    entry = data.get(sig, {"count": 0})
    entry["fix"] = recipe[:300]
    entry["count"] = entry.get("count", 0) + 1
    entry["ts"] = int(time.time())
    data[sig] = entry
    _save(data)
    logger.info(f"fix_memory: запомнен фикс для [{sig}]: {recipe[:60]}")


def recall_fix(error_text: str) -> str:
    """
    Вернуть подсказку по прошлому удачному фиксу для похожей ошибки, или "".
    Best-effort: при любой проблеме возвращает пустую строку.
    """
    if _is_environment_error(error_text):
        return ""   # ошибка окружения — память тут не поможет (нужен pip)
    sig = error_signature(error_text)
    if not sig:
        return ""
    try:
        data = _load()
        entry = data.get(sig)
        if entry and entry.get("fix"):
            return (
                f"\n💡 ПАМЯТЬ: похожую ошибку [{sig}] раньше чинили так:\n"
                f"{entry['fix']}\n"
                f"(сработало {entry.get('count', 1)} раз — попробуй тот же подход)\n"
            )
    except Exception:
        pass
    return ""
