"""
Инициализация базы данных.
Создаёт async engine, session factory и все таблицы.
Используется через dependency injection в FastAPI.

SQLite оптимизации:
- journal_mode=WAL: writer и readers могут работать одновременно
- busy_timeout=5000: ждать 5 сек перед "database is locked"
- synchronous=NORMAL: безопасно с WAL, быстрее чем FULL
- foreign_keys=ON: enforces FK constraints
"""
from typing import AsyncGenerator

from sqlalchemy import event
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    AsyncEngine,
    async_sessionmaker,
    create_async_engine,
)

from app.core.config import settings
from app.core.logger import get_logger
from app.memory.models import Base

logger = get_logger(__name__)

_engine: AsyncEngine | None = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


def _is_sqlite() -> bool:
    return "sqlite" in settings.database_url


def get_engine() -> AsyncEngine:
    """Возвращает существующий engine или создаёт новый."""
    global _engine
    if _engine is not None:
        return _engine

    engine_kwargs = {
        "echo": False,
        "pool_pre_ping": True,
    }

    if _is_sqlite():
        # SQLite-specific: один writer одновременно — пул больше 1 не помогает
        # ResultProxy и т.п. могут жить между запросами — pool_size=1 не годится
        # Используем дефолтный пул (NullPool для async — каждое соединение свежее)
        engine_kwargs["connect_args"] = {"check_same_thread": False, "timeout": 30}

    _engine = create_async_engine(settings.database_url, **engine_kwargs)

    if _is_sqlite():
        # PRAGMA на каждое новое соединение через event hook
        @event.listens_for(_engine.sync_engine, "connect")
        def _set_sqlite_pragma(dbapi_connection, _conn_record):
            cursor = dbapi_connection.cursor()
            cursor.execute("PRAGMA journal_mode=WAL")          # параллельное чтение/запись
            cursor.execute("PRAGMA synchronous=NORMAL")        # с WAL безопасно
            cursor.execute("PRAGMA busy_timeout=10000")        # ждать 10с при lock
            cursor.execute("PRAGMA foreign_keys=ON")           # включаем FK
            cursor.execute("PRAGMA temp_store=MEMORY")         # tmp в RAM
            cursor.close()

    logger.info(f"Database engine created: {settings.database_url}")
    return _engine


def get_session_factory() -> async_sessionmaker[AsyncSession]:
    global _session_factory
    if _session_factory is None:
        _session_factory = async_sessionmaker(
            bind=get_engine(),
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=False,
            autocommit=False,
        )
    return _session_factory


async def init_db() -> None:
    engine = get_engine()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database tables initialized")


async def close_db() -> None:
    global _engine
    if _engine is not None:
        await _engine.dispose()
        _engine = None
        logger.info("Database engine closed")


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency для FastAPI.
    Открывает короткую транзакцию — endpoint делает свои операции и сразу commit.
    Долгие операции (workflow) НЕ должны держать эту сессию открытой.
    """
    factory = get_session_factory()
    async with factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()
