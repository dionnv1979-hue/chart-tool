"""
Repository — единственное место для всех операций с БД.
Бизнес-логика не знает о SQLAlchemy — она работает только через Repository.
Dependency injection: Repository получает сессию снаружи.
"""
import json
from datetime import datetime, timedelta
from typing import Optional

from pydantic import BaseModel
from sqlalchemy import select, delete, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logger import get_logger
from app.memory.models import Message, PendingAction, Project, Session, Setting


class _StateEncoder(json.JSONEncoder):
    """
    JSON encoder для сериализации graph_state в SQLite pending store.
    Pydantic модели → dict через .model_dump().
    Остальные неизвестные типы → str.
    """
    def default(self, obj):
        if isinstance(obj, BaseModel):
            return obj.model_dump()
        try:
            return super().default(obj)
        except TypeError:
            return str(obj)

logger = get_logger(__name__)


class MessageRepository:
    """Операции с таблицей messages."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def save(
        self,
        session_id: str,
        role: str,
        agent: str,
        content: str,
    ) -> Message:
        """Сохранить сообщение. Автоматически создаёт Session если нет."""
        # Убеждаемся что Session запись существует
        await self._ensure_session(session_id)

        msg = Message(
            session_id=session_id,
            role=role,
            agent=agent,
            content=content,
        )
        self._db.add(msg)
        await self._db.flush()  # получаем id без commit
        logger.debug(f"Message saved: session={session_id} role={role} agent={agent}")
        return msg

    async def get_history(
        self,
        session_id: str,
        limit: int = 10,
    ) -> list[Message]:
        """
        Последние N сообщений сессии в хронологическом порядке.
        Возвращаем в порядке от старых к новым (для промпта агенту).
        """
        result = await self._db.execute(
            select(Message)
            .where(Message.session_id == session_id)
            .order_by(Message.id.desc())
            .limit(limit)
        )
        messages = result.scalars().all()
        return list(reversed(messages))

    async def get_history_for_api(
        self,
        session_id: str,
        limit: int = 50,
    ) -> list[Message]:
        """История для /history endpoint — больший лимит."""
        result = await self._db.execute(
            select(Message)
            .where(Message.session_id == session_id)
            .order_by(Message.id.asc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def delete_session_messages(self, session_id: str) -> int:
        """Удалить все сообщения сессии. Возвращает количество удалённых."""
        result = await self._db.execute(
            delete(Message).where(Message.session_id == session_id)
        )
        return result.rowcount

    async def cleanup_old(self, max_total: int) -> int:
        """
        Оставить только последние max_total записей.
        Возвращает количество удалённых.
        """
        # Находим id порога
        subq = (
            select(Message.id)
            .order_by(Message.id.desc())
            .limit(max_total)
            .scalar_subquery()
        )
        result = await self._db.execute(
            delete(Message).where(Message.id.not_in(subq))
        )
        deleted = result.rowcount
        if deleted > 0:
            logger.info(f"Cleaned up {deleted} old messages")
        return deleted

    async def _ensure_session(self, session_id: str) -> None:
        """Создаёт запись Session если не существует."""
        result = await self._db.execute(
            select(Session).where(Session.session_id == session_id)
        )
        if result.scalar_one_or_none() is None:
            session = Session(session_id=session_id)
            self._db.add(session)
            await self._db.flush()


class SessionRepository:
    """Операции с таблицей sessions."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def list_recent(self, limit: int = 20) -> list[str]:
        """Список session_id отсортированных по последней активности."""
        result = await self._db.execute(
            select(Message.session_id)
            .group_by(Message.session_id)
            .order_by(func.max(Message.id).desc())
            .limit(limit)
        )
        return [row[0] for row in result.all()]

    async def exists(self, session_id: str) -> bool:
        result = await self._db.execute(
            select(Session.id).where(Session.session_id == session_id)
        )
        return result.scalar_one_or_none() is not None

    async def delete(self, session_id: str) -> None:
        """Удалить сессию и всё связанное (cascade)."""
        await self._db.execute(
            delete(Session).where(Session.session_id == session_id)
        )


class PendingActionRepository:
    """Операции с pending_actions — ожидающие подтверждения."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def save(
        self,
        action_id: str,
        session_id: str,
        agent: str,
        tool: str,
        params: dict,
        prompt_text: str,
        response_so_far: str,
        steps: list,
        current_step: int,
        graph_state: dict,
    ) -> PendingAction:
        """Сохранить pending action. Upsert по action_id."""
        # Удаляем старую запись если есть
        await self._db.execute(
            delete(PendingAction).where(PendingAction.id == action_id)
        )

        action = PendingAction(
            id=action_id,
            session_id=session_id,
            agent=agent,
            tool=tool,
            params_json=json.dumps(params, ensure_ascii=False),
            prompt_text=prompt_text,
            response_so_far=response_so_far,
            steps_json=json.dumps(steps, ensure_ascii=False),
            current_step=current_step,
            graph_state_json=json.dumps(graph_state, cls=_StateEncoder, ensure_ascii=False),
        )
        self._db.add(action)
        await self._db.flush()
        logger.info(f"PendingAction saved: {action_id} tool={tool}")
        return action

    async def get_and_delete(self, action_id: str) -> Optional[dict]:
        """
        Атомарно: получить и удалить pending action.
        Возвращает dict с десериализованными данными или None если не найден.
        """
        result = await self._db.execute(
            select(PendingAction).where(PendingAction.id == action_id)
        )
        action = result.scalar_one_or_none()
        if action is None:
            logger.warning(f"PendingAction not found: {action_id}")
            return None

        data = {
            "id": action.id,
            "session_id": action.session_id,
            "agent": action.agent,
            "tool": action.tool,
            "params": json.loads(action.params_json),
            "prompt_text": action.prompt_text,
            "response_so_far": action.response_so_far,
            "steps": json.loads(action.steps_json),
            "current_step": action.current_step,
            "graph_state": json.loads(action.graph_state_json),
        }

        await self._db.delete(action)
        await self._db.flush()
        logger.info(f"PendingAction consumed: {action_id}")
        return data

    async def cleanup_expired(self, max_age_hours: int) -> int:
        """Удалить устаревшие pending actions."""
        cutoff = datetime.utcnow() - timedelta(hours=max_age_hours)
        result = await self._db.execute(
            delete(PendingAction).where(PendingAction.created_at < cutoff)
        )
        deleted = result.rowcount
        if deleted > 0:
            logger.info(f"Cleaned up {deleted} expired pending actions")
        return deleted


class ProjectRepository:
    """Операции с таблицей projects."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def save(self, name: str, path: str, session_id: str = "") -> Project:
        project = Project(name=name, path=path, session_id=session_id)
        self._db.add(project)
        await self._db.flush()
        logger.info(f"Project saved: {name} → {path}")
        return project

    async def list_recent(self, limit: int = 20) -> list[Project]:
        result = await self._db.execute(
            select(Project).order_by(Project.id.desc()).limit(limit)
        )
        return list(result.scalars().all())


class SettingRepository:
    """Операции с таблицей settings (key-value)."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def get(self, key: str) -> Optional[str]:
        result = await self._db.execute(
            select(Setting.value).where(Setting.key == key)
        )
        return result.scalar_one_or_none()

    async def set(self, key: str, value: str) -> None:
        result = await self._db.execute(
            select(Setting).where(Setting.key == key)
        )
        setting = result.scalar_one_or_none()
        if setting is None:
            self._db.add(Setting(key=key, value=value))
        else:
            setting.value = value
            setting.updated_at = datetime.utcnow()
        await self._db.flush()
        logger.debug(f"Setting saved: {key}={value}")

    async def get_all(self) -> dict[str, str]:
        result = await self._db.execute(select(Setting))
        return {s.key: s.value for s in result.scalars().all()}
