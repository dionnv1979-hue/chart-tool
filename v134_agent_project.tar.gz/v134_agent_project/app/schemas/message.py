"""
Pydantic схемы для сообщений и сессий.
Используются в API responses для /history, /sessions.
"""
from datetime import datetime
from typing import Literal, Optional
from pydantic import BaseModel, Field


class MessageSchema(BaseModel):
    """Сообщение для отдачи через API."""

    id: Optional[int] = None
    role: Literal["user", "assistant"]
    agent: str
    content: str
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class SessionSchema(BaseModel):
    """Информация о сессии."""

    session_id: str
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class ClearSessionRequest(BaseModel):
    """Запрос очистки сессии."""
    session: str = Field(..., min_length=1, max_length=64)


class ClearSessionResponse(BaseModel):
    """Ответ на очистку сессии."""
    ok: bool
    deleted_count: int = 0


class ProjectSchema(BaseModel):
    """Проект для отдачи через API."""

    id: Optional[int] = None
    name: str
    path: str
    session_id: Optional[str] = None
    created_at: Optional[datetime] = None

    model_config = {"from_attributes": True}


class HistoryResponse(BaseModel):
    """Ответ /history endpoint."""
    messages: list[MessageSchema]
    total: int


class SessionsResponse(BaseModel):
    """Ответ /sessions endpoint."""
    sessions: list[str]
