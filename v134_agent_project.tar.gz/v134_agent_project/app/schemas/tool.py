"""
Pydantic схемы для structured tool calling.
Каждый инструмент имеет свою схему входных параметров.
Это заменяет regex-парсинг из оригинала.
"""
from typing import Optional, Any
from pydantic import BaseModel, Field, field_validator
import re


class ReadFileParams(BaseModel):
    """Параметры инструмента read_file."""
    path: str = Field(..., min_length=1, max_length=1024, description="Путь к файлу")


class WriteFileParams(BaseModel):
    """Параметры инструмента write_file."""
    path: str = Field(..., min_length=1, max_length=1024, description="Путь к файлу в Projects")
    content: str = Field(..., max_length=1_000_000, description="Содержимое файла")


class ListFilesParams(BaseModel):
    """Параметры инструмента list_files."""
    path: Optional[str] = Field(default=None, max_length=1024, description="Путь к директории")


class RunPythonParams(BaseModel):
    """Параметры инструмента run_python."""
    code: str = Field(..., min_length=1, max_length=100_000, description="Python код для выполнения")
    project_dir: str = Field(
        default="",
        description=(
            "Необязательно. Путь к папке проекта (внутри Projects/) для запуска тестов "
            "с доступом к файлам проекта. Если указан — код запускается с PYTHONPATH=project_dir, "
            "можно писать 'from game import Game' вместо копирования классов. "
            "Пример: project_dir='TetrisGame'"
        )
    )


class WebSearchParams(BaseModel):
    """Параметры инструмента web_search."""
    query: str = Field(..., min_length=1, max_length=200, description="Поисковый запрос")


class SaveProjectParams(BaseModel):
    """Параметры инструмента save_project."""
    name: str = Field(
        ...,
        min_length=1,
        max_length=128,
        description="Название проекта (используется как имя папки)"
    )
    staging: bool = Field(
        default=False,
        description="Сохранить в .staging/<name>/ для тестирования перед финальным сохранением",
    )
    files: dict[str, str] = Field(
        ...,
        description="Словарь filename → content"
    )

    @field_validator("name")
    @classmethod
    def sanitize_name(cls, v: str) -> str:
        """Убираем опасные символы из имени проекта."""
        return re.sub(r"[^\w\-]", "_", v)

    @field_validator("files")
    @classmethod
    def validate_files(cls, v: dict) -> dict:
        if not v:
            raise ValueError("files не может быть пустым словарём")
        if len(v) > 100:
            raise ValueError("Слишком много файлов (максимум 100)")
        return v


class ToolCallSchema(BaseModel):
    """
    Structured tool call от LLM.
    LLM возвращает JSON вида:
        {"tool": "run_python", "params": {"code": "print(1+1)"}}
    Этот класс валидирует эту структуру.
    """
    tool: str = Field(..., description="Имя инструмента")
    params: dict[str, Any] = Field(default_factory=dict, description="Параметры инструмента")

    @field_validator("tool")
    @classmethod
    def validate_tool_name(cls, v: str) -> str:
        from app.core.constants import DANGEROUS_TOOLS, SAFE_TOOLS
        all_tools = DANGEROUS_TOOLS | SAFE_TOOLS
        if v not in all_tools:
            raise ValueError(f"Unknown tool: {v}. Available: {all_tools}")
        return v


# Маппинг имя инструмента → Pydantic схема параметров
TOOL_PARAM_SCHEMAS: dict[str, type[BaseModel]] = {
    "read_file": ReadFileParams,
    "write_file": WriteFileParams,
    "list_files": ListFilesParams,
    "run_python": RunPythonParams,
    "web_search": WebSearchParams,
    "save_project": SaveProjectParams,
}



class PipInstallParams(BaseModel):
    """Параметры для установки пакетов."""
    packages: list[str] = Field(
        ...,
        description="Список пакетов для установки. Например: ['requests', 'numpy==1.24.0']",
        min_length=1,
    )

    @field_validator("packages")
    @classmethod
    def validate_packages(cls, v: list[str]) -> list[str]:
        import re
        if not v:
            raise ValueError("Список пакетов не может быть пустым")
        for pkg in v:
            # Запрещаем URL-based пакеты (git+http, http://, file://)
            if any(pkg.startswith(p) for p in ("git+", "http://", "https://", "file://", "svn+", "hg+")):
                raise ValueError(f"URL-based пакеты запрещены: {pkg!r}")
            # Проверка формата имени
            clean = re.split(r"[=><!\[]", pkg)[0].strip()
            if not re.fullmatch(r"[a-zA-Z0-9_\-\.]+", clean):
                raise ValueError(f"Недопустимое имя пакета: {pkg!r}")
        return v



class RunScriptParams(BaseModel):
    """Параметры для run_script."""
    path: str = Field(..., description="Путь к .py файлу внутри Projects/")
    timeout: int = Field(default=30, ge=1, le=120, description="Таймаут в секундах")


class CheckPackageParams(BaseModel):
    """Параметры для check_package."""
    package: str = Field(..., description="Имя пакета для проверки", min_length=1)


class CreateDirParams(BaseModel):
    """Параметры для create_dir."""
    path: str = Field(..., description="Путь к папке внутри Projects/", min_length=1)



class RunCodeParams(BaseModel):
    """Параметры для run_code — универсального запуска кода."""
    language: str = Field(
        ...,
        description=(
            "Язык программирования: python, javascript, typescript, bash, "
            "powershell, php, ruby, go, rust, c, cpp, java, sql"
        ),
        min_length=1,
    )
    code: str = Field(..., description="Исходный код для выполнения", min_length=1)
    timeout: int = Field(default=30, ge=1, le=120, description="Таймаут в секундах")


def parse_and_validate_tool_call(raw: dict) -> tuple[str, BaseModel]:
    """
    Парсит и валидирует tool call из LLM ответа.

    Args:
        raw: dict с ключами 'tool' и 'params'

    Returns:
        (tool_name, validated_params_model)

    Raises:
        ValueError: если структура невалидна
    """
    call = ToolCallSchema.model_validate(raw)
    schema_class = TOOL_PARAM_SCHEMAS.get(call.tool)
    if schema_class is None:
        raise ValueError(f"No param schema for tool: {call.tool}")
    validated_params = schema_class.model_validate(call.params)
    return call.tool, validated_params
