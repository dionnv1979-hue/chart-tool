"""
Pydantic схемы для chat API.
Валидация входящих запросов и исходящих ответов.
"""
from typing import Any, Literal, Optional
from pydantic import BaseModel, Field, field_validator


class ChatRequest(BaseModel):
    """Запрос на /chat endpoint."""

    message: str = Field(
        ...,
        min_length=1,
        max_length=32_000,
        description="Текст сообщения пользователя",
    )
    agent: str = Field(
        default="single",
        description="Ключ агента: single, manager, coder, etc.",
    )
    session: str = Field(
        default="default",
        min_length=1,
        max_length=64,
        description="ID сессии диалога",
    )
    mode: Literal["single", "multi", "debate", "stream"] = Field(
        default="single",
        description="Режим: одиночный агент, pipeline, дебаты, стриминг",
    )

    # base64-encoded изображения (без data:... префикса)
    images: list[str] = Field(
        default_factory=list,
        description="base64 изображения для multimodal запроса",
    )

    @field_validator("agent")
    @classmethod
    def validate_agent(cls, v: str) -> str:
        from app.agents.prompts import AGENTS as AGENT_DEFINITIONS
        if v not in AGENT_DEFINITIONS:
            raise ValueError(f"Unknown agent: {v}. Valid: {list(AGENT_DEFINITIONS.keys())}")
        return v


class ToolStepSchema(BaseModel):
    """Один шаг выполнения инструмента агентом."""

    step: int
    tool: str
    params: dict[str, Any]
    result: str


class ConfirmRequest(BaseModel):
    """Запрос подтверждения/отклонения действия."""

    action_id: str = Field(..., min_length=1, max_length=64)
    approved: bool = Field(..., description="True — разрешить, False — отклонить")


class ConfirmResponse(BaseModel):
    """Ответ после обработки подтверждения."""

    type: Literal["done", "error"] = "done"
    response: str
    steps: list[ToolStepSchema] = Field(default_factory=list)
    agent: str = ""


class SingleAgentResponse(BaseModel):
    """Ответ одиночного агента."""

    type: Literal["done"] = "done"
    response: str
    steps: list[ToolStepSchema] = Field(default_factory=list)
    agent: str


class PendingConfirmResponse(BaseModel):
    """Ответ когда агент ждёт подтверждения опасного действия."""

    type: Literal["confirm"] = "confirm"
    action_id: str
    tool: str
    params: dict[str, Any]
    agent: str
    steps: list[ToolStepSchema] = Field(default_factory=list)
    thought: str = ""


class AgentResultSchema(BaseModel):
    """Результат одного агента в multi/debate режиме."""

    type: str = "done"
    agent: str
    response: str
    steps: list[ToolStepSchema] = Field(default_factory=list)
    round: Optional[int] = None
    label: Optional[str] = None


class MultiDoneResponse(BaseModel):
    """Ответ завершённого multi-pipeline."""

    type: Literal["multi_done"] = "multi_done"
    results: list[AgentResultSchema]


class MultiConfirmResponse(BaseModel):
    """Ответ multi-pipeline когда внутри нужно подтверждение."""

    type: Literal["multi_confirm"] = "multi_confirm"
    results: list[AgentResultSchema]
    pending: PendingConfirmResponse


class DebateResponse(BaseModel):
    """Ответ дебатного режима."""

    type: Literal["debate"] = "debate"
    results: list[AgentResultSchema]


class ErrorResponse(BaseModel):
    """Ошибка."""

    type: Literal["error"] = "error"
    response: str


# Union всех возможных ответов /chat endpoint
ChatResponse = (
    SingleAgentResponse
    | PendingConfirmResponse
    | MultiDoneResponse
    | MultiConfirmResponse
    | DebateResponse
    | ErrorResponse
)


class StreamChatRequest(BaseModel):
    """Запрос для /stream endpoint."""

    message: str = Field(..., min_length=1, max_length=32_000)
    agent: str = Field(default="single")
    session: str = Field(default="default", max_length=64)

    @field_validator("agent")
    @classmethod
    def validate_agent(cls, v: str) -> str:
        from app.agents.prompts import AGENTS as AGENT_DEFINITIONS
        if v not in AGENT_DEFINITIONS:
            raise ValueError(f"Unknown agent: {v}")
        return v
