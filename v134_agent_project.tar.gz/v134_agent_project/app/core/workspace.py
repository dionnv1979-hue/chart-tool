"""
WorkspaceManager — управляет staging областью для безопасной разработки.

Схема работы:
  1. Кодер пишет файлы в Projects/.staging/<project>/
  2. Тестер запускает файлы из .staging/<project>/  
  3. Критик проверяет (визуально или через тесты без GUI)
  4. После APPROVED → promote(): .staging/<project>/ → <project>/

Преимущества:
  - Projects/ содержит только РАБОЧИЙ код
  - Агенты могут итерировать и исправлять в staging
  - Чёткое разделение: staging = WIP, Projects/ = done
"""
import os
import shutil

from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)

_PROJECTS_DIR = os.path.realpath(settings.projects_dir)
_STAGING_DIR = os.path.join(_PROJECTS_DIR, ".staging")


def get_staging_dir() -> str:
    """Путь к корню staging области."""
    os.makedirs(_STAGING_DIR, exist_ok=True)
    return _STAGING_DIR


def get_project_staging_path(project_name: str) -> str:
    """Путь к staging папке конкретного проекта."""
    safe = "".join(c if c.isalnum() or c in "-_." else "_" for c in project_name)
    path = os.path.join(_STAGING_DIR, safe)
    os.makedirs(path, exist_ok=True)
    return path


def get_project_final_path(project_name: str) -> str:
    """Путь к финальной папке проекта."""
    safe = "".join(c if c.isalnum() or c in "-_." else "_" for c in project_name)
    return os.path.join(_PROJECTS_DIR, safe)


def promote(project_name: str) -> dict:
    """
    Перенести проект из staging в финальную папку.
    staging/<name>/ → <name>/

    Возвращает dict с результатом:
      {"ok": True, "path": "...", "files": [...]}
    """
    staging_path = os.path.join(_STAGING_DIR, project_name)
    if not os.path.exists(staging_path):
        # Ищем папку без точного совпадения имени
        for d in os.listdir(_STAGING_DIR):
            if d.lower() == project_name.lower():
                staging_path = os.path.join(_STAGING_DIR, d)
                project_name = d
                break
        else:
            return {"ok": False, "error": f"Staging не найден: {project_name}"}

    final_path = os.path.join(_PROJECTS_DIR, project_name)

    # Если финальная папка существует — удаляем старую версию
    if os.path.exists(final_path):
        shutil.rmtree(final_path)

    # Переносим (не копируем — staging очищается)
    shutil.copytree(staging_path, final_path)
    shutil.rmtree(staging_path)

    # Список файлов
    files = []
    for root, dirs, fnames in os.walk(final_path):
        # Пропускаем __pycache__
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        for fname in fnames:
            rel = os.path.relpath(os.path.join(root, fname), final_path)
            files.append(rel)

    logger.info(f"Promoted {project_name}: {len(files)} files → {final_path}")
    return {"ok": True, "path": final_path, "files": files}


def list_staging_projects() -> list[str]:
    """Список проектов в staging."""
    if not os.path.exists(_STAGING_DIR):
        return []
    return [d for d in os.listdir(_STAGING_DIR)
            if os.path.isdir(os.path.join(_STAGING_DIR, d))]


def cleanup_staging(project_name: str) -> bool:
    """Удалить проект из staging (например если отменили)."""
    path = os.path.join(_STAGING_DIR, project_name)
    if os.path.exists(path):
        shutil.rmtree(path)
        return True
    return False
