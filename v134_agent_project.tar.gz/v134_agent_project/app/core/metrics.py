"""
Observability — structured metrics для агентов, инструментов, sandbox.

Что собирается:
    agent.run   → agent, duration_ms, tokens_est, mode, session_id
    tool.call   → tool, duration_ms, success, dangerous
    sandbox.run → duration_ms, timed_out, blocked, docker

Доступ:
    from app.core.metrics import metrics
    async with metrics.agent_timer("coder", session_id) as m:
        result = await agent.run(...)
        m.tokens(len(result.response))

    data = metrics.snapshot()   # → dict с агрегатами

Endpoint /metrics отдаёт snapshot как JSON.

Хранится in-memory. При рестарте сбрасывается.
Для persistence → экспортировать в Prometheus / ClickHouse.
"""
import asyncio
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from dataclasses import dataclass, field

from app.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class AgentStat:
    """Статистика одного запуска агента."""
    agent: str
    session_id: str
    mode: str
    duration_ms: int = 0
    tokens_est: int = 0
    steps: int = 0
    success: bool = True
    ts: float = field(default_factory=time.monotonic)


@dataclass
class ToolStat:
    """Статистика одного вызова инструмента."""
    tool: str
    duration_ms: int = 0
    success: bool = True
    dangerous: bool = False
    ts: float = field(default_factory=time.monotonic)


@dataclass
class SandboxStat:
    """Статистика одного запуска sandbox."""
    duration_ms: int = 0
    timed_out: bool = False
    blocked: bool = False
    docker: bool = False
    ts: float = field(default_factory=time.monotonic)


class _AgentTimerContext:
    """Context manager для замера агента. Позволяет добавлять данные по ходу."""
    def __init__(self, stat: AgentStat, collector: "MetricsCollector"):
        self._stat = stat
        self._collector = collector
        self._start = time.monotonic()

    def tokens(self, n: int) -> None:
        self._stat.tokens_est = n

    def steps(self, n: int) -> None:
        self._stat.steps = n

    def fail(self) -> None:
        self._stat.success = False

    def _finish(self) -> None:
        self._stat.duration_ms = int((time.monotonic() - self._start) * 1000)
        self._collector._record_agent(self._stat)
        logger.info(
            f"[AGENT] {self._stat.agent} done",
            extra={
                "agent": self._stat.agent,
                "session_id": self._stat.session_id,
                "mode": self._stat.mode,
                "duration_ms": self._stat.duration_ms,
                "tokens_est": self._stat.tokens_est,
                "steps": self._stat.steps,
                "success": self._stat.success,
            },
        )


class MetricsCollector:
    """
    In-memory метрики с скользящим окном (последние 1000 записей).
    Thread-safe через asyncio.Lock.
    """

    def __init__(self, window: int = 1000) -> None:
        self._lock = asyncio.Lock()
        self._agents: deque[AgentStat] = deque(maxlen=window)
        self._tools: deque[ToolStat] = deque(maxlen=window)
        self._sandbox: deque[SandboxStat] = deque(maxlen=window)

    # ── Agent timing ──────────────────────────────────────────────────────────

    @asynccontextmanager
    async def agent_timer(
        self, agent: str, session_id: str = "", mode: str = "single"
    ):
        """
        Async context manager для замера агента.

        async with metrics.agent_timer("coder", session_id, mode) as m:
            result = await agent.run(...)
            m.tokens(len(result.response))
            m.steps(len(result.steps))
        """
        stat = AgentStat(agent=agent, session_id=session_id, mode=mode)
        ctx = _AgentTimerContext(stat, self)
        try:
            yield ctx
        except Exception:
            ctx.fail()
            raise
        finally:
            ctx._finish()

    # ── Tool timing ───────────────────────────────────────────────────────────

    def record_tool(self, tool: str, duration_ms: int, success: bool, dangerous: bool) -> None:
        stat = ToolStat(tool=tool, duration_ms=duration_ms, success=success, dangerous=dangerous)
        self._tools.append(stat)

    # ── Sandbox timing ────────────────────────────────────────────────────────

    @asynccontextmanager
    async def sandbox_timer(self, docker: bool = False):
        """
        async with metrics.sandbox_timer(docker=True) as s:
            result = await runner.run(code)
            if result.timed_out: s.timeout()
            if result.blocked: s.block()
        """
        stat = SandboxStat(docker=docker)
        start = time.monotonic()

        class _SandboxCtx:
            def timeout(self_): stat.timed_out = True
            def block(self_): stat.blocked = True

        ctx = _SandboxCtx()
        try:
            yield ctx
        finally:
            stat.duration_ms = int((time.monotonic() - start) * 1000)
            self._sandbox.append(stat)
            logger.info(
                "[SANDBOX] run",
                extra={
                    "duration_ms": stat.duration_ms,
                    "timed_out": stat.timed_out,
                    "blocked": stat.blocked,
                    "docker": stat.docker,
                },
            )

    # ── Internal ──────────────────────────────────────────────────────────────

    def _record_agent(self, stat: AgentStat) -> None:
        self._agents.append(stat)

    # ── Snapshot ──────────────────────────────────────────────────────────────

    def snapshot(self) -> dict:
        """
        Текущий срез метрик.
        Возвращает агрегаты по агентам, инструментам, sandbox.
        """
        def _agg(items, key_fn):
            groups: dict[str, list[int]] = defaultdict(list)
            for item in items:
                groups[key_fn(item)].append(item.duration_ms)
            return {
                k: {
                    "count": len(v),
                    "avg_ms": int(sum(v) / len(v)) if v else 0,
                    "max_ms": max(v) if v else 0,
                    "min_ms": min(v) if v else 0,
                }
                for k, v in groups.items()
            }

        agents_agg = _agg(list(self._agents), lambda s: s.agent)

        # Добавляем token/step avg
        for agent_key in agents_agg:
            agent_stats = [s for s in self._agents if s.agent == agent_key]
            tokens = [s.tokens_est for s in agent_stats if s.tokens_est]
            steps = [s.steps for s in agent_stats if s.steps]
            if tokens:
                agents_agg[agent_key]["avg_tokens"] = int(sum(tokens) / len(tokens))
            if steps:
                agents_agg[agent_key]["avg_steps"] = round(sum(steps) / len(steps), 1)

        tools_agg = _agg(list(self._tools), lambda s: s.tool)
        tool_errors = defaultdict(int)
        for s in self._tools:
            if not s.success:
                tool_errors[s.tool] += 1
        for t in tools_agg:
            tools_agg[t]["errors"] = tool_errors.get(t, 0)

        sandbox_list = list(self._sandbox)
        sandbox_agg = {}
        if sandbox_list:
            durations = [s.duration_ms for s in sandbox_list]
            sandbox_agg = {
                "count": len(sandbox_list),
                "avg_ms": int(sum(durations) / len(durations)),
                "max_ms": max(durations),
                "timeouts": sum(1 for s in sandbox_list if s.timed_out),
                "blocked": sum(1 for s in sandbox_list if s.blocked),
                "docker_runs": sum(1 for s in sandbox_list if s.docker),
            }

        return {
            "agents": agents_agg,
            "tools": tools_agg,
            "sandbox": sandbox_agg,
            "totals": {
                "agent_runs": len(self._agents),
                "tool_calls": len(self._tools),
                "sandbox_runs": len(self._sandbox),
            },
        }


# Синглтон
metrics = MetricsCollector()
