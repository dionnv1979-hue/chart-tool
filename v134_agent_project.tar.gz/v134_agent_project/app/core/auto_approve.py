"""
Глобальный переключатель автоподтверждения инструментов.

Когда включён (True) — все dangerous инструменты (pip_install, write_file,
save_project, run_script) выполняются БЕЗ запроса подтверждения.

Управляется через:
  POST /settings  {"key": "auto_approve", "value": "true"/"false"}
  GET  /settings  → возвращает текущее значение

Состояние хранится в памяти (сбрасывается при рестарте).
Для постоянного хранения — сохраняется в БД Settings.
"""
import threading

_lock = threading.Lock()
_auto_approve: bool = False


def is_auto_approve() -> bool:
    """Проверить включён ли auto-approve."""
    with _lock:
        return _auto_approve


def set_auto_approve(value: bool) -> None:
    """Включить/выключить auto-approve."""
    global _auto_approve
    with _lock:
        _auto_approve = value


def toggle_auto_approve() -> bool:
    """Переключить auto-approve. Возвращает новое значение."""
    global _auto_approve
    with _lock:
        _auto_approve = not _auto_approve
        return _auto_approve
