"""
Централизованная конфигурация приложения.
Все настройки читаются из переменных окружения с fallback на дефолты.
Pydantic BaseSettings автоматически валидирует типы и читает .env файл.
"""
from pydantic_settings import BaseSettings
from pydantic import Field
import os


class Settings(BaseSettings):
    # ── Ollama ──────────────────────────────────────────────────────────────
    ollama_base_url: str = Field(
        default="http://localhost:11434",
        description="Базовый URL Ollama API"
    )
    default_model: str = Field(
        default="qwen3-coder:30b",
        description="Модель по умолчанию если не выбрана другая"
    )
    num_ctx: int = Field(
        default=32768,
        description="Размер контекстного окна для Ollama"
    )
    num_gpu: int = Field(
        default=999,
        description="Количество слоёв модели на GPU (999 = все слои)"
    )
    num_predict: int = Field(
        default=16384,
        description=(
            "Максимум токенов в ОДНОМ ответе модели (≈60К символов). "
            "КРИТИЧНО: без лимита локальные модели иногда сваливаются в "
            "бесконечную генерацию (повторяют код по кругу) — был случай 890К "
            "символов за 2 часа. Лимит ОБЯЗАТЕЛЕН, но 8192 оказался мал: в логе "
            "v131 переписка renderer.py (30К симв.) обрезалась на полуслове и "
            "Кодер писал битый код. 16384 всё ещё жёстко обрывает зацикливание, "
            "но хватает на полный перезапис крупного файла. Снизить до 8192 "
            "можно, если включён write_file-guard на точечные правки. "
            "-1 = без лимита (НЕ рекомендуется)."
        )
    )
    num_thread: int = Field(
        default=min(os.cpu_count() or 8, 8),
        description="Количество потоков CPU"
    )
    temperature: float = Field(
        default=0.7,
        description="Температура генерации"
    )
    ollama_timeout: int = Field(
        default=900,
        description="Общий таймаут запроса к Ollama в секундах (жёсткий потолок на весь ответ)"
    )
    ollama_idle_timeout: int = Field(
        default=120,
        description="Таймаут простоя: если модель не прислала ни одного токена за это время — считаем зависшей и прерываем (живая модель шлёт токены непрерывно)"
    )

    # ── Database ─────────────────────────────────────────────────────────────
    database_url: str = Field(
        default="sqlite+aiosqlite:///./agent_memory.db",
        description="URL базы данных SQLAlchemy (async)"
    )

    # ── Projects ─────────────────────────────────────────────────────────────
    projects_dir: str = Field(
        default=os.path.join(os.path.expanduser("~"), "Projects"),
        description="Директория для сохранения проектов"
    )

    # ── Sandbox ───────────────────────────────────────────────────────────────
    sandbox_timeout: int = Field(
        default=15,
        description="Таймаут выполнения кода в sandbox (секунды)"
    )
    docker_image: str = Field(
        default="python:3.11-slim",
        description="Docker образ для sandbox"
    )
    sandbox_memory: str = Field(
        default="256m",
        description="Лимит памяти для Docker sandbox"
    )
    sandbox_cpus: str = Field(
        default="1.0",
        description="Лимит CPU для Docker sandbox"
    )

    # ── Web Search ────────────────────────────────────────────────────────────
    search_max_per_minute: int = Field(
        default=10,
        description="Максимум web_search запросов в минуту"
    )
    search_max_query_len: int = Field(
        default=200,
        description="Максимальная длина поискового запроса"
    )

    # ── Memory / Cleanup ─────────────────────────────────────────────────────
    max_messages_total: int = Field(
        default=10_000,
        description="Максимум строк в таблице messages"
    )
    max_pending_age_hours: int = Field(
        default=24,
        description="Возраст pending action после которого удаляется"
    )
    cleanup_interval_seconds: int = Field(
        default=3600,
        description="Интервал между автоматическими очистками БД"
    )
    history_limit: int = Field(
        default=100,
        description="Сколько последних сообщений подавать в контекст агенту"
    )

    # ── Agent pipeline ────────────────────────────────────────────────────────
    max_agent_steps: int = Field(
        default=30,
        description=(
            "Глобальный аварийный тормоз шагов агента. "
            "Реальные лимиты задаются в AgentConfig.max_steps для каждого агента. "
            "Используется как верхняя граница: min(role_steps, max_agent_steps)."
        )
    )
    max_agent_seconds: int = Field(
        default=1800,
        description=(
            "Бюджет времени на одного агента (wall-clock, секунды, по умолч. 30 мин). "
            "Кодер пишет ~170с на файл; для проекта в 10 файлов нужно ~1700с. "
            "Защищает от зависания, но даёт дописать большой проект. "
            "Если каждый шаг очень долгий (медленное железо) — снижай."
        )
    )
    debate_max_rounds: int = Field(
        default=3,
        description="Максимум раундов дебатов Кодер↔Критик"
    )

    # ── FastAPI ───────────────────────────────────────────────────────────────
    app_host: str = Field(default="0.0.0.0")
    app_port: int = Field(default=8000)
    app_debug: bool = Field(default=False)
    cors_origins: list[str] = Field(
        default=["http://localhost:8000", "http://127.0.0.1:8000"],
        description="Разрешённые CORS origins"
    )


    # ── Redis (опционально) ───────────────────────────────────────────────────
    redis_url: str = Field(
        default="",
        description="Redis URL. Пусто = Redis отключён, fallback на SQLite. "
                    "Пример: redis://localhost:6379/0"
    )

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


# Синглтон — импортируется во всех модулях
settings = Settings()