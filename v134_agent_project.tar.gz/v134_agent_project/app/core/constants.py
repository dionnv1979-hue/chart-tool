"""
Константы приложения.
Здесь живут неизменяемые определения: агенты, промпты, опасные инструменты.
Не импортировать из других app-модулей во избежание циклов.
"""
from typing import Final

# ── Определения агентов ───────────────────────────────────────────────────────
# Каждый агент: name, emoji, color, system_prompt
# AGENT_DEFINITIONS переехал в app/agents/prompts.py
# Добавить агента = добавить запись в AGENTS dict там.

DANGEROUS_TOOLS: Final[set] = {
    "write_file",
    "create_dir",
    "save_project",
}

# ── Безопасные инструменты — выполняются без подтверждения ───────────────────
SAFE_TOOLS: Final[set] = {
    "read_file",
    "list_files",
    "run_python",
    "web_search",
}

# ── AST: запрещённые имена для проверки кода перед sandbox ──────────────────
FORBIDDEN_BUILTINS: Final[set] = {
    "__import__", "exec", "eval", "compile", "open",
    "breakpoint", "input", "memoryview",
    "__builtins__", "__globals__", "__locals__",
    "__subclasses__", "__bases__", "__base__",
    "__mro__", "__code__", "__closure__",
    "globals", "locals", "vars", "dir",
    "getattr", "setattr", "delattr", "hasattr",
    "object", "type", "super",
}

FORBIDDEN_ATTRS: Final[set] = {
    "__class__", "__subclasses__", "__base__", "__bases__",
    "__mro__", "__globals__", "__builtins__", "__code__",
    "__closure__", "__dict__", "__module__",
    "__import__", "__reduce__", "__reduce_ex__",
}

FORBIDDEN_DANGER_PATTERNS: Final[list] = [
    # r"__\w+__" убран — блокировал __name__, unittest.main(), обычные методы
    r"\\x[0-9a-f]{2}",  # hex-escape (обфускация)
    r"chr\s*\(",          # chr() для обфускации (chr(101)+chr(118)+chr(97)+chr(108))
]

# ── Prelude для sandbox: безопасные stdlib модули ────────────────────────────
SANDBOX_SAFE_PRELUDE: Final[str] = (
    "import math, random, re, json, collections, "
    "itertools, statistics, decimal, fractions, unittest\n"
)

# ── Режимы работы чата ───────────────────────────────────────────────────────
CHAT_MODES: Final[set] = {"single", "multi", "debate", "stream"}

# ── Имена агентов в pipeline ─────────────────────────────────────────────────
PIPELINE_AGENTS: Final[list] = [
    "manager",
    "architect",
    "coder",
    "critic",
    "tester",
]

# ── Ключи настроек в БД ──────────────────────────────────────────────────────
SETTINGS_KEY_MODEL: Final[str] = "model"

# ── Лимит истории который отдаётся во /history endpoint ──────────────────────
HISTORY_API_LIMIT: Final[int] = 50

# ── Лимит проектов в /projects endpoint ──────────────────────────────────────
PROJECTS_API_LIMIT: Final[int] = 20

# ── Максимум сессий в списке ─────────────────────────────────────────────────
SESSIONS_LIST_LIMIT: Final[int] = 20

# ── Версия приложения ─────────────────────────────────────────────────────────
APP_VERSION: Final[str] = "2.0.0"
APP_NAME: Final[str] = "Qwen Multi-Agent System"
