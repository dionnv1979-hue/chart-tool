"""
Активное имя проекта для текущего прогона.

Проблема (#5): агенты создают папки-дубликаты — Архитектор называет проект
'TetrisGame', а Кодер пишет в 'Tetris/main.py'. Возникают две папки, Тестер
читает не ту, тратятся шаги.

Решение: пайплайн фиксирует каноническое имя (из PROJECT_NAME Архитектора),
а инструменты write_file/save_project нормализуют ПЕРВЫЙ сегмент пути к этому
имени. Это не ломает универсальность: меняется только имя корневой папки
проекта, структура файлов внутри — любая.

Состояние в памяти, сбрасывается между прогонами (set_active_project(None)).
Зеркалит паттерн auto_approve.py.
"""
import os
import threading

_lock = threading.Lock()
_active_project: str | None = None
# Режим починки по traceback: разрешает write_file умеренно уменьшать файл
# (точечный фикс может убрать строки). Regression guard смягчается, но всё
# равно блокирует ЭКСТРЕМАЛЬНУЮ деградацию (выпотрошить файл).
_fix_mode: bool = False


def set_fix_mode(enabled: bool) -> None:
    """Включить/выключить режим починки (смягчает regression guard)."""
    global _fix_mode
    with _lock:
        _fix_mode = bool(enabled)


def get_fix_mode() -> bool:
    """Активен ли режим починки по traceback."""
    with _lock:
        return _fix_mode


# ── Разрыв клинча write_file↔str_replace ──────────────────────────────────
# Когда Кодер застревает (str_replace не находит И write_file блокируется
# regression guard'ом на одном файле), даём ОДНОРАЗОВОЕ разрешение переписать
# этот файл целиком — иначе цикл не разорвать. Токен снимается после 1 записи.
_force_rewrite: set[str] = set()


def allow_force_rewrite(path: str) -> None:
    """Разрешить один полный перезапис файла (разрыв клинча)."""
    with _lock:
        _force_rewrite.add(os.path.basename(path or ""))


def consume_force_rewrite(path: str) -> bool:
    """Проверить и снять разрешение на перезапись (одноразовое)."""
    base = os.path.basename(path or "")
    with _lock:
        if base in _force_rewrite:
            _force_rewrite.discard(base)
            return True
        return False


def set_active_project(name: str | None) -> None:
    """Зафиксировать каноническое имя проекта (или сбросить через None)."""
    global _active_project
    with _lock:
        _active_project = (name or "").strip() or None


# ── Read-before-edit + чеклист файлов (дисциплина Claude Code) ──────────────
# 1. Read-tracking: str_replace на файл, который агент НЕ читал в этом прогоне,
#    блокируется с подсказкой. Слепые правки по памяти — главный источник
#    промахов old_str.
# 2. Чеклист: required_files Архитектора = задачи; write_file отмечает
#    выполненное; прогресс виден агенту в каждом tool result и юзеру в UI.
#    Без LLM — чисто программно, task-agnostic.
_files_read: set[str] = set()          # basename'ы прочитанных в прогоне
_checklist: dict[str, bool] = {}       # basename → записан?
_checklist_order: list[str] = []       # порядок как у Архитектора


def _base(path: str) -> str:
    return os.path.basename((path or "").replace("\\", "/").rstrip("/")).lower()


def reset_run_tracking() -> None:
    """Сброс трекинга в начале прогона (вызывается из chat.py)."""
    global _files_read, _checklist, _checklist_order
    with _lock:
        _files_read = set()
        _checklist = {}
        _checklist_order = []


def mark_file_read(path: str) -> None:
    """Отметить файл прочитанным (вызывается из read_file)."""
    b = _base(path)
    if b:
        with _lock:
            _files_read.add(b)


def was_file_read(path: str) -> bool:
    """Читал ли агент этот файл в текущем прогоне."""
    with _lock:
        return _base(path) in _files_read


def set_checklist(files: list[str]) -> None:
    """Зафиксировать чеклист файлов (вызывается из architect node)."""
    global _checklist, _checklist_order
    with _lock:
        _checklist_order = [_base(f) for f in files if _base(f)]
        _checklist = {b: False for b in _checklist_order}


def mark_file_written(path: str) -> None:
    """Отметить файл записанным (вызывается из write_file)."""
    b = _base(path)
    with _lock:
        if b in _checklist:
            _checklist[b] = True


def checklist_progress() -> tuple[int, int, list[str]]:
    """(сделано, всего, оставшиеся). (0,0,[]) если чеклист не активен."""
    with _lock:
        if not _checklist:
            return 0, 0, []
        done = sum(1 for v in _checklist.values() if v)
        remaining = [b for b in _checklist_order if not _checklist[b]]
        return done, len(_checklist), remaining


def progress_line() -> str:
    """Готовая строка прогресса для tool result, или '' если чеклист пуст."""
    done, total, remaining = checklist_progress()
    if total == 0:
        return ""
    if not remaining:
        return f"📋 Прогресс: {done}/{total} — ВСЕ файлы записаны. Вызывай save_project."
    show = ", ".join(remaining[:6]) + ("…" if len(remaining) > 6 else "")
    return f"📋 Прогресс: {done}/{total} | Осталось: {show}"


def get_active_project() -> str | None:
    """Текущее каноническое имя проекта, либо None если не зафиксировано."""
    with _lock:
        return _active_project


def canonicalize_path(user_path: str) -> str:
    """
    Привести первый сегмент пути к каноническому имени проекта.

    Если активное имя не задано — путь возвращается без изменений (универсально:
    одиночные запросы и не-проектные задачи работают как раньше).

    Примеры (active='TetrisGame'):
        'Tetris/main.py'      → 'TetrisGame/main.py'   (заменили дублирующее имя)
        'main.py'             → 'TetrisGame/main.py'   (добавили корень)
        'TetrisGame/ui.py'    → 'TetrisGame/ui.py'     (уже верно)
        'src/main.py'         → 'TetrisGame/src/main.py' если src похоже на подпапку?
                                 НЕТ — см. логику ниже: трогаем только верхний
                                 сегмент, если он выглядит как имя-проекта.

    Логика консервативна: переименовываем верхний сегмент ТОЛЬКО если он
    отличается от канонического и не является очевидной подпапкой проекта.
    """
    active = get_active_project()
    if not active:
        return user_path

    cleaned = user_path.replace("\\", "/").lstrip("./")
    # Срезаем возможный префикс Projects/
    for prefix in ("Projects/", "projects/"):
        if cleaned.startswith(prefix):
            cleaned = cleaned[len(prefix):]
            break

    if not cleaned:
        return user_path

    parts = cleaned.split("/")

    # Файл без папки → кладём в корень проекта
    if len(parts) == 1:
        return f"{active}/{parts[0]}"

    top = parts[0]
    # Уже правильный корень — ничего не делаем
    if top == active:
        return cleaned

    # Верхний сегмент совпадает с активным именем без учёта регистра/разделителей
    # ('tetris_game' vs 'TetrisGame') — нормализуем к каноническому.
    def _norm(s: str) -> str:
        return s.lower().replace("_", "").replace("-", "").replace(" ", "")

    if _norm(top) == _norm(active):
        return "/".join([active] + parts[1:])

    # Известные generic-подпапки — это НЕ дубликат имени проекта.
    _COMMON_SUBDIRS = {
        "src", "app", "lib", "api", "tests", "test", "assets", "static",
        "templates", "docs", "config", "core", "utils", "models", "views",
        "components", "public", "build", "dist", "scripts", "data", "bin",
    }
    if "." not in top and top.lower() not in _COMMON_SUBDIRS:
        # top похож на укороченное имя проекта (модель отбросила слово):
        # 'Tetris' для 'TetrisGame'. Признак — нормализованный top это префикс
        # активного имени (или наоборот) и достаточно длинный (>3 симв).
        nt, na = _norm(top), _norm(active)
        if len(nt) >= 4 and (na.startswith(nt) or nt.startswith(na)):
            return "/".join([active] + parts[1:])

    # Иначе top — легитимная подпапка → префиксуем корнём проекта, не заменяя.
    return "/".join([active] + parts)
