"""
EventBus — шина событий для real-time стриминга прогресса агентов.

Схема:
  BaseAgent.run() → EventBus.emit() → asyncio.Queue per session
  GET /events/{session_id} → читает Queue → SSE stream → UI

Типы событий:
  pipeline_start   — пайплайн начался, список агентов
  agent_start      — агент начал работу
  agent_thinking   — агент генерирует ответ (LLM запрос)
  agent_thought    — мысль агента: что он решил сделать и зачем (текст до tool call)
  tool_call        — агент вызывает инструмент
  tool_result      — результат инструмента
  agent_done       — агент завершил работу
  pipeline_done    — весь пайплайн завершён
  approval_needed  — нужно подтверждение пользователя
  error            — ошибка
"""
import asyncio
import json
import time
from typing import Any

from app.core.logger import get_logger

logger = get_logger(__name__)

# ── Хранилище очередей: session_id → Queue ────────────────────────────────────
# Каждый запрос получает свою очередь. Очередь живёт пока есть подписчик.
_queues: dict[str, asyncio.Queue] = {}
_QUEUE_MAX_SIZE = 100  # не накапливаем больше N событий


def get_or_create_queue(session_id: str) -> asyncio.Queue:
    """Получить или создать очередь для сессии."""
    if session_id not in _queues:
        _queues[session_id] = asyncio.Queue(maxsize=_QUEUE_MAX_SIZE)
        logger.debug(f"EventBus: queue created for {session_id}")
    return _queues[session_id]


def remove_queue(session_id: str) -> None:
    """Удалить очередь (вызывается когда SSE соединение закрыто)."""
    _queues.pop(session_id, None)
    logger.debug(f"EventBus: queue removed for {session_id}")


def has_subscriber(session_id: str) -> bool:
    """Есть ли активный SSE подписчик для сессии."""
    return session_id in _queues


async def emit(session_id: str, event_type: str, **data: Any) -> None:
    """
    Отправить событие в очередь сессии.
    Если подписчика нет — событие молча игнорируется (не блокирует агента).
    """
    if session_id not in _queues:
        return
    queue = _queues[session_id]
    event = {
        "type": event_type,
        "ts": round(time.time() * 1000),  # milliseconds
        **data,
    }
    try:
        queue.put_nowait(event)
    except asyncio.QueueFull:
        # Если UI не успевает читать — пропускаем событие (не блокируем агента)
        logger.warning(f"EventBus: queue full for {session_id}, dropping event {event_type}")


async def event_generator(session_id: str):
    """
    Async generator для SSE.
    Читает из очереди и yield-ит SSE-formatted строки.

    Завершается когда приходит событие типа 'pipeline_done' или 'error'.
    """
    queue = get_or_create_queue(session_id)
    sentinel_types = {"pipeline_done", "error"}
    timeout = 300  # 5 минут максимум

    start = time.time()
    try:
        # Heartbeat каждые 15 секунд чтобы соединение не закрылось
        while True:
            if time.time() - start > timeout:
                yield _sse_format({"type": "timeout", "message": "Превышено время ожидания"})
                break

            try:
                event = await asyncio.wait_for(queue.get(), timeout=15.0)
                yield _sse_format(event)
                if event.get("type") in sentinel_types:
                    break
            except asyncio.TimeoutError:
                # Heartbeat — держим соединение живым
                yield ": heartbeat\n\n"
    finally:
        remove_queue(session_id)


def _sse_format(data: dict) -> str:
    """Форматировать словарь как SSE сообщение."""
    return f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
