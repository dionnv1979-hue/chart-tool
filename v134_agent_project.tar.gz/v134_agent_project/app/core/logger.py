"""
Централизованная настройка логирования.
Используем structlog для структурированных логов.
Все модули импортируют get_logger() отсюда.
"""
import logging
import logging.handlers
import sys
from typing import Any


def setup_logging(debug: bool = False) -> None:
    """
    Настраивает корневой logger.
    Пишет и в консоль и в файл logs/app.log.
    Вызывается один раз при старте приложения из main.py.
    """
    import os
    level = logging.DEBUG if debug else logging.INFO

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # ── Console handler ───────────────────────────────────────────────────
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    console_handler.setLevel(level)

    # ── File handler → logs/app.log ───────────────────────────────────────
    logs_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "logs")
    os.makedirs(logs_dir, exist_ok=True)
    log_file = os.path.join(logs_dir, "app.log")

    file_handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=10 * 1024 * 1024,  # 10 MB — потом создаёт новый файл
        backupCount=5,               # хранит 5 последних файлов
        encoding="utf-8",
    )
    file_handler.setFormatter(formatter)
    file_handler.setLevel(level)

    root_logger = logging.getLogger()
    root_logger.setLevel(level)

    # Убираем дублирующие handlers если setup вызван повторно
    root_logger.handlers.clear()
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)

    # Приглушаем слишком болтливые библиотеки
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)

    root_logger.info(f"Logging started → {log_file}")


def get_logger(name: str) -> logging.Logger:
    """
    Возвращает logger с заданным именем.
    Использование:
        from app.core.logger import get_logger
        logger = get_logger(__name__)
        logger.info("Сообщение", extra={"key": "value"})
    """
    return logging.getLogger(name)


class AgentLogger:
    """
    Обёртка для логирования действий агента с контекстом сессии.
    Удобна внутри агентов и graph nodes.
    """

    def __init__(self, agent_name: str, session_id: str) -> None:
        self._logger = get_logger(f"agent.{agent_name}")
        self._session = session_id
        self._agent = agent_name

    def _extra(self, **kwargs: Any) -> dict:
        return {"session": self._session, "agent": self._agent, **kwargs}

    def info(self, message: str, **kwargs: Any) -> None:
        self._logger.info(
            f"[{self._agent}] {message}",
            extra=self._extra(**kwargs),
        )

    def debug(self, message: str, **kwargs: Any) -> None:
        self._logger.debug(
            f"[{self._agent}] {message}",
            extra=self._extra(**kwargs),
        )

    def warning(self, message: str, **kwargs: Any) -> None:
        self._logger.warning(
            f"[{self._agent}] {message}",
            extra=self._extra(**kwargs),
        )

    def error(self, message: str, **kwargs: Any) -> None:
        self._logger.error(
            f"[{self._agent}] {message}",
            extra=self._extra(**kwargs),
        )

    def tool_call(self, tool_name: str, params: dict) -> None:
        self._logger.info(
            f"[{self._agent}] TOOL CALL: {tool_name}",
            extra=self._extra(tool=tool_name, params=str(params)[:200]),
        )

    def tool_result(self, tool_name: str, result: str) -> None:
        self._logger.info(
            f"[{self._agent}] TOOL RESULT: {tool_name} → {result[:100]}",
            extra=self._extra(tool=tool_name),
        )

    def step(self, step_number: int, total: int) -> None:
        self._logger.debug(
            f"[{self._agent}] Step {step_number}/{total}",
            extra=self._extra(step=step_number, total=total),
        )
