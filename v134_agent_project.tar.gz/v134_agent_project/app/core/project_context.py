"""
Project Context — чтение AGENT_CONTEXT.md при повторном обращении к проекту.

Замыкает цикл v109: save_project ПИШЕТ контракт (PROJECT_NAME, STRUCTURE,
ENTRY, KNOWN_PACKAGES, LAST_FIX), а этот модуль ЧИТАЕТ его при новой задаче.
"Добавь звук в Тетрис" → Архитектор получает проверенную структуру вместо
планирования с нуля; Кодер — known packages и последний фикс.

Матчинг (без LLM):
  1. СИЛЬНЫЙ: PROJECT_NAME (или его нормализованная форма) встречается в
     тексте задачи → этот контракт + можно сразу зафиксировать active_project.
  2. СЛАБЫЙ: пересечение ключевых слов задачи с "Описание задачи" контракта
     (>=2 слова) → контракт подмешивается, но имя НЕ фиксируется (Архитектор
     сам решит, доработка это или новый проект).

Best-effort: любая ошибка → пустая строка, пайплайн не страдает.
"""
from __future__ import annotations

import os
import re

from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)

_MAX_DIRS_SCAN = 40
_MAX_CONTEXT_CHARS = 1500


def _norm(s: str) -> str:
    return re.sub(r"[_\-\s]", "", s.lower())


_RU_SUFFIXES = sorted(
    ["иями", "ями", "ами", "ого", "его", "ому", "ему", "ыми", "ими",
     "ой", "ей", "ом", "ем", "ах", "ях", "ов", "ев", "ие", "ые", "ия",
     "ью", "ью", "и", "ы", "а", "я", "о", "е", "у", "ю", "ь"],
    key=len, reverse=True,
)


def _stem(word: str) -> str:
    """Лёгкий стемминг: срезаем типовое окончание если основа >= 3 символов.
    'очки'/'очками' → 'очк'; 'тетрис' → 'тетрис'. Без библиотек, для матчинга."""
    w = word.lower()
    for suf in _RU_SUFFIXES:
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            return w[: -len(suf)]
    return w


def _stems(words) -> set[str]:
    return {_stem(w) for w in words}


def find_project_context(user_message: str) -> tuple[str, str]:
    """
    Найти подходящий AGENT_CONTEXT.md для задачи.
    Возвращает (project_name | "", блок_для_промпта | "").
    project_name непустой ТОЛЬКО при сильном матче по имени —
    тогда вызывающий может зафиксировать active_project.
    """
    try:
        projects_dir = os.path.realpath(settings.projects_dir)
        if not os.path.isdir(projects_dir):
            return "", ""

        msg_norm = _norm(user_message)
        # Ключевые слова задачи для слабого матча
        from app.learning.lessons import extract_keywords
        task_kw = set(extract_keywords(user_message, limit=10))

        best_name, best_block, best_score, strong = "", "", 0, False
        scanned = 0
        for entry in sorted(os.listdir(projects_dir)):
            if scanned >= _MAX_DIRS_SCAN:
                break
            ctx_path = os.path.join(projects_dir, entry, "AGENT_CONTEXT.md")
            if not os.path.isfile(ctx_path):
                continue
            scanned += 1
            try:
                with open(ctx_path, encoding="utf-8") as f:
                    content = f.read(4000)
            except Exception:
                continue

            m = re.search(r"PROJECT_NAME:\s*([\w\-\.]+)", content)
            pname = m.group(1).strip() if m else entry

            # Сильный матч: имя проекта в тексте задачи
            if len(_norm(pname)) >= 4 and _norm(pname) in msg_norm:
                logger.info(f"project_context: сильный матч по имени [{pname}]")
                return pname, _format_block(pname, content, strong=True)

            # Слабый матч: СТЕММЫ ключевых слов задачи vs описание в контракте
            # (стемминг: 'очки'/'очками' считаются одним словом)
            dm = re.search(r"## Описание задачи\n(.{10,300})", content, re.DOTALL)
            if dm and task_kw:
                ctx_kw = set(extract_keywords(dm.group(1), limit=10))
                score = len(_stems(task_kw) & _stems(ctx_kw))
                if score > best_score:
                    best_name, best_score = pname, score
                    best_block = _format_block(pname, content, strong=False)

        if best_score >= 2:
            logger.info(f"project_context: слабый матч [{best_name}] score={best_score}")
            return "", best_block  # имя не фиксируем — пусть решает Архитектор
        return "", ""
    except Exception as e:
        logger.warning(f"project_context skipped: {e}")
        return "", ""


def _format_block(pname: str, content: str, strong: bool) -> str:
    head = (
        "📂 СУЩЕСТВУЮЩИЙ ПРОЕКТ — контракт с прошлого прогона "
        f"({'задача явно про него' if strong else 'возможно про него'}):\n"
    )
    tail = (
        "\nЕсли задача — ДОРАБОТКА этого проекта: сохрани PROJECT_NAME и "
        "структуру как есть, меняй только нужное. Если это НОВАЯ задача — "
        "игнорируй контракт.\n"
    )
    return head + content[:_MAX_CONTEXT_CHARS] + tail


__all__ = ["find_project_context"]
