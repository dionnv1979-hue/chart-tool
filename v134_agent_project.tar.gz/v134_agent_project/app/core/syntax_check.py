"""
Мультиязычная мгновенная проверка синтаксиса после записи/правки файла.

Раньше verify был Python-only (ast.parse). Теперь реестр чекеров:
  .py            → ast.parse (stdlib)
  .json          → json.loads (stdlib)
  .js .mjs .cjs  → node --check (если node установлен; нет — пропуск)
  .yaml .yml     → yaml.safe_load (если pyyaml установлен; нет — пропуск)
  прочее         → пропуск (знание языка — в модели, проверка — best-effort)

Возвращает "" если ок/нет чекера, иначе блок с ошибкой и инструкцией
"ИСПРАВЬ СЕЙЧАС" — агент чинит следующим шагом, не дожидаясь smoke-раунда.
"""
from __future__ import annotations

import json
import shutil
import subprocess

from app.core.logger import get_logger

logger = get_logger(__name__)

_node_path: str | None | bool = False  # False = не проверяли, None = нет


def _node() -> str | None:
    """Путь к node с кэшированием (which один раз за процесс)."""
    global _node_path
    if _node_path is False:
        _node_path = shutil.which("node")
        if _node_path:
            logger.info(f"syntax_check: node найден ({_node_path}) — JS-проверка активна")
    return _node_path


def _ctx_lines(content: str, line_no: int) -> str:
    lines = content.split("\n")
    lo, hi = max(0, line_no - 3), min(len(lines), line_no + 2)
    return "\n".join(f"{i+1:4}| {lines[i]}" for i in range(lo, hi))


def _fail(path_label: str, line_no: int, msg: str, content: str) -> str:
    return (
        f"\n⚠️ Синтаксическая ошибка после записи ({path_label}): "
        f"строка {line_no}: {msg}\n{_ctx_lines(content, line_no)}\n"
        f"ИСПРАВЬ СЕЙЧАС следующим шагом — не переходи к другим файлам "
        f"пока этот сломан."
    )


def _check_python(path: str, content: str) -> str:
    import ast
    try:
        ast.parse(content)
        return ""
    except SyntaxError as e:
        return _fail("Python", e.lineno or 0, e.msg or "invalid syntax", content)


def _check_json(path: str, content: str) -> str:
    try:
        json.loads(content)
        return ""
    except json.JSONDecodeError as e:
        return _fail("JSON", e.lineno, e.msg, content)


def _check_js(path: str, content: str) -> str:
    node = _node()
    if not node:
        return ""  # node не установлен — проверку пропускаем молча
    try:
        proc = subprocess.run(
            [node, "--check", path],
            capture_output=True, text=True, timeout=10,
        )
        if proc.returncode == 0:
            return ""
        err = (proc.stderr or proc.stdout or "").strip()
        # node пишет "file.js:12\n<код>\nSyntaxError: ..."
        line_no = 0
        for token in err.replace("\n", ":").split(":"):
            if token.strip().isdigit():
                line_no = int(token.strip())
                break
        first = err.splitlines()[-1][:150] if err else "syntax error"
        return _fail("JavaScript", line_no, first, content)
    except (subprocess.TimeoutExpired, OSError):
        return ""


def _check_yaml(path: str, content: str) -> str:
    try:
        import yaml
    except ImportError:
        return ""
    try:
        yaml.safe_load(content)
        return ""
    except yaml.YAMLError as e:
        mark = getattr(e, "problem_mark", None)
        line_no = (mark.line + 1) if mark else 0
        return _fail("YAML", line_no, str(getattr(e, "problem", e))[:120], content)


_CHECKERS = {
    ".py": _check_python,
    ".json": _check_json,
    ".js": _check_js,
    ".mjs": _check_js,
    ".cjs": _check_js,
    ".yaml": _check_yaml,
    ".yml": _check_yaml,
}


def syntax_check(path: str, content: str) -> str:
    """Проверить файл по расширению. '' = ок или нет чекера."""
    low = path.lower()
    for ext, fn in _CHECKERS.items():
        if low.endswith(ext):
            try:
                return fn(path, content)
            except Exception:
                return ""  # чекер сломался — не блокируем работу
    return ""


__all__ = ["syntax_check"]
