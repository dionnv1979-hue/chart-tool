"""
Redis клиент с graceful degradation.
Если Redis недоступен — возвращает None, система падает на SQLite.
Никакой паники, никаких hard failures при старте.

Использование:
    redis = await get_redis()
    if redis:
        await redis.setex("key", 3600, "value")
    else:
        # fallback to SQLite
        ...
"""
import os
from typing import Optional

from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)

# Опциональная зависимость — не падаем если не установлен
try:
    import redis.asyncio as aioredis
    _REDIS_AVAILABLE = True
except ImportError:
    _REDIS_AVAILABLE = False
    logger.info("redis package not installed — Redis disabled")

_client: Optional[object] = None
_redis_enabled: bool = False


async def init_redis() -> bool:
    """
    Попытаться подключиться к Redis.
    Возвращает True если подключение успешно.
    Вызывается из lifespan — НЕ кидает исключений.
    """
    global _client, _redis_enabled

    if not _REDIS_AVAILABLE:
        logger.info("Redis: disabled (package not installed)")
        return False

    redis_url = os.getenv("REDIS_URL", settings.redis_url)
    if not redis_url:
        logger.info("Redis: disabled (REDIS_URL not set)")
        return False

    try:
        client = aioredis.from_url(
            redis_url,
            encoding="utf-8",
            decode_responses=True,
            socket_connect_timeout=2,
            socket_timeout=2,
        )
        # Проверяем соединение
        await client.ping()
        _client = client
        _redis_enabled = True
        logger.info(f"Redis: connected → {redis_url}")
        return True
    except Exception as e:
        logger.warning(f"Redis: unavailable ({e}) → falling back to SQLite")
        _redis_enabled = False
        return False


async def close_redis() -> None:
    global _client, _redis_enabled
    if _client is not None:
        await _client.aclose()
        _client = None
        _redis_enabled = False
        logger.info("Redis: connection closed")


def get_redis() -> Optional[object]:
    """Возвращает Redis клиент или None если недоступен."""
    return _client if _redis_enabled else None


def is_redis_available() -> bool:
    return _redis_enabled
