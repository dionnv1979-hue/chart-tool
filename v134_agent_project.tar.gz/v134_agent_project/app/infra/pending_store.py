"""
PendingStore — хранилище pending actions.
Два бэкенда: Redis (если доступен) и SQLite (fallback).

Redis:
    Ключи: pending:{action_id}
    TTL:   24 часа
    Быстро, работает в multi-process сценариях

SQLite:
    Через PendingActionRepository (существующий код)
    Работает без Redis

Использование:
    store = get_pending_store(db_session)
    await store.save(action_id, data)
    data = await store.get_and_delete(action_id)
"""
import json
from typing import Optional

from app.core.logger import get_logger
from app.infra.redis_client import get_redis

logger = get_logger(__name__)

_PENDING_TTL = 60 * 60 * 24  # 24 часа
_KEY_PREFIX = "pending:"


class RedisPendingStore:
    """Redis-backed pending store. Быстро, работает в multi-process."""

    def __init__(self, redis) -> None:
        self._redis = redis

    async def save(self, action_id: str, data: dict) -> None:
        key = _KEY_PREFIX + action_id
        await self._redis.setex(key, _PENDING_TTL, json.dumps(data, ensure_ascii=False))
        logger.info(f"PendingStore[Redis] saved: {action_id}")

    async def get_and_delete(self, action_id: str) -> Optional[dict]:
        key = _KEY_PREFIX + action_id
        # Атомарный GET + DEL через pipeline
        pipe = self._redis.pipeline()
        pipe.get(key)
        pipe.delete(key)
        results = await pipe.execute()
        raw = results[0]
        if raw is None:
            logger.warning(f"PendingStore[Redis] not found: {action_id}")
            return None
        data = json.loads(raw)
        logger.info(f"PendingStore[Redis] consumed: {action_id}")
        return data

    async def cleanup_expired(self, max_age_hours: int = 24) -> int:
        """Redis TTL управляет очисткой автоматически."""
        return 0


class SqlitePendingStore:
    """SQLite-backed pending store. Fallback когда Redis недоступен."""

    def __init__(self, db) -> None:
        from app.memory.repository import PendingActionRepository
        self._repo = PendingActionRepository(db)

    async def save(self, action_id: str, data: dict) -> None:
        await self._repo.save(
            action_id=action_id,
            session_id=data["session_id"],
            agent=data.get("agent", ""),
            tool=data.get("tool", ""),
            params=data.get("params", {}),
            prompt_text=data.get("prompt_text", ""),
            response_so_far=data.get("response_so_far", ""),
            steps=data.get("steps", []),
            current_step=data.get("current_step", 0),
            graph_state=data.get("graph_state", {}),
        )
        logger.info(f"PendingStore[SQLite] saved: {action_id}")

    async def get_and_delete(self, action_id: str) -> Optional[dict]:
        return await self._repo.get_and_delete(action_id)

    async def cleanup_expired(self, max_age_hours: int = 24) -> int:
        return await self._repo.cleanup_expired(max_age_hours)


def get_pending_store(db=None):
    """
    Вернуть лучший доступный store.
    Redis → если доступен.
    SQLite → fallback (требует db сессию).
    """
    redis = get_redis()
    if redis is not None:
        return RedisPendingStore(redis)
    if db is None:
        raise RuntimeError("SQLite pending store requires db session")
    return SqlitePendingStore(db)
