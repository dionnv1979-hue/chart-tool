"""
BaseAgent — общий цикл выполнения агента.
Содержит только механику: prompt building, tool-calling loop, approval handling.
Никакой бизнес-логики конкретных агентов — она в prompts.py.
"""
import json
import time
import hashlib
import re
import uuid
from typing import Optional

from app.agents.prompts import AgentConfig, get_agent_config
from app.core.logger import AgentLogger
from app.core import events as _events
from app.schemas.chat import AgentResultSchema, ToolStepSchema
from app.services.ollama_service import OllamaService
from app.services.tool_service import ToolService
from app.tools.base import ApprovalRequired
from app.agents.loop_guard import LoopGuard



# Спецфайлы без стандартных расширений которые часто создают агенты
_SPECIAL_FILENAMES = frozenset({
    "Dockerfile", "dockerfile",
    "Makefile", "makefile",
    "Procfile",
    ".env", ".env.local", ".env.example", ".env.production",
    ".gitignore", ".dockerignore", ".npmignore",
    "README", "LICENSE", "CHANGELOG",
    "requirements.txt", "requirements-dev.txt",
    "pyproject.toml", "setup.cfg", "setup.py",
    "package.json", "tsconfig.json", "webpack.config.js",
    ".eslintrc", ".prettierrc", ".babelrc",
    "docker-compose.yml", "docker-compose.yaml",
})


def _parse_filename_header(header: str) -> str | None:
    """
    Из заголовка-комментария вынимает имя файла.

    Примеры входа → выхода:
        "main.py"                            → "main.py"
        "filename.py myproject/main.py"       → "main.py"
        "myproject/display.py"               → "display.py"
        "Dockerfile"                         → "Dockerfile"
        ".env"                               → ".env"
        ".gitignore"                         → ".gitignore"
        "requirements.txt"                   → "requirements.txt"
        "просто комментарий без имени"       → None
    """
    candidates = []
    for token in header.replace("\\", "/").split():
        bare = token.rsplit("/", 1)[-1].strip(":,;()")
        if not bare:
            continue
        # Спецфайлы без расширений
        if bare in _SPECIAL_FILENAMES:
            candidates.append(bare)
            continue
        # Обычные файлы с расширением (поддержка my.component.tsx, .env.local)
        if re.fullmatch(r"[\w][\w.\-]*\.\w+", bare):  # \w матчит Unicode букв
            candidates.append(bare)
    if not candidates:
        return None
    # Игнорируем "filename.py" как маркер-заглушку
    real = [c for c in candidates if c.lower() != "filename.py"]
    return real[-1] if real else None


class AgentRunResult:
    """
    Результат запуска агента.
    type='done'    → ответ готов
    type='confirm' → нужно подтверждение для dangerous tool
    """
    def __init__(
        self,
        agent_key: str,
        response: str,
        steps: list[ToolStepSchema],
        type: str = "done",
        pending_action_id: Optional[str] = None,
        pending_tool: Optional[str] = None,
        pending_params: Optional[dict] = None,
        pending_thought: str = "",
        resume_prompt: Optional[str] = None,
    ) -> None:
        self.agent_key = agent_key
        self.response = response
        self.steps = steps
        self.type = type
        self.pending_action_id = pending_action_id
        self.pending_tool = pending_tool
        self.pending_params = pending_params
        self.pending_thought = pending_thought
        self.resume_prompt = resume_prompt

    def is_done(self) -> bool:
        return self.type == "done"

    def needs_confirm(self) -> bool:
        return self.type == "confirm"

    def to_agent_result_schema(
        self, label: str = "", round_n: int = 0
    ) -> AgentResultSchema:
        return AgentResultSchema(
            type="done",
            agent=self.agent_key,
            response=self.response,
            steps=self.steps,
            label=label or None,
            round=round_n or None,
        )


class BaseAgent:
    """
    Базовый агент с tool-calling loop.
    Конфигурируется через AgentConfig из prompts.py.
    Не содержит промптов — они в AGENTS dict.
    """

    def __init__(
        self,
        agent_key: str,
        ollama: OllamaService,
        tools: ToolService,
        max_steps: Optional[int] = None,
        temperature: Optional[float] = None,
        num_predict: Optional[int] = None,
    ) -> None:
        self._config: AgentConfig = get_agent_config(agent_key)
        self.agent_key = agent_key
        self._ollama = ollama
        self._tools = tools
        from app.core.config import settings as _s
        # min(роль_лимит, глобальный_тормоз) — теперь они реально связаны
        _role_steps = max_steps or self._config["max_steps"]
        self._max_steps = min(_role_steps, _s.max_agent_steps)
        self._allowed_tools: list[str] | None = self._config.get("allowed_tools")
        # Модель этого агента (может быть переопределена через Settings UI)
        self._model: str = self._config.get("model", "")
        # Температура: UI override > конфиг роли > дефолт 0.3
        self._temperature: float = (
            temperature if temperature is not None
            else self._config.get("temperature", 0.3)
        )
        # num_predict: UI override > глобальный settings (None = глобальный)
        self._num_predict: Optional[int] = num_predict

    def set_model(self, model: str) -> None:
        """Установить модель для этого агента."""
        if model:
            self._model = model

    def _tool_prompt_suffix(self) -> str:
        """
        Суффикс промпта для structured tool calling.
        Объясняет модели что нужно вернуть JSON объект.
        """
        return (
            "\n\nОТВЕЧАЙ СТРОГО В JSON ФОРМАТЕ:\n"
            '{"type": "tool_call", "tool": "имя_инструмента", "params": {...}}'
            " — если нужен инструмент\n"
            '{"type": "final_answer", "answer": "твой ответ"}'
            " — если это финальный ответ"
        )

    def _build_prompt(
        self,
        user_msg: str,
        history_text: str,
        extra_context: str = "",
    ) -> str:
        cfg = self._config
        # extra_context ставится ПОСЛЕ истории, прямо перед ответом агента.
        # Qwen уделяет максимальное внимание концу контекста — критичная
        # информация (traceback, факт-отчёт, план фикса) не должна тонуть
        # под несколькими kB истории. Перестановка трёх строк.
        return (
            f"{cfg['system_prompt']}\n\n"
            f"Доступные инструменты:\n{self._tools.get_tools_description(self._allowed_tools)}\n\n"
            f"Если нужен инструмент, пиши СТРОГО:\n"
            f"```tool\n"
            f'{{\"tool\": \"имя\", \"params\": {{\"key\": \"value\"}}}}\n'
            f"```\n"
            f"=== История ===\n{history_text}\n"
            f"=== Запрос ===\n"
            f"Пользователь: {user_msg}\n\n"
            f"{extra_context}\n"
            f"{cfg['emoji']} {cfg['name']}:"
        )

    async def run(
        self,
        user_msg: str,
        history_text: str,
        session_id: str,
        extra_context: str = "",
        images: list[str] | None = None,
    ) -> AgentRunResult:
        """
        Tool-calling loop.
        ApprovalRequired перехватывается здесь и конвертируется в confirm result.
        Больше нет is_dangerous() проверки в агенте — middleware делает это.
        """
        log = AgentLogger(self.agent_key, session_id)
        # Изолируем TODO и счётчик фейков по сессии (#6 + латентный баг)
        try:
            from app.tools.todo_tracker import set_todo_session
            set_todo_session(session_id)
        except Exception:
            pass
        prompt = self._build_prompt(user_msg, history_text, extra_context)
        steps: list[ToolStepSchema] = []
        response = ""

        # LoopGuard — детект циклов (идентичные вызовы, ping-pong, per-tool budget)
        guard = LoopGuard()
        _repair_fails: dict[str, int] = {}  # счётчик неудач str_replace по файлам
        _wf_blocks: dict[str, int] = {}     # счётчик блокировок write_file (regression)
        _empty_retry_done = False           # один повтор на пустой ответ за turn
        _save_ok_count = 0                  # успешные save_project (анти-спам Кодера)
        # Хэши последних ответов для детекции отсутствия прогресса
        recent_response_hashes: list[str] = []

        _start_ts = time.time()
        from app.core.config import settings as _s
        _time_budget = _s.max_agent_seconds
        await _events.emit(session_id, "agent_start",
            agent=self.agent_key, name=self._config["name"],
            emoji=self._config["emoji"])

        for step_num in range(self._max_steps):
            # ── Бюджет времени (wall-clock) ───────────────────────────────────
            # Защита от 3+ часов: шаги могут быть, но каждый очень долгий на 30B.
            _elapsed = time.time() - _start_ts
            if _elapsed > _time_budget:
                log.info(
                    f"Time budget exceeded: {_elapsed:.0f}s > {_time_budget}s "
                    f"на шаге {step_num + 1}/{self._max_steps} → stop"
                )
                await _events.emit(session_id, "agent_step",
                    agent=self.agent_key, step=step_num + 1,
                    action=f"⏱️ Лимит времени {_time_budget}s исчерпан — остановка")
                if not response:
                    response = (
                        f"⏱️ Превышен лимит времени ({_time_budget}s). "
                        f"Остановка чтобы не зависнуть. Сделано шагов: {step_num}."
                    )
                break

            log.step(step_num + 1, self._max_steps)
            await _events.emit(session_id, "agent_thinking",
                agent=self.agent_key, step=step_num + 1)

            # ── Structured tool calling ───────────────────────────────────────
            # Пробуем получить структурированный ответ (tool_call | final_answer).
            # Если Ollama не поддерживает format или вернула невалидный JSON —
            # падаем на regex fallback (старый способ).
            tool_name = None
            tool_params = None
            response = ""

            _llm_t0 = time.time()
            structured = await self._ollama.generate_structured(
                prompt=prompt + self._tool_prompt_suffix(),
                json_schema=self._ollama.TOOL_CALL_SCHEMA,
                model=self._model or None,
            )
            _llm_dt = time.time() - _llm_t0
            # Диагностика: сколько занял ИМЕННО вызов LLM (отдельно от прочего).
            # Если тут тысячи секунд — висит инференс/сеть. Если мало, а шаг долгий —
            # время утекает в другом месте (парсинг/инструменты/код).
            # Не шумим "took 0.0s" когда модель не поддерживает structured —
            # это не вызов, а мгновенный None-возврат (by-design, не ошибка).
            if structured is not None or _llm_dt > 0.5:
                log.info(f"LLM call (structured) took {_llm_dt:.1f}s, "
                         f"prompt_len={len(prompt)}")
            if _llm_dt > 120:
                log.info(f"⚠️ Долгий вызов LLM: {_llm_dt:.0f}s на шаге {step_num + 1} "
                         f"(prompt {len(prompt)} символов)")

            if structured and isinstance(structured, dict):
                if structured.get("type") == "tool_call" and structured.get("tool"):
                    tool_name = structured["tool"]
                    tool_params = structured.get("params", {})
                    # Мысль из structured ответа — прокидываем в params чтобы
                    # блок эмита ниже её подхватил (единый путь для обоих режимов)
                    if structured.get("thought") and isinstance(tool_params, dict):
                        tool_params.setdefault("thought", structured["thought"])
                    # Генерируем текстовый response для логов
                    response = f"[structured] calling {tool_name}({json.dumps(tool_params)})"
                    log.info(f"Structured tool call: {tool_name}")
                elif structured.get("type") == "final_answer":
                    response = structured.get("answer", "")
                    if not response:
                        # Пустой final_answer — fallback на обычную генерацию
                        response = await self._ollama.generate(
                            prompt, images=images if step_num == 0 else None
                        )
                    break  # финальный ответ
                else:
                    # Невалидная структура — fallback
                    structured = None

            if structured is None:
                # ── Regex fallback ────────────────────────────────────────────
                _gen_t0 = time.time()
                response = await self._ollama.generate(
                    prompt, images=images if step_num == 0 else None,
                    model=self._model or None,
                    temperature=self._temperature,
                    num_predict=self._num_predict,
                )
                _gen_dt = time.time() - _gen_t0
                log.info(f"LLM call (generate) took {_gen_dt:.1f}s, "
                         f"prompt_len={len(prompt)}, resp_len={len(response)}")
                # Пустой ответ (resp_len=0) — модель ничего не выдала (часто из-за
                # длинного контекста / нехватки VRAM / сырого кванта). Это НЕ повод
                # жечь раунд впустую: пробуем ОДИН раз с урезанным промптом — иногда
                # модель «отвисает» на более коротком входе. Универсально для любой
                # модели, которая иногда возвращает пустоту.
                if not response and not _empty_retry_done and len(prompt) > 4000:
                    _empty_retry_done = True
                    trimmed = prompt[:2000] + "\n...\n" + prompt[-2000:]
                    log.warning(
                        f"Пустой ответ модели — повтор с урезанным промптом "
                        f"({len(prompt)}→{len(trimmed)} симв)"
                    )
                    _gen_t0 = time.time()
                    response = await self._ollama.generate(
                        trimmed, model=self._model or None,
                        temperature=self._temperature,
                        num_predict=self._num_predict,
                    )
                    log.info(f"LLM retry (generate) took {time.time()-_gen_t0:.1f}s, "
                             f"resp_len={len(response)}")
                if not response:
                    break
                # Ollama вернула ошибку/таймаут — прерываем без продолжения
                if response.startswith(("[TIMEOUT]", "[API ERROR")):
                    log.error(f"Ollama error at step {step_num + 1}: {response[:80]}")
                    await _events.emit(session_id, "error",
                                       agent=self.agent_key, message=response[:200])
                    response = ""  # не возвращаем ошибку как ответ агента
                    break
                # Ответ обрезан по num_predict — инструктируем модель дописать
                if "# [TRUNCATED_BY_NUM_PREDICT]" in response:
                    response = response.replace("# [TRUNCATED_BY_NUM_PREDICT]", "")
                    log.warning(f"Truncation detected at step {step_num + 1} — injecting continuation hint")
                    await _events.emit(session_id, "agent_step",
                        agent=self.agent_key, step=step_num + 1,
                        action="⚠️ Ответ обрезан по num_predict — запрашиваю продолжение")
                    cfg = self._config
                    resp_for_prompt = response[:3000] + (
                        f"\n... [обрезан, всего {len(response)} символов]"
                        if len(response) > 3000 else ""
                    )
                    prompt += (
                        f"\n{resp_for_prompt}\n\n"
                        f"⚠️ СИСТЕМА: ответ обрезан (достигнут лимит num_predict). "
                        f"Код НЕПОЛНЫЙ — последний файл оборван посередине. "
                        f"Продолжи с места обрыва: допиши незаконченные функции/классы, "
                        f"затем перейди к следующим файлам по плану. "
                        f"НЕ начинай заново — продолжай с того места где оборвалось.\n\n"
                        f"{cfg['emoji']} {cfg['name']}:"
                    )
                    continue  # следующий шаг — продолжение без tool call
                tool_name, tool_params = self._tools.parse_tool_call_from_text(response, self._allowed_tools)
                if tool_name is None:
                    break  # Финальный ответ без tool call

            log.tool_call(tool_name, tool_params or {})
            # ── Эмит мысли агента ─────────────────────────────────────────
            # Текст ДО tool call — это рассуждение модели: что она решила
            # сделать и зачем. Раньше выбрасывался — UI видел только
            # "TOOL CALL: write_file" без контекста. Теперь мысль видна.
            _thought = ""
            if tool_params and isinstance(tool_params, dict) and "thought" in tool_params:
                # structured путь: thought пришёл полем — изымаем из params
                _thought = str(tool_params.pop("thought", ""))[:400]
            elif response and not response.startswith("[structured]"):
                # regex путь: мысль — текст до ```tool блока
                _raw_thought = response.split("```tool")[0].strip()
                # Отрезаем код-блоки из мысли (если модель писала код до tool)
                _raw_thought = re.sub(r"```\w*\n.*?\n```", "[код]", _raw_thought,
                                      flags=re.DOTALL)
                _thought = _raw_thought.strip()[-400:]
            if _thought:
                await _events.emit(session_id, "agent_thought",
                    agent=self.agent_key, step=step_num + 1,
                    thought=_thought)
                log.info(f"THOUGHT: {_thought[:150]}")
            await _events.emit(session_id, "tool_call",
                agent=self.agent_key, tool=tool_name,
                params={k: str(v)[:80] for k, v in (tool_params or {}).items()})

            try:
                result = await self._tools.execute(tool_name, tool_params or {}, allowed=self._allowed_tools)
            except ApprovalRequired as approval:
                # ── Approval middleware intercept ──────────────────────
                action_id = self._make_action_id(session_id, step_num)
                thought = response.split("```tool")[0].strip()
                log.info(f"Approval required: {action_id} tool={tool_name}")
                # Уведомляем UI — агент ждёт подтверждения пользователя
                await _events.emit(session_id, "approval_needed",
                                   agent=self.agent_key,
                                   tool=tool_name,
                                   action_id=action_id)
                return AgentRunResult(
                    agent_key=self.agent_key,
                    response=response,
                    steps=steps,
                    type="confirm",
                    pending_action_id=action_id,
                    pending_tool=approval.tool_name,
                    pending_params=approval.params,
                    pending_thought=thought,
                    resume_prompt=prompt + f"\n{response}\n\n",
                )

            log.tool_result(tool_name, result.output)
            await _events.emit(session_id, "tool_result",
                agent=self.agent_key, tool=tool_name,
                ok=result.success, preview=result.output[:150])
            steps.append(ToolStepSchema(
                step=step_num + 1,
                tool=tool_name,
                params=tool_params or {},
                result=result.output[:500],
            ))

            # ── Чеклист: прогресс по файлам в UI ───────────────────────────
            if tool_name == "write_file" and "📋 Прогресс" in result.output:
                try:
                    from app.core.active_project import checklist_progress
                    _d, _t, _rem = checklist_progress()
                    if _t > 0:
                        await _events.emit(session_id, "checklist",
                            done=_d, total=_t, remaining=_rem[:10])
                except Exception:
                    pass

            # ── Direction hint при падении запуска кода ───────────────────
            # Без подсказки модель часто запускает тот же сломанный код снова,
            # не читая ошибку. Добавляем direction + hint из fix_memory.
            if (tool_name in ("run_python", "run_code", "run_script")
                    and not result.success):
                try:
                    from app.memory.fix_memory import recall_fix as _recall
                    _mem_hint = _recall(result.output)
                except Exception:
                    _mem_hint = ""
                _run_direction = (
                    f"\n⚠️ КОД УПАЛ. НЕ запускай снова без правки — результат будет тот же.\n"
                    f"Алгоритм: (1) найди строку с ошибкой в трейсбэке выше, "
                    f"(2) прочитай файл через read_file если нужно, "
                    f"(3) исправь через str_replace на КОНКРЕТНУЮ строку.\n"
                    + _mem_hint
                )
                result.output = result.output + _run_direction
                log.info(f"Direction hint добавлен после {tool_name} fail")

            # ── Анти repair-loop: после 2 неудачных str_replace на один файл —
            # принудительно переключаем Кодера на write_file (целиком). Иначе
            # модель крутит read→str_replace(fail)→read по кругу (баг из лога).
            if tool_name == "str_replace" and not result.success and "old_str" in result.output:
                _fp = (tool_params or {}).get("path", "?")
                _repair_fails[_fp] = _repair_fails.get(_fp, 0) + 1
                if _repair_fails[_fp] >= 2:
                    log.info(f"Repair-loop: {_repair_fails[_fp]} неудач str_replace на {_fp} → форсим write_file")
                    prompt += (
                        f"\n\n🔧 СИСТЕМА: str_replace на {_fp} не сработал "
                        f"{_repair_fails[_fp]} раза подряд. ПРЕКРАТИ пытаться str_replace "
                        f"и НЕ читай файл снова. Перепиши весь файл целиком одним вызовом "
                        f"write_file(path=\"{_fp}\", content=\"<полный исправленный код>\")."
                    )
            elif tool_name == "str_replace" and result.success:
                _repair_fails.pop((tool_params or {}).get("path", "?"), None)

            # ── Разрыв КЛИНЧА write_file↔str_replace (находка из лога) ────
            # Кодер застревает: write_file блокируется regression guard'ом,
            # str_replace не находит old_str — по кругу. Если на ОДНОМ файле
            # случилось и то, и другое — даём одноразовое разрешение переписать
            # файл целиком (иначе цикл не разорвать). Регистрируем write-блок:
            if (tool_name == "write_file" and not result.success
                    and "ДЕГРАДАЦИЯ" in result.output):
                _wf = (tool_params or {}).get("path", "?")
                _wf_blocks[_wf] = _wf_blocks.get(_wf, 0) + 1
                # Клинч: str_replace тоже падал на этом файле ИЛИ write блокнут 2+ раз
                if _repair_fails.get(_wf, 0) >= 1 or _wf_blocks[_wf] >= 2:
                    try:
                        from app.core.active_project import allow_force_rewrite
                        allow_force_rewrite(_wf)
                        log.info(f"Клинч на {_wf} → одноразовое разрешение перезаписи")
                        prompt += (
                            f"\n\n🔧 СИСТЕМА: разблокирована ОДНА перезапись {_wf}. "
                            f"Сейчас вызови write_file(path=\"{_wf}\", "
                            f"content=\"<ПОЛНЫЙ исправленный код со ВСЕМИ функциями>\"). "
                            f"Убедись что код полный — не сокращай."
                        )
                    except Exception:
                        pass

            # ── Детекция цикла (LoopGuard) ────────────────────────────
            # Ловит: идентичные вызовы, ping-pong A-B-A-B, злоупотребление
            # одним осмотровым инструментом. warn-before-block: первый раз
            # предупреждаем модель, второй такой же цикл — останавливаем.
            verdict = guard.check_call(tool_name, tool_params or {})
            if verdict.warned:
                log.info(f"LoopGuard warn: {verdict.reason}")
                # Вставляем предупреждение в контекст следующего шага —
                # модель получает шанс исправиться сама.
                prompt += (
                    f"\n\n⚠️ СИСТЕМА: {verdict.reason}\n"
                    f"Не повторяй то же действие — сделай следующий конкретный шаг."
                )
            elif verdict.blocked:
                log.info(f"LoopGuard block: {verdict.reason}")
                response = (
                    f"⚠️ {verdict.reason}\n\n"
                    f"Последний результат:\n```\n{result.output[:300]}\n```\n\n"
                    f"Останавливаюсь чтобы не тратить ресурсы."
                )
                break

            # ── Детекция отсутствия прогресса ────────────────────────
            # Если последние 3 ответа агента одинаковы — он кружится
            response_hash = hashlib.sha256(response.encode()).hexdigest()[:16]
            recent_response_hashes.append(response_hash)
            recent_response_hashes = recent_response_hashes[-3:]
            if (len(recent_response_hashes) == 3
                    and len(set(recent_response_hashes)) == 1
                    and len(response) > 50):  # игнорируем короткие пустые ответы
                log.info("No-progress detected: response unchanged for 3 steps → stop")
                response = (
                    f"⚠️ Замечаю что мои последние {len(recent_response_hashes)} ответа "
                    f"одинаковы — нет прогресса. Останавливаюсь.\n\n"
                    f"Последнее состояние:\n{response[:500]}"
                )
                break

            # ── Тестер: стоп когда тесты прошли ────────────────────────
            if self.agent_key == "tester" and tool_name in ("run_python", "run_code", "run_script"):
                out = result.output
                # Тесты прошли если: есть OK/passed и нет FAILED/ERROR
                tests_ok = (
                    ("OK" in out or "passed" in out.lower() or "Ran" in out)
                    and "FAILED" not in out
                    and "ERROR" not in out
                    and "Traceback" not in out
                )
                if tests_ok:
                    log.info("Tester: all tests passed → stop early")
                    response = (
                        f"✅ Все тесты прошли успешно.\n\n"
                        f"Результат:\n```\n{out[:500]}\n```"
                    )
                    break

            # ── Кодер: стоп после повторного save_project ──────────────────
            # Из лога: Кодер сохранял проект 6 раз подряд, каждый раз генерируя
            # ~20K символов кода заново (~90с на шаг) — ~9 минут впустую.
            # После успешного save модель не понимает что задача завершена.
            # 1-й успешный save → жёсткий стоп-сигнал в промпт.
            # 2-й успешный save → принудительный break (хватит).
            if (self.agent_key == "coder" and tool_name == "save_project"
                    and result.success):
                _save_ok_count += 1
                if _save_ok_count >= 2:
                    log.info(f"Coder: save_project x{_save_ok_count} → принудительный стоп")
                    response = (
                        f"✅ Проект сохранён ({_save_ok_count}-й вызов save_project — "
                        f"останавливаюсь, повторное сохранение не нужно).\n\n"
                        f"{result.output[:300]}"
                    )
                    break
                # Первый save — инжектируем стоп-сигнал
                prompt += (
                    f"\n\n🛑 СИСТЕМА: проект УСПЕШНО СОХРАНЁН. Задача завершена.\n"
                    f"Если ВСЕ файлы из списка Архитектора записаны — напиши "
                    f"короткий финальный ответ (1-2 предложения: что сделано). "
                    f"НЕ генерируй код заново. НЕ вызывай save_project повторно.\n"
                    f"Если какой-то файл НЕ записан — напиши ТОЛЬКО его через "
                    f"write_file (не переписывай уже записанные)."
                )

            cfg = self._config
            # Обрезаем вывод инструмента в промпте — защита от prompt bloat (ChatGPT #9)
            tool_out_truncated = result.output[:2000] + (
                f"\n... [обрезано, всего {len(result.output)} символов]"
                if len(result.output) > 2000 else ""
            )
            # Ответ модели тоже обрезаем перед добавлением в промпт — иначе один
            # большой ответ раздувает контекст следующих шагов (был случай 890К→138К промпт).
            resp_for_prompt = response[:3000] + (
                f"\n... [ответ обрезан, всего {len(response)} символов]"
                if len(response) > 3000 else ""
            )
            prompt += (
                f"\n{resp_for_prompt}\n\n"
                f"[Результат {tool_name}]:\n{tool_out_truncated}\n\n"
                f"{cfg['emoji']} {cfg['name']}:"
            )

        await _events.emit(session_id, "agent_done",
            agent=self.agent_key, name=self._config["name"],
            emoji=self._config["emoji"],
            elapsed=round(time.time() - _start_ts, 2),
            steps_count=len(steps))
        return AgentRunResult(
            agent_key=self.agent_key,
            response=response,
            steps=steps,
            type="done",
        )

    async def resume_after_confirm(
        self,
        resume_prompt: str,
        tool_name: str,
        tool_result: str,
        step_num: int,
        existing_steps: list[ToolStepSchema],
        session_id: str,
    ) -> AgentRunResult:
        """Продолжить после подтверждения пользователем."""
        cfg = self._config
        continued = (
            resume_prompt
            + f"[Результат {tool_name}]:\n{tool_result}\n\n"
            + f"{cfg['emoji']} {cfg['name']}:"
        )
        steps = list(existing_steps)
        steps.append(ToolStepSchema(
            step=step_num + 1,
            tool=tool_name,
            params={},
            result=tool_result[:500],
        ))
        final = await self._ollama.generate(continued)
        return AgentRunResult(agent_key=self.agent_key, response=final, steps=steps)

    def _make_action_id(self, session_id: str, step: int) -> str:
        # uuid4 — нет коллизий, нет предсказуемости (ChatGPT #7)
        return f"action_{uuid.uuid4().hex[:16]}"

    # ── Static helpers ────────────────────────────────────────────────────
    @staticmethod
    def extract_code(text: str, lang: str = "python") -> str:
        matches = re.findall(rf"```{lang}\s*(.*?)```", text, re.DOTALL | re.IGNORECASE)
        if matches:
            return matches[0].strip()
        fallback = re.findall(r"```\s*(.*?)```", text, re.DOTALL)
        return fallback[0].strip() if fallback else text.strip()

    @staticmethod
    def extract_all_files(text: str) -> dict[str, str]:
        """
        Достаёт файлы из ответа LLM. Поддерживает 3 формата:

        Формат A — имя ПЕРЕД блоком:
            # main.py
            ```python
            print("hello")
            ```

        Формат B — имя ПЕРВОЙ СТРОКОЙ внутри блока (как комментарий):
            ```python
            # main.py
            print("hello")
            ```

        Формат C — формат B с префиксом-путём (Кодер часто так пишет):
            ```python
            # filename.py myproject/main.py
            import sys
            ```
            → имя файла берётся как basename последнего токена

        Если ничего не нашли — fallback к первому блоку как main.py.
        """
        files: dict[str, str] = {}

        # ── Формат A: # name.py ПЕРЕД блоком ──────────────────────────────
        for fname, code in re.findall(
            r"^#\s*([\w\-]+\.\w+)\s*\n```\w*\s*\n(.*?)\n```",
            text, re.DOTALL | re.MULTILINE,
        ):
            name = fname.strip()
            if name not in files:
                files[name] = code.strip()

        # ── Формат B/C: имя ВНУТРИ блока первой строкой ───────────────────
        # Захватываем всё что выглядит как комментарий-имя на первой строке
        for header, body in re.findall(
            r"```\w*\s*\n#\s*([^\n]+?)\n(.*?)\n```",
            text, re.DOTALL,
        ):
            # Из заголовка типа "filename.py myproject/main.py" или "main.py"
            # вытаскиваем последний токен который выглядит как имя файла
            name = _parse_filename_header(header)
            if name and name not in files:
                # Очищаем от вложенных markdown фенсов если они есть
                clean_body = body.strip()
                clean_body = re.sub(r"^```\w*\n", "", clean_body)
                clean_body = re.sub(r"\n```$", "", clean_body)
                files[name] = clean_body

        # ── Fallback: один блок без имени → main.py ───────────────────────
        if not files:
            code = BaseAgent.extract_code(text)
            if code:
                # extract_code уже возвращает содержимое без фенсов
                files["main.py"] = code

        return files
