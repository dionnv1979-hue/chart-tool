"""
LoopGuard — детект и предотвращение вырожденных циклов вызова инструментов.

Адаптировано из OpenJarvis (упрощено: чистый Python, без Rust/EventBus).

Зачем: в логах qwen3-coder регулярно зацикливается:
  - todo_tracker → todo_tracker → todo_tracker (один инструмент по кругу)
  - list_files(A) → list_files(B) → list_files(A) (ping-pong A-B-A-B)
  - 4+ одинаковых list_files подряд (бюджет инструмента)
Каждый холостой вызов = ещё один запрос к 30B-модели = минуты простоя.

Три независимых детектора:
  1. Идентичные вызовы:  SHA-256(tool+args) повторился > max_identical раз
  2. Per-tool budget:    один инструмент вызван > poll_budget раз за прогон
  3. Ping-pong:          паттерн A-B-A-B или A-B-C-A-B-C в последовательности

Поведение warn-before-block: первое срабатывание — предупреждение (модель
получает шанс исправиться), второе такое же — жёсткий блок.

ВАЖНО: per-tool budget НЕ применяется к «рабочим» инструментам, которые
естественно вызываются много раз (write_file, str_replace) — только к
«осмотровым»/«опросным» (list_files, read_file, check_package, todo_tracker).
Это делает guard универсальным под любые проекты: писать 20 файлов — норма,
а 20 раз сканировать одну папку — цикл.
"""
from __future__ import annotations

import hashlib
from collections import deque
from dataclasses import dataclass, field

from app.core.logger import get_logger

logger = get_logger(__name__)


@dataclass
class LoopGuardConfig:
    """Настройки LoopGuard. Значения подобраны под локальные модели."""

    enabled: bool = True
    max_identical_calls: int = 3       # одинаковый (tool+args) подряд/всего
    ping_pong_window: int = 6          # окно для детекта A-B-A-B
    poll_tool_budget: int = 6          # макс. вызовов одного «осмотрового» инструмента
    warn_before_block: bool = True     # 1-й цикл — предупредить, 2-й — блок

    # Инструменты, для которых действует poll_budget (осмотр/опрос, не запись).
    # Остальные инструменты (write_file, str_replace, save_project, run_*) —
    # без лимита по количеству, т.к. их много вызывать нормально.
    poll_tools: frozenset = frozenset({
        "list_files", "read_file", "check_package", "todo_tracker", "web_search",
    })


@dataclass
class LoopVerdict:
    """Результат проверки одного вызова."""

    blocked: bool = False
    warned: bool = False
    reason: str = ""
    cycle_key: str = ""   # стабильный идентификатор типа цикла (для warn-before-block)


@dataclass
class LoopGuard:
    """
    Детектор вырожденных циклов. Один экземпляр на один прогон агента.

    Использование:
        guard = LoopGuard()
        verdict = guard.check_call(tool_name, params_dict)
        if verdict.blocked:
            # остановить агента, отдать verdict.reason модели
        elif verdict.warned:
            # вставить verdict.reason в контекст как предупреждение, продолжить
    """

    config: LoopGuardConfig = field(default_factory=LoopGuardConfig)
    _call_counts: dict[str, int] = field(default_factory=dict, init=False)
    _per_tool_counts: dict[str, int] = field(default_factory=dict, init=False)
    _tool_sequence: deque = field(default=None, init=False)  # type: ignore
    _warned_cycles: set[str] = field(default_factory=set, init=False)

    def __post_init__(self) -> None:
        self._tool_sequence = deque(maxlen=self.config.ping_pong_window * 2)

    def check_call(self, tool_name: str, arguments: dict | str) -> LoopVerdict:
        """
        Проверить вызов. Вызывать ПОСЛЕ выполнения инструмента
        (чтобы guard видел реальную последовательность).
        """
        if not self.config.enabled:
            return LoopVerdict()

        verdict = self._raw_check(tool_name, arguments)

        # warn-before-block: первое срабатывание данного типа цикла —
        # предупреждение, второе — блок. Ключ цикла СТАБИЛЬНЫЙ (tool+тип),
        # без счётчика в тексте — иначе каждое срабатывание выглядит «новым»
        # и блок никогда не наступает.
        if verdict.blocked and self.config.warn_before_block:
            if verdict.cycle_key not in self._warned_cycles:
                self._warned_cycles.add(verdict.cycle_key)
                return LoopVerdict(blocked=False, warned=True,
                                   reason=verdict.reason, cycle_key=verdict.cycle_key)

        return verdict

    def _raw_check(self, tool_name: str, arguments: dict | str) -> LoopVerdict:
        # Нормализуем аргументы в строку для хэша
        if isinstance(arguments, dict):
            import json
            try:
                args_str = json.dumps(arguments, sort_keys=True, ensure_ascii=False)
            except (TypeError, ValueError):
                args_str = str(sorted(arguments.items()))
        else:
            args_str = str(arguments)

        # ── 1. Идентичные вызовы (tool + точные args) ────────────────────
        call_hash = hashlib.sha256(f"{tool_name}:{args_str}".encode()).hexdigest()[:16]
        self._call_counts[call_hash] = self._call_counts.get(call_hash, 0) + 1
        if self._call_counts[call_hash] > self.config.max_identical_calls:
            reason = (
                f"Идентичный вызов `{tool_name}` повторён "
                f"{self._call_counts[call_hash]} раз "
                f"(лимит {self.config.max_identical_calls}). "
                f"Результат не меняется — смени подход."
            )
            logger.warning(f"LoopGuard: identical_call {tool_name} x{self._call_counts[call_hash]}")
            return LoopVerdict(blocked=True, reason=reason, cycle_key=f"identical:{call_hash}")

        # ── 2. Per-tool budget (только для осмотровых инструментов) ───────
        if tool_name in self.config.poll_tools:
            self._per_tool_counts[tool_name] = self._per_tool_counts.get(tool_name, 0) + 1
            # В repair-режиме read_file вызывается законно много раз:
            # прочитал → str_replace fail → прочитал свежую версию → повтор.
            # Удваиваем бюджет чтобы LoopGuard не блокировал правомерный workflow.
            budget = self.config.poll_tool_budget
            if tool_name == "read_file":
                try:
                    from app.core.active_project import get_fix_mode
                    if get_fix_mode():
                        budget = budget * 2
                except Exception:
                    pass
            if self._per_tool_counts[tool_name] > budget:
                reason = (
                    f"Инструмент `{tool_name}` вызван "
                    f"{self._per_tool_counts[tool_name]} раз "
                    f"(бюджет {self.config.poll_tool_budget}). "
                    f"Хватит осматриваться — переходи к работе (пиши файлы / дай ответ)."
                )
                logger.warning(f"LoopGuard: poll_budget {tool_name} x{self._per_tool_counts[tool_name]}")
                return LoopVerdict(blocked=True, reason=reason, cycle_key=f"poll:{tool_name}")

        # ── 3. Ping-pong (A-B-A-B / A-B-C-A-B-C) ─────────────────────────
        self._tool_sequence.append(tool_name)
        if len(self._tool_sequence) >= self.config.ping_pong_window:
            if self._detect_ping_pong():
                reason = (
                    "Замечен повторяющийся паттерн вызовов "
                    "(хождение по кругу между инструментами). "
                    "Останови осмотр и сделай конкретный шаг."
                )
                logger.warning(f"LoopGuard: ping_pong seq={list(self._tool_sequence)}")
                return LoopVerdict(blocked=True, reason=reason, cycle_key="ping_pong")

        return LoopVerdict()

    def _detect_ping_pong(self) -> bool:
        """
        Ищем периодический паттерн (период 2 или 3) в хвосте последовательности.
        ВАЖНО: паттерн должен содержать БОЛЬШЕ ОДНОГО разного инструмента —
        иначе «write_file x20» (норма — пишем 20 файлов) ложно считается циклом.
        Однообразные повторы одного инструмента ловит per-tool budget /
        identical-call, а не этот детектор.
        """
        seq = list(self._tool_sequence)
        n = len(seq)
        for period in (2, 3):
            if n >= period * 2:
                tail = seq[-period * 2:]
                pattern = tail[:period]
                if len(set(pattern)) < 2:
                    continue  # период из одного инструмента — не ping-pong
                if all(tail[i] == pattern[i % period] for i in range(len(tail))):
                    return True
        return False

    def reset(self) -> None:
        """Сбросить всё состояние (между прогонами)."""
        self._call_counts.clear()
        self._per_tool_counts.clear()
        self._tool_sequence.clear()
        self._warned_cycles.clear()


__all__ = ["LoopGuard", "LoopGuardConfig", "LoopVerdict"]
