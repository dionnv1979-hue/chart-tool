import re
"""
Реестр агентов.
create_agent() — единственная фабрика. Больше нет отдельных классов
ManagerAgent, CoderAgent и т.д. — агент = BaseAgent + конфиг из AGENTS.
"""
from app.agents.base import BaseAgent
from app.services.ollama_service import OllamaService
from app.services.tool_service import ToolService


def create_agent(
    agent_key: str,
    ollama: OllamaService,
    tools: ToolService,
    model_override: str | None = None,
    params: dict | None = None,
) -> BaseAgent:
    """
    Создать агента по ключу.
    model_override — модель из БД Settings (переопределяет дефолт конфига).
    params — переопределения из Settings UI:
      {"temperature": float, "num_predict": int, "max_steps": int}
      (любое поле опционально; None/отсутствие = дефолт роли)
    """
    from app.agents.prompts import get_agent_config
    get_agent_config(agent_key)  # validate
    p = params or {}
    agent = BaseAgent(
        agent_key=agent_key, ollama=ollama, tools=tools,
        max_steps=p.get("max_steps"),
        temperature=p.get("temperature"),
        num_predict=p.get("num_predict"),
    )
    if model_override:
        agent.set_model(model_override)
    return agent


# ── Хелперы для специфичной логики агентов ────────────────────────────────────

def critic_is_approved(response: str) -> bool:
    """
    Проверить что критик одобрил.

    Протокол критика: "APPROVED" или "REJECTED + причина"
    Проверяем ТОЛЬКО первую строку ответа.

    Примеры:
      "APPROVED"                           → True  ✅
      "APPROVED. Код корректный."          → True  ✅ (первое слово)
      "APPROVED\nНО ЕСТЬ ЗАМЕЧАНИЯ"        → False ✅ (оговорки = не одобрено)
      "REJECTED. Нет тестов."              → False ✅
      "NOT APPROVED"                       → False ✅
      "I do not fully APPROVED this"       → False ✅ (не первое слово)

    Логика: берём только первую строку и проверяем что она начинается с APPROVED.
    Если после APPROVED есть оговорки (НО, WITH, BUT и т.д.) — это частичное
    одобрение которое мы трактуем как REJECTED (лучше переделать чем пропустить баг).
    """
    lines = response.strip().splitlines()
    if not lines:
        return False
    first_line = lines[0].strip()
    upper = first_line.upper()

    # Явные отклонения
    if re.search(r"\b(NOT|НЕ|REJECT|ОТКЛОНЕН)\b", upper):
        return False

    # Первая строка должна начинаться с APPROVED
    if not re.match(r"^APPROVED\b", upper):
        return False

    # После APPROVED допускаем только: пустоту, точку, тире + пояснение
    # НЕ допускаем другие слова сразу после APPROVED (MAYBE, BUT, WITH и т.д.)
    # Паттерн: APPROVED optionally followed by . или — или : и текст
    # Разрешаем: APPROVED / APPROVED. / APPROVED: / APPROVED — / APPROVED. текст
    if not re.match(r"^APPROVED[.!]?(?:\s*[-—:.].*)?$", upper):
        return False

    # ChatGPT верно указал: APPROVED: BUT CRITICAL BUGS — это не одобрение
    # Проверяем оговорки в ЛЮБОМ месте строки
    caveats = (
        "BUT ", "BUT\n", "HOWEVER", "WITH ISSUES", "CRITICAL",
        "WARNING", "НО ", "НО\n", "ОДНАКО", "EXCEPT", "UNLESS",
        "MISSING", "NOT ALL", "INCOMPLETE",
    )
    if any(c in upper for c in caveats):
        return False

    return True
