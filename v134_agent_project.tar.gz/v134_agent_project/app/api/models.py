"""
Models API — управление моделями Ollama.
GET  /models       — список установленных моделей
GET  /model        — текущая модель
POST /model        — сменить модель
"""
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.constants import SETTINGS_KEY_MODEL
from app.core.logger import get_logger
from app.memory.database import get_db_session
from app.memory.repository import SettingRepository
from app.services.ollama_service import OllamaService, get_ollama_service

router = APIRouter(tags=["models"])
logger = get_logger(__name__)


class ModelInfo(BaseModel):
    name: str
    size: int = 0
    modified: str = ""


class ModelsListResponse(BaseModel):
    ok: bool
    models: list[ModelInfo] = []
    current: str = ""
    error: str = ""


class CurrentModelResponse(BaseModel):
    current: str


class SetModelRequest(BaseModel):
    name: str


class SetModelResponse(BaseModel):
    ok: bool
    current: str = ""
    error: str = ""


@router.get("/models", response_model=ModelsListResponse)
async def list_models(
    ollama: OllamaService = Depends(get_ollama_service),
):
    """Список установленных моделей в Ollama."""
    try:
        models = await ollama.list_models()
        return ModelsListResponse(
            ok=True,
            models=[ModelInfo(**m) for m in models],
            current=ollama.current_model,
        )
    except Exception as e:
        logger.error(f"list_models error: {e}")
        return ModelsListResponse(ok=False, error=str(e))


@router.get("/model", response_model=CurrentModelResponse)
async def get_current_model(
    ollama: OllamaService = Depends(get_ollama_service),
):
    """Текущая активная модель."""
    return CurrentModelResponse(current=ollama.current_model)


@router.post("/model", response_model=SetModelResponse)
async def set_model(
    request: SetModelRequest,
    db: AsyncSession = Depends(get_db_session),
    ollama: OllamaService = Depends(get_ollama_service),
):
    """
    Сменить активную модель.
    Проверяет что модель установлена в Ollama перед сменой.
    Сохраняет выбор в БД.
    """
    name = request.name.strip()
    if not name:
        return SetModelResponse(ok=False, error="Имя модели не может быть пустым")

    # No-op если модель не меняется — избегаем лишней записи в БД
    if name == ollama.current_model:
        return SetModelResponse(ok=True, current=name)

    available = await ollama.is_model_available(name)
    if not available:
        return SetModelResponse(
            ok=False,
            error=f"Модель '{name}' не установлена. Запустите: ollama pull {name}",
        )

    ollama.current_model = name

    # Сохраняем в БД
    setting_repo = SettingRepository(db)
    await setting_repo.set(SETTINGS_KEY_MODEL, name)

    logger.info(f"Model set to: {name}")
    return SetModelResponse(ok=True, current=name)
