"""
Sessions API — управление сессиями диалога.
GET  /sessions — список сессий
POST /clear    — очистить сессию
GET  /history  — история сообщений
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.constants import HISTORY_API_LIMIT, SESSIONS_LIST_LIMIT
from app.core.logger import get_logger
from app.memory.database import get_db_session
from app.schemas.message import (
    ClearSessionRequest,
    ClearSessionResponse,
    HistoryResponse,
    MessageSchema,
    SessionsResponse,
)
from app.services.session_service import SessionService

router = APIRouter(tags=["sessions"])
logger = get_logger(__name__)


@router.get("/sessions", response_model=SessionsResponse)
async def list_sessions(
    db: AsyncSession = Depends(get_db_session),
):
    """Список активных сессий (последние по активности)."""
    service = SessionService(db)
    sessions = await service.list_sessions(limit=SESSIONS_LIST_LIMIT)
    return SessionsResponse(sessions=sessions)


@router.post("/clear", response_model=ClearSessionResponse)
async def clear_session(
    request: ClearSessionRequest,
    db: AsyncSession = Depends(get_db_session),
):
    """Очистить историю сессии."""
    service = SessionService(db)
    deleted = await service.clear_session(request.session)
    return ClearSessionResponse(ok=True, deleted_count=deleted)


@router.get("/history", response_model=HistoryResponse)
async def get_history(
    session: str = Query(..., min_length=1, max_length=64, description="ID сессии"),
    limit: int = Query(default=HISTORY_API_LIMIT, ge=1, le=500),
    db: AsyncSession = Depends(get_db_session),
):
    """История сообщений сессии."""
    service = SessionService(db)
    messages = await service.get_history_for_api(session_id=session, limit=limit)
    schemas = [
        MessageSchema(
            id=m.id,
            role=m.role,
            agent=m.agent,
            content=m.content,
            created_at=m.created_at,
        )
        for m in messages
    ]
    return HistoryResponse(messages=schemas, total=len(schemas))
