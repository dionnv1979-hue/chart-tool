"""
Chat API — основные endpoints для взаимодействия с агентами.
POST /chat   — отправить сообщение
POST /confirm — подтвердить/отклонить действие агента
POST /stream  — стриминговая генерация
"""
import json

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.logger import get_logger
from app.graph.state import WorkflowState
from app.graph.workflow import get_workflow
from app.memory.database import get_db_session
from app.memory.repository import PendingActionRepository
from app.schemas.chat import (
    ChatRequest,
    ConfirmRequest,
    ConfirmResponse,
    StreamChatRequest,
    PendingConfirmResponse,
    MultiDoneResponse,
    MultiConfirmResponse,
    DebateResponse,
    SingleAgentResponse,
    ErrorResponse,
    ToolStepSchema,
)
from app.services.ollama_service import get_ollama_service, OllamaService
from app.services.session_service import SessionService
from app.services.tool_service import get_tool_service, ToolService

router = APIRouter(tags=["chat"])
logger = get_logger(__name__)


def _make_initial_state(request: ChatRequest, history_text: str) -> WorkflowState:
    """Создаёт начальный WorkflowState из запроса."""
    return WorkflowState(
        session_id=request.session,
        user_message=request.message,
        agent_key=request.agent,
        mode=request.mode,
        history_text=history_text,
        results=[],
        current_context="",
        current_code="",
        debate_round=0,
        critic_approved=False,
        pending_action_id=None,
        pending_tool=None,
        pending_params=None,
        pending_agent=None,
        pending_thought="",
        pending_steps=[],
        resume_prompt=None,
        resume_step=0,
        final_response=None,
        final_type="done",
        error_message=None,
        next_node=None,
        images=request.images or [],
    )


@router.post("/chat")
async def chat(
    request: ChatRequest,
    ollama: OllamaService = Depends(get_ollama_service),
    tools: ToolService = Depends(get_tool_service),
):
    """
    Основной chat endpoint.
    Запускает LangGraph workflow в зависимости от mode.
    Возвращает результат или pending confirm.

    ВАЖНО: НЕ держим db сессию открытой во время workflow.ainvoke() —
    workflow может работать минутами (multi-agent pipeline), за это время
    SQLite блокируется и другие запросы падают с "database is locked".
    Открываем короткие сессии только когда реально нужно писать/читать.
    """
    if not request.message.strip():
        return ErrorResponse(response="Пустое сообщение")

    from app.memory.database import get_session_factory
    factory = get_session_factory()

    # ── Транзакция 1: сохранить user msg + прочитать историю ────────────
    async with factory() as db:
        session_service = SessionService(db)
        await session_service.save_user_message(request.session, request.message)
        history_msgs = await session_service.get_history_for_prompt(request.session)
        history_text = session_service.format_history_for_prompt(history_msgs)
        await db.commit()

    # Строим начальный state
    initial_state = _make_initial_state(request, history_text)

    # Получаем workflow
    workflow = get_workflow()

    # Конфигурация thread для LangGraph checkpointer
    # recursion_limit: каждый переход узла графа считается. Автофикс-циклы
    # (coder→verifier→critic→tester→coder) при 3 раундах + внутренние шаги
    # легко превышают дефолт 25. Цикл ОГРАНИЧЕН (debate_max_rounds/test_round),
    # поэтому поднимаем потолок до 60 — хватает на легитимные повторы, но всё
    # ещё ловит настоящее зацикливание.
    config = {
        "configurable": {"thread_id": request.session},
        "recursion_limit": 60,
    }

    try:
        # Запускаем граф
        # Загружаем overrides моделей ОДИН РАЗ — кладём в state
        from app.graph.nodes import _load_agent_models as _lam_once
        initial_state["agent_models"] = await _lam_once()
        from app.graph.nodes import _load_agent_params as _lap_once
        initial_state["agent_params"] = await _lap_once()
        # AGENT_CONTEXT.md существующего проекта (замыкание цикла v109):
        # сильный матч по имени фиксирует active_project сразу.
        try:
            from app.core.project_context import find_project_context
            _pc_name, _pc_block = find_project_context(request.message)
            initial_state["project_context"] = _pc_block
            if _pc_name:
                from app.core.active_project import set_active_project
                set_active_project(_pc_name)
                initial_state["project_name"] = _pc_name
        except Exception:
            initial_state["project_context"] = ""
        initial_state["installed_packages"] = []
        # НЕ затираем project_name, если его зафиксировал сильный матч выше
        initial_state.setdefault("project_name", "")
        # ── Сброс пер-прогонных полей: каждый НОВЫЙ запрос начинает с чистого
        # бюджета раундов. Без этого багфикс-запрос в той же сессии стартовал
        # с раунда 3/6 (хвост прошлого прогона съедал попытки — кейс из лога).
        initial_state["test_round"] = 0
        initial_state["debate_round"] = 0
        initial_state["prev_round_sig"] = ""
        initial_state["last_error_text"] = ""
        initial_state["last_error_sig"] = ""
        initial_state["tests_passed"] = None

        # Уведомляем UI о начале пайплайна
        from app.core import events as _ev
        from app.core.constants import PIPELINE_AGENTS
        # Отмечаем активность — IdleWorker отложит самообучение
        try:
            from app.learning.idle_worker import mark_activity
            mark_activity()
        except Exception:
            pass
        # Сброс read-tracking и чеклиста файлов (новый прогон)
        try:
            from app.core.active_project import reset_run_tracking
            reset_run_tracking()
        except Exception:
            pass
        if request.mode == "multi":
            await _ev.emit(request.session, "pipeline_start",
                           mode=request.mode, agents=PIPELINE_AGENTS)
        else:
            await _ev.emit(request.session, "pipeline_start",
                           mode=request.mode, agents=[request.agent])
        final_state: WorkflowState = await workflow.ainvoke(initial_state, config=config)
    except Exception as e:
        logger.error(f"Workflow error: {e}", exc_info=True)
        # Останавливаем таймер UI даже при ошибке — иначе счётчик тикает вечно
        try:
            from app.core import events as _ev_err
            await _ev_err.emit(request.session, "pipeline_done", final_type="error")
        except Exception:
            pass
        # Особый случай: лимит переходов графа — проект мог УЖЕ быть на диске
        if "RecursionError" in type(e).__name__ or "recursion" in str(e).lower():
            return ErrorResponse(response=(
                "⏱️ Пайплайн сделал слишком много циклов исправления и был остановлен.\n\n"
                "Файлы проекта, скорее всего, уже сохранены в папке Projects — "
                "проверь их. Если проект не запускается, пришли новый запрос "
                "«исправь ошибку запуска в <проект>» — это короткий цикл без полной пересборки."
            ))
        return ErrorResponse(response=f"❌ Ошибка workflow: {e}")

    final_type = final_state.get("final_type", "done")
    results = final_state.get("results", [])

    # Уведомляем UI что пайплайн завершён
    from app.core import events as _ev2
    import asyncio as _aio
    _aio.create_task(_ev2.emit(request.session, "pipeline_done", final_type=final_type))

    # ── Обработка результатов по типу ────────────────────────────────────

    if final_type == "confirm":
        # Одиночный агент ждёт подтверждения
        action_id = final_state.get("pending_action_id", "")
        tool = final_state.get("pending_tool", "")
        params = final_state.get("pending_params", {})
        agent = final_state.get("pending_agent", request.agent)
        steps = final_state.get("pending_steps", [])

        return PendingConfirmResponse(
            action_id=action_id,
            tool=tool,
            params=params,
            agent=agent,
            steps=steps,
            thought=final_state.get("pending_thought", ""),
        )

    if final_type == "multi_confirm":
        # Pipeline ждёт подтверждения
        action_id = final_state.get("pending_action_id", "")
        tool = final_state.get("pending_tool", "")
        params = final_state.get("pending_params", {})
        agent = final_state.get("pending_agent", "")
        steps = final_state.get("pending_steps", [])

        pending = PendingConfirmResponse(
            action_id=action_id,
            tool=tool,
            params=params,
            agent=agent,
            steps=steps,
        )
        return MultiConfirmResponse(results=results[:-1], pending=pending)

    # ── Транзакция 2: сохранить результаты агентов ──────────────────────
    async with factory() as db_save:
        save_service = SessionService(db_save)

        if final_type == "multi_done":
            for r in results:
                await save_service.save_assistant_message(
                    request.session, r.agent, r.response
                )
            await db_save.commit()
            return MultiDoneResponse(results=results)

        if final_type == "debate":
            for r in results:
                await save_service.save_assistant_message(
                    request.session, r.agent, r.response
                )
            await db_save.commit()
            return DebateResponse(results=results)

        # Обычный ответ single агента
        response_text = final_state.get("final_response") or ""
        if not response_text and results:
            # Fallback: берём ответ из последнего результата
            response_text = results[-1].response or ""
        agent_key = request.agent if request.mode == "single" else (
            results[-1].agent if results else request.agent
        )
        await save_service.save_assistant_message(
            request.session, agent_key, response_text
        )
        await db_save.commit()

    agent_steps: list[ToolStepSchema] = []
    if results:
        agent_steps = results[-1].steps

    return SingleAgentResponse(
        response=response_text,
        steps=agent_steps,
        agent=agent_key,
    )


@router.post("/confirm", response_model=ConfirmResponse)
async def confirm(
    request: ConfirmRequest,
    db: AsyncSession = Depends(get_db_session),
    ollama: OllamaService = Depends(get_ollama_service),
    tools: ToolService = Depends(get_tool_service),
):
    """
    Подтверждение/отклонение опасного действия агента.
    Возобновляет workflow после решения пользователя.
    """
    # ── Транзакция 1: прочитать и удалить pending action ────────────────
    # Короткая транзакция — не держим db пока агент думает
    from app.memory.database import get_session_factory
    _factory = get_session_factory()
    async with _factory() as db_read:
        pending_repo = PendingActionRepository(db_read)
        action = await pending_repo.get_and_delete(request.action_id)
        await db_read.commit()

    if action is None:
        raise HTTPException(status_code=404, detail="Действие не найдено или истекло")

    if not request.approved:
        logger.info(f"Action denied: {request.action_id}")
        return ConfirmResponse(
            type="done",
            response="⛔ Действие отменено пользователем.",
            steps=[ToolStepSchema(**s) for s in action["steps"]],
            agent=action["agent"],
        )

    # ── Выполняем инструмент ─────────────────────────────────────────────
    tool_name = action["tool"]
    tool_params = action["params"]
    tool_result = await tools.execute(tool_name, tool_params, skip_approval=True)
    logger.info(f"Action approved and executed: {tool_name}")

    # Определяем режим из сохранённого graph_state
    graph_state = action.get("graph_state", {})
    mode = graph_state.get("mode", "single")

    # Если pip_install успешен — добавляем в контекст
    # чтобы следующие агенты не повторяли check_package/pip_install
    if tool_name == "pip_install" and "[OK]" in tool_result.output:
        packages = tool_params.get("packages", [])
        existing_pkgs = graph_state.get("installed_packages", [])
        all_pkgs = list(set(existing_pkgs + packages))
        graph_state["installed_packages"] = all_pkgs
        installed_info = (
            f"[СИСТЕМНАЯ ИНФОРМАЦИЯ] УЖЕ УСТАНОВЛЕНО: {all_pkgs}. "
            f"ЗАПРЕЩЕНО вызывать pip_install снова. Сразу пиши код.\n\n"
        )
        # В НАЧАЛО prompt — агент увидит первым
        graph_state["current_context"] = installed_info + graph_state.get("current_context", "")
        action["prompt_text"] = installed_info + action.get("prompt_text", "")

    # ── MULTI MODE: возобновляем ВЕСЬ граф ───────────────────────────────
    # После подтверждения в pipeline — продолжаем с того места где остановились.
    # resume_after_confirm только для single, иначе Критик/Тестер/save_project
    # никогда не запустятся.
    if mode in ("multi", "debate"):
        from app.agents.registry import create_agent as _ca
        from app.graph.workflow import get_workflow

        # Возобновляем агента с правильной моделью из Settings БД
        from app.graph.nodes import _load_agent_models as _lam
        _confirm_models = await _lam()
        existing_steps = [ToolStepSchema(**s) for s in action["steps"]]
        agent = _ca(action["agent"], ollama, tools,
                    model_override=_confirm_models.get(action["agent"]))
        run_result = await agent.resume_after_confirm(
            resume_prompt=action["prompt_text"],
            tool_name=tool_name,
            tool_result=tool_result.output,
            step_num=action["current_step"],
            existing_steps=existing_steps,
            session_id=action["session_id"],
        )

        # Обновляем graph_state ответом агента и продолжаем pipeline
        resumed_state = dict(graph_state)
        resumed_state["current_code"] = run_result.response
        resumed_state["pending_action_id"] = None

        # Добавляем результат агента в results
        from app.schemas.chat import AgentResultSchema as _ARS
        existing_results = resumed_state.get("results", [])
        agent_result = _ARS(
            type="done",
            agent=action["agent"],
            response=run_result.response,
            steps=run_result.steps,
            label=f"{action['agent']} (продолжение)",
        )
        resumed_state["results"] = list(existing_results) + [agent_result]

        # Определяем откуда продолжать граф
        # Кодер → Критик, Тестер → save_project
        agent_to_next = {
            "coder": "critic",
            "manager": "architect",
            "architect": "coder",
            "critic": "coder",
            "tester": "human_approval",
        }
        resumed_state["next_node"] = agent_to_next.get(action["agent"], "save_project")

        # Переинвокируем граф с обновлённым state
        # Перезапускаем SSE pipeline прогресс
        from app.core import events as _ev_resume
        from app.core.constants import PIPELINE_AGENTS
        await _ev_resume.emit(action["session_id"], "pipeline_start",
                              mode="multi", agents=PIPELINE_AGENTS,
                              resumed=True)
        workflow = get_workflow()
        config = {"configurable": {"thread_id": action["session_id"] + "_resume"}}
        try:
            final_state = await workflow.ainvoke(resumed_state, config=config)
        except Exception as e:
            logger.error(f"Pipeline resume error: {e}", exc_info=True)
            final_state = resumed_state

        final_type = final_state.get("final_type", "done")
        results = final_state.get("results", [])

        # Уведомляем UI что resume pipeline завершён
        import asyncio as _aio2
        _aio2.create_task(_ev_resume.emit(
            action["session_id"], "pipeline_done", final_type=final_type))

        # Сохраняем все результаты
        # results могут быть Pydantic объектами или dict — обрабатываем оба случая
        async with _factory() as db_save:
            save_service = SessionService(db_save)
            for r in results:
                if isinstance(r, dict):
                    agent_key = r.get("agent", action["agent"])
                    response_text = r.get("response", "")
                else:
                    agent_key = getattr(r, "agent", action["agent"])
                    response_text = getattr(r, "response", "")
                if response_text:
                    await save_service.save_assistant_message(
                        action["session_id"], agent_key, response_text
                    )
            await db_save.commit()

        if final_type == "multi_done":
            from app.schemas.chat import MultiDoneResponse
            return MultiDoneResponse(results=results)

        return ConfirmResponse(
            type="done",
            response=final_state.get("final_response") or run_result.response,
            steps=run_result.steps,
            agent=action["agent"],
        )

    # ── SINGLE MODE: возобновляем только агента ───────────────────────────
    from app.agents.registry import create_agent
    agent = create_agent(action["agent"], ollama, tools)
    existing_steps = [ToolStepSchema(**s) for s in action["steps"]]

    run_result = await agent.resume_after_confirm(
        resume_prompt=action["prompt_text"],
        tool_name=tool_name,
        tool_result=tool_result.output,
        step_num=action["current_step"],
        existing_steps=existing_steps,
        session_id=action["session_id"],
    )

    # ── Транзакция 2: сохранить ответ агента ──────────────────────────────
    async with _factory() as db_save:
        save_service = SessionService(db_save)
        await save_service.save_assistant_message(
            action["session_id"], action["agent"], run_result.response,
        )
        await db_save.commit()

    return ConfirmResponse(
        type="done",
        response=run_result.response,
        steps=run_result.steps,
        agent=action["agent"],
    )


@router.post("/stream")
async def stream(
    request: StreamChatRequest,
    db: AsyncSession = Depends(get_db_session),
    ollama: OllamaService = Depends(get_ollama_service),
):
    """
    Стриминговая генерация — возвращает токены по одному.
    Используется только в режиме 'stream' (одиночный агент).
    """

    session_service = SessionService(db)
    await session_service.save_user_message(request.session, request.message)

    history_msgs = await session_service.get_history_for_prompt(request.session)
    history_text = session_service.format_history_for_prompt(history_msgs)

    # Строим промпт напрямую без graph
    from app.agents.registry import create_agent
    agent = create_agent(request.agent, ollama, get_tool_service())
    prompt = agent._build_prompt(request.message, history_text)

    async def generate_tokens():
        full_response = ""
        try:
            async for token in ollama.generate_stream(prompt):
                full_response += token
                data = json.dumps({"token": token, "done": False}, ensure_ascii=False)
                yield f"data: {data}\n\n"
        except Exception as e:
            error_data = json.dumps({"token": f"❌ {e}", "done": True})
            yield f"data: {error_data}\n\n"
            return

        # Финальный токен
        yield f"data: {json.dumps({'token': '', 'done': True})}\n\n"

        # Сохраняем полный ответ после завершения стрима
        # Используем отдельную db сессию т.к. текущая может быть закрыта
        try:
            from app.memory.database import get_session_factory
            factory = get_session_factory()
            async with factory() as save_db:
                save_service = SessionService(save_db)
                await save_service.save_assistant_message(
                    request.session, request.agent, full_response
                )
                await save_db.commit()
        except Exception as e:
            logger.error(f"Failed to save stream response: {e}")

    return StreamingResponse(
        generate_tokens(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )
