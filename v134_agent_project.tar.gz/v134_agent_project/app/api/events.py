"""
Events API — SSE стриминг прогресса пайплайна.

GET /events/{session_id}
  → Server-Sent Events stream
  → Клиент получает события в реальном времени

Клиент подключается ПЕРЕД отправкой /chat запроса.
Поток закрывается автоматически когда пайплайн завершается.
"""
from fastapi import APIRouter
from fastapi.responses import StreamingResponse

from app.core.events import event_generator

router = APIRouter()


@router.get("/events/{session_id}")
async def stream_events(session_id: str):
    """
    SSE endpoint для получения событий пайплайна в реальном времени.

    Использование (JS):
        const es = new EventSource(`/events/${sessionId}`);
        es.onmessage = (e) => {
            const event = JSON.parse(e.data);
            updateProgress(event);
        };

    После получения события type='pipeline_done' или 'error'
    поток закрывается автоматически.
    """
    return StreamingResponse(
        event_generator(session_id),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",  # отключаем nginx буфферинг
            "Connection": "keep-alive",
        },
    )
