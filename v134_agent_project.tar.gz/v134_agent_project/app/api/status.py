"""
Status API — состояние системы.
GET /status — здоровье всех компонентов
"""
from fastapi import APIRouter, Depends
from pydantic import BaseModel

from app.core.config import settings
from app.core.constants import APP_NAME, APP_VERSION
from app.sandbox.docker_runner import get_docker_runner
from app.services.ollama_service import OllamaService, get_ollama_service

router = APIRouter(tags=["status"])


class StatusResponse(BaseModel):
    app_name: str
    version: str
    model: str
    default_model: str
    sandbox: str
    docker_available: bool
    projects_dir: str
    ollama_url: str
    num_ctx: int
    temperature: float


@router.get("/status", response_model=StatusResponse)
async def get_status(
    ollama: OllamaService = Depends(get_ollama_service),
):
    """Статус системы — все параметры конфигурации."""
    runner = get_docker_runner()
    return StatusResponse(
        app_name=APP_NAME,
        version=APP_VERSION,
        model=ollama.current_model,
        default_model=settings.default_model,
        sandbox=runner.get_sandbox_info(),
        docker_available=runner.docker_available,
        projects_dir=settings.projects_dir,
        ollama_url=settings.ollama_base_url,
        num_ctx=settings.num_ctx,
        temperature=settings.temperature,
    )


@router.get("/metrics")
async def get_metrics():
    """
    Метрики производительности — агенты, инструменты, sandbox.
    Показывает avg/max/min duration_ms, кол-во вызовов, ошибки.
    """
    from app.core.metrics import metrics
    return metrics.snapshot()


@router.get("/learning")
async def get_learning_status():
    """
    Статус самообучения: воркер, очередь рефлексии, нерешённые ошибки,
    база уроков. IdleWorker учится когда система простаивает >10 мин.
    """
    from app.learning.idle_worker import status
    return status()
