"""
Files API — браузер файловой системы.
GET /files    — список файлов/папок
GET /projects — список сохранённых проектов
"""
from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.constants import PROJECTS_API_LIMIT
from app.core.logger import get_logger
from app.memory.database import get_db_session
from app.schemas.message import ProjectSchema
from app.services.project_service import ProjectService
from app.tools.list_files import ListFilesTool
from app.schemas.tool import ListFilesParams

import json

from fastapi import UploadFile, File

router = APIRouter(tags=["files"])
logger = get_logger(__name__)

# Папка загрузок пользователя — внутри Projects/, доступна read_file
_UPLOADS_SUBDIR = "_uploads"
_MAX_UPLOAD_BYTES = 50 * 1024 * 1024  # 50MB


@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    """
    Загрузка файла ЛЮБОГО формата с диска пользователя.
    Сохраняется в Projects/_uploads/, агент работает через
    read_file / analyze_image / extract_archive.
    """
    import os, re, time
    from app.core.config import settings

    raw_name = os.path.basename(file.filename or "file")
    # Санитизация имени: буквы/цифры/._- (кириллица ок)
    safe_name = re.sub(r"[^\w.\-а-яА-ЯёЁ]", "_", raw_name)[:120] or "file"
    uploads_dir = os.path.join(os.path.realpath(settings.projects_dir), _UPLOADS_SUBDIR)
    os.makedirs(uploads_dir, exist_ok=True)

    target = os.path.join(uploads_dir, safe_name)
    if os.path.exists(target):  # не перетираем — добавляем таймстемп
        stem, ext = os.path.splitext(safe_name)
        target = os.path.join(uploads_dir, f"{stem}_{int(time.time())}{ext}")

    size = 0
    try:
        with open(target, "wb") as out:
            while chunk := await file.read(1024 * 1024):
                size += len(chunk)
                if size > _MAX_UPLOAD_BYTES:
                    out.close()
                    os.unlink(target)
                    return {"ok": False, "error": f"Файл больше {_MAX_UPLOAD_BYTES // 1024 // 1024}MB"}
                out.write(chunk)
    except Exception as e:
        return {"ok": False, "error": str(e)}

    rel_path = f"{_UPLOADS_SUBDIR}/{os.path.basename(target)}"
    logger.info(f"upload: {rel_path} ({size // 1024}KB)")
    return {"ok": True, "path": rel_path, "size": size}


class FilesResponse(BaseModel):
    ok: bool
    path: str = ""
    items: list[dict] = Field(default_factory=list)
    error: str = ""


class ProjectsResponse(BaseModel):
    projects: list[ProjectSchema]


@router.get("/files")
async def list_files(
    path: str = Query(default="", description="Путь к директории"),
):
    """
    Список файлов и папок.
    Если path не указан — показывает Projects директорию.
    """
    params = ListFilesParams(path=path if path else None)
    result_json = await ListFilesTool().execute(params)

    try:
        data = json.loads(result_json)
        return data
    except json.JSONDecodeError:
        return FilesResponse(ok=False, error="Ошибка парсинга результата")


@router.get("/projects", response_model=ProjectsResponse)
async def list_projects(
    limit: int = Query(default=PROJECTS_API_LIMIT, ge=1, le=100),
    db: AsyncSession = Depends(get_db_session),
):
    """Список сохранённых проектов."""
    service = ProjectService(db)
    projects = await service.list_projects(limit=limit)
    schemas = [
        ProjectSchema(
            id=p.id,
            name=p.name,
            path=p.path,
            session_id=p.session_id,
            created_at=p.created_at,
        )
        for p in projects
    ]
    return ProjectsResponse(projects=schemas)
