"""
Settings API — управление настройками агентной системы.
GET /settings — получить все настройки
POST /settings — обновить настройку
GET /settings/models — список доступных моделей из Ollama
"""
import httpx
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from app.agents.prompts import AGENTS
from app.core.config import settings
from app.core.logger import get_logger
from app.memory.database import get_db_session
from app.memory.repository import SettingRepository

logger = get_logger(__name__)
router = APIRouter()


class SettingUpdate(BaseModel):
    key: str
    value: str


@router.get("/settings")
async def get_settings(db: AsyncSession = Depends(get_db_session)):
    """Получить все настройки включая модели агентов."""
    repo = SettingRepository(db)

    result = {}

    # Конфиги агентов с их текущими моделями и параметрами (из БД или дефолт)
    agents = []
    for key, cfg in AGENTS.items():
        db_model = await repo.get(f"agent_model:{key}")
        db_temp = await repo.get(f"agent_temp:{key}")
        db_npredict = await repo.get(f"agent_npredict:{key}")
        db_steps = await repo.get(f"agent_steps:{key}")
        agents.append({
            "key": key,
            "name": cfg["name"],
            "emoji": cfg["emoji"],
            "default_model": cfg.get("model", ""),
            "current_model": db_model or cfg.get("model", ""),
            "default_temperature": cfg.get("temperature", 0.3),
            "current_temperature": db_temp or "",
            "default_num_predict": settings.num_predict,
            "current_num_predict": db_npredict or "",
            "default_max_steps": cfg.get("max_steps", 10),
            "current_max_steps": db_steps or "",
        })

    result["agents"] = agents
    result["global_model"] = await repo.get("global_model") or settings.default_model

    # auto_approve — берём из памяти + синхронизируем с БД при старте
    from app.core.auto_approve import is_auto_approve
    result["auto_approve"] = is_auto_approve()

    return result


@router.post("/settings")
async def update_setting(
    update: SettingUpdate,
    db: AsyncSession = Depends(get_db_session),
):
    """Обновить настройку."""
    repo = SettingRepository(db)
    await repo.set(update.key, update.value)
    await db.commit()

    # Если меняем auto_approve — обновляем состояние в памяти сразу
    if update.key == "auto_approve":
        from app.core.auto_approve import set_auto_approve
        set_auto_approve(update.value.lower() in ("true", "1", "yes"))
        logger.info(f"auto_approve: {'включён' if update.value.lower() in ('true','1','yes') else 'выключен'}")

    logger.info(f"Setting updated: {update.key} = {update.value}")
    return {"ok": True, "key": update.key, "value": update.value}


@router.get("/settings/models")
async def get_available_models():
    """Получить список моделей из Ollama."""
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            r = await client.get(f"{settings.ollama_base_url}/api/tags")
            r.raise_for_status()
            data = r.json()
            models = [m["name"] for m in data.get("models", [])]
            return {"ok": True, "models": models}
    except Exception as e:
        logger.warning(f"Could not fetch Ollama models: {e}")
        return {"ok": False, "models": [], "error": str(e)}
