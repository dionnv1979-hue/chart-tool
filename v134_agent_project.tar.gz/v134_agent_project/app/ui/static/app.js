'use strict';

// ── State ─────────────────────────────────────────────────────────────────────
const AG = {
  single:    { name: 'Qwen Agent',  emoji: '🤖', color: '#00d4aa' },
  manager:   { name: 'Менеджер',    emoji: '🧠', color: '#00d4aa' },
  architect: { name: 'Архитектор',  emoji: '📐', color: '#7c3aed' },
  coder:     { name: 'Кодер',       emoji: '💻', color: '#3b82f6' },
  critic:    { name: 'Критик',      emoji: '🔍', color: '#f59e0b' },
  tester:    { name: 'Тестер',      emoji: '🧪', color: '#10b981' },
};

let curAgent   = 'single';
let curMode    = 'single';
let curSession = 'session_' + Date.now();
let pendingImages = [];
let waiting    = false;

// ── API helpers ───────────────────────────────────────────────────────────────
async function apiPost(url, body) {
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!r.ok) {
    const text = await r.text();
    throw new Error(`HTTP ${r.status}: ${text.slice(0, 200)}`);
  }
  const text = await r.text();
  return text ? JSON.parse(text) : {};
}

async function apiGet(url) {
  const r = await fetch(url);
  if (!r.ok) {
    const text = await r.text();
    throw new Error(`HTTP ${r.status}: ${text.slice(0, 200)}`);
  }
  const text = await r.text();
  return text ? JSON.parse(text) : {};
}

// ── Sidebar ───────────────────────────────────────────────────────────────────
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('hidden');
}

// ── Mode ──────────────────────────────────────────────────────────────────────
function setMode(m) {
  curMode = m;
  ['single', 'multi'].forEach(x => {
    document.getElementById('m_' + x)?.classList.toggle('on', x === m);
  });
  const labels = { single: '🤖 Одиночный', multi: '🔗 Мультиагент' };
  const el = document.getElementById('modeLabel');
  if (el) el.textContent = labels[m] || m;

  // В мультиагент скрываем выбор агента — команда работает автоматически
  const isMulti = m === 'multi';
  const agentLabel = document.getElementById('agentLabel');
  const agentList  = document.getElementById('agentList');
  const hint       = document.getElementById('modeHint');
  if (agentLabel) agentLabel.style.display = isMulti ? 'none' : '';
  if (agentList)  agentList.style.display  = isMulti ? 'none' : '';
  if (hint) hint.textContent = isMulti
    ? '🔗 Менеджер → Архитектор → Кодер → Критик → Тестер'
    : '💬 Чат с выбранным агентом';
}

// ── Agent list ────────────────────────────────────────────────────────────────
function buildAgentList() {
  const el = document.getElementById('agentList');
  el.innerHTML = '';
  Object.entries(AG).forEach(([k, a]) => {
    const btn = document.createElement('button');
    btn.className = 'agent-btn' + (k === curAgent ? ' on' : '');
    const dot = document.createElement('div');
    dot.className = 'agent-dot';
    dot.style.background = a.color;
    const lbl = document.createElement('span');
    lbl.textContent = a.emoji + ' ' + a.name;
    btn.appendChild(dot);
    btn.appendChild(lbl);
    btn.onclick = () => { curAgent = k; buildAgentList(); };
    el.appendChild(btn);
  });
}

// ── Models ────────────────────────────────────────────────────────────────────
async function loadModels() {
  const data = await apiGet('/models');
  if (!data.ok) return;
  document.getElementById('currentModel').textContent = data.current || '—';
  renderModelDropdown(data.current, data.models || []);
}

function renderModelDropdown(current, models) {
  const el = document.getElementById('modelList');
  el.innerHTML = '';
  models.forEach(m => {
    const item = document.createElement('div');
    item.className = 'model-item' + (m.name === current ? ' active' : '');
    item.textContent = m.name;
    item.title = `${(m.size / 1e9).toFixed(1)} GB`;
    item.onclick = () => selectModel(m.name);
    el.appendChild(item);
  });
}

function toggleModelDropdown() {
  document.getElementById('modelDropdown').classList.toggle('open');
}

async function selectModel(name) {
  setStatus('Переключаю модель...', true);
  const d = await apiPost('/model', { name });
  if (d.ok) {
    document.getElementById('currentModel').textContent = d.current;
    document.getElementById('modelDropdown').classList.remove('open');
    await loadModels();
    setStatus('Готов');
  } else {
    alert('Ошибка: ' + d.error);
    setStatus('Готов');
  }
}

// ── Sessions ──────────────────────────────────────────────────────────────────
async function loadSessions() {
  const data = await apiGet('/sessions');
  const sessions = data.sessions || [];
  const el = document.getElementById('sessionList');
  el.innerHTML = '';

  // При первой загрузке — восстанавливаем последнюю сессию из localStorage или из списка
  if (!_sessionsLoaded && sessions.length > 0) {
    _sessionsLoaded = true;
    const saved = localStorage.getItem('lastSession');
    curSession = (saved && sessions.includes(saved)) ? saved : sessions[0];
    loadHistory();
  }

  sessions.forEach(s => {
    const d = document.createElement('div');
    d.className = 'session-item' + (s === curSession ? ' on' : '');
    // Показываем дату и время из session_1234567890
    const ts = parseInt(s.replace('session_', ''));
    const label = ts ? new Date(ts).toLocaleString('ru', {
      month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit'
    }) : s.substring(0, 14);
    d.textContent = label;
    d.title = s;
    d.onclick = () => { curSession = s; localStorage.setItem('lastSession', s); loadHistory(); loadSessions(); };
    el.appendChild(d);
  });
}
let _sessionsLoaded = false;

function newSession() {
  curSession = 'session_' + Date.now();
  document.getElementById('chat').innerHTML = '<div class="welcome"><h2>Новая сессия</h2></div>';
  loadSessions();
}

async function clearSession() {
  await apiPost('/clear', { session: curSession });
  document.getElementById('chat').innerHTML = '';
  loadSessions();
}

async function loadHistory() {
  const data = await apiGet('/history?session=' + curSession);
  const msgs = data.messages || [];
  const chat = document.getElementById('chat');
  chat.innerHTML = '';
  msgs.forEach(m => {
    if (m.role === 'user') addMsg(m.content, 'user');
    else addMsg(m.content, 'bot', m.agent);
  });
}

// ── File browser ──────────────────────────────────────────────────────────────
async function loadFiles(path) {
  const url = '/files' + (path ? '?path=' + encodeURIComponent(path) : '');
  const data = await apiGet(url);
  document.getElementById('fbPath').textContent = data.path || '~/Projects';
  const el = document.getElementById('fbList');
  el.innerHTML = '';

  if (!data.ok) {
    const err = document.createElement('div');
    err.style.cssText = 'color:var(--err);font-size:11px;padding:4px 6px';
    err.textContent = data.error || 'Ошибка';
    el.appendChild(err);
    return;
  }

  // Кнопка "наверх"
  const up = document.createElement('div');
  up.className = 'fb-item dir';
  up.textContent = '↑ ..';
  up.onclick = () => {
    const parts = (data.path || '').replace(/\\/g, '/').split('/');
    loadFiles(parts.slice(0, -1).join('/') || '.');
  };
  el.appendChild(up);

  (data.items || []).forEach(item => {
    const d = document.createElement('div');
    d.className = 'fb-item' + (item.kind === 'dir' ? ' dir' : '');
    const icon = item.kind === 'dir' ? '📁 ' : '📄 ';
    const size = item.size ? ` (${(item.size / 1024).toFixed(1)}k)` : '';
    d.textContent = icon + item.name + size;
    d.title = item.path;
    d.onclick = () => {
      if (item.kind === 'dir') {
        loadFiles(item.path);
      } else {
        document.getElementById('inp').value = `Прочитай файл: ${item.path}`;
        document.getElementById('inp').focus();
      }
    };
    el.appendChild(d);
  });
}

// ── Status ────────────────────────────────────────────────────────────────────
function setStatus(text, loading = false) {
  document.getElementById('stTxt').textContent = text;
  const dot = document.getElementById('statusDot');
  dot.classList.toggle('loading', loading);
}

// ── DOM helpers ───────────────────────────────────────────────────────────────
function autoResize(el) {
  el.style.height = 'auto';
  el.style.height = Math.min(el.scrollHeight, 140) + 'px';
}

function scrollChat() {
  const chat = document.getElementById('chat');
  chat.scrollTop = chat.scrollHeight;
}

// ── Messages ──────────────────────────────────────────────────────────────────
function addMsg(text, role, agent = 'single') {
  const chat = document.getElementById('chat');
  document.querySelector('.welcome')?.remove();

  const wrap = document.createElement('div');
  wrap.className = 'msg-wrap ' + role;

  const lbl = document.createElement('div');
  lbl.className = 'msg-label';
  if (role === 'user') {
    lbl.textContent = 'Вы';
  } else {
    const a = AG[agent] || AG.single;
    lbl.textContent = `${a.emoji} ${a.name} • ${new Date().toLocaleTimeString('ru')}`;
    lbl.style.color = a.color;
  }

  const msg = document.createElement('div');
  msg.className = 'msg ' + role;
  msg.textContent = text;

  if (text.includes('APPROVED')) {
    const badge = document.createElement('div');
    badge.className = 'approved-badge';
    badge.textContent = '✅ APPROVED';
    wrap.appendChild(lbl);
    wrap.appendChild(msg);
    wrap.appendChild(badge);
  } else {
    wrap.appendChild(lbl);
    wrap.appendChild(msg);
  }

  chat.appendChild(wrap);
  scrollChat();
  return msg;
}

function addThinking(text = 'Думает...') {
  document.querySelector('.thinking')?.remove();
  const chat = document.getElementById('chat');
  const d = document.createElement('div');
  d.className = 'thinking';
  d.innerHTML = `<div class="dots"><span></span><span></span><span></span></div><span>${text}</span>`;
  chat.appendChild(d);
  scrollChat();
}

function removeThinking() {
  document.querySelector('.thinking')?.remove();
}

// ── Tool steps ────────────────────────────────────────────────────────────────
function addSteps(steps, parent) {
  const container = parent || document.getElementById('chat');
  (steps || []).forEach(s => {
    if (!s.tool) return;
    const card = document.createElement('div');
    card.className = 'step-card';

    const header = document.createElement('div');
    header.className = 'step-header';
    header.textContent = `⚡ ${s.tool}(${JSON.stringify(s.params || {}).slice(0, 60)})`;

    const result = document.createElement('div');
    result.className = 'step-result';
    result.textContent = (s.result || '').slice(0, 300);

    card.appendChild(header);
    card.appendChild(result);
    container.appendChild(card);
  });
  scrollChat();
}

// ── Multi / Debate blocks ─────────────────────────────────────────────────────
function addMultiOrDebate(results, wrapClass) {
  const chat = document.getElementById('chat');
  document.querySelector('.welcome')?.remove();

  const wrap = document.createElement('div');
  wrap.className = wrapClass;

  results.forEach(r => {
    if (!r.response) return;
    const a = AG[r.agent] || AG.single;

    const block = document.createElement('div');
    block.className = 'agent-block';
    block.style.borderColor = a.color + '44';

    const header = document.createElement('div');
    header.className = 'agent-block-header';
    header.style.cssText = `background:${a.color}18;color:${a.color}`;
    header.textContent = `${a.emoji} ${a.name}`;

    if (r.label) {
      const badge = document.createElement('span');
      badge.className = 'round-badge';
      badge.textContent = r.label;
      header.appendChild(badge);
    }

    const body = document.createElement('div');
    body.className = 'agent-block-body';
    body.textContent = r.response;

    block.appendChild(header);
    block.appendChild(body);

    if (r.steps && r.steps.length) {
      addSteps(r.steps, block);
    }

    if ((r.response || '').includes('APPROVED')) {
      const badge = document.createElement('div');
      badge.className = 'approved-badge';
      badge.textContent = '✅ APPROVED';
      badge.style.margin = '4px 12px 10px';
      block.appendChild(badge);
    }

    wrap.appendChild(block);
  });

  chat.appendChild(wrap);
  scrollChat();
}

// ── Confirm box ───────────────────────────────────────────────────────────────
function addConfirm(data) {
  removeThinking();
  const chat = document.getElementById('chat');

  const box = document.createElement('div');
  box.className = 'confirm-box';
  box.id = 'cfm_' + data.action_id;

  const title = document.createElement('div');
  title.className = 'confirm-title';
  title.textContent = `⚠️ Агент хочет выполнить: ${data.tool}`;

  const pre = document.createElement('div');
  pre.className = 'confirm-pre';
  pre.textContent = JSON.stringify(data.params, null, 2).slice(0, 600);

  if (data.thought) {
    const thought = document.createElement('div');
    thought.style.cssText = 'font-size:12px;color:var(--text-dim);margin-bottom:8px;padding:6px 8px;background:var(--bg3);border-radius:6px;';
    thought.textContent = '💭 ' + data.thought.slice(0, 200);
    box.appendChild(title);
    box.appendChild(thought);
    box.appendChild(pre);
  } else {
    box.appendChild(title);
    box.appendChild(pre);
  }

  const btns = document.createElement('div');
  btns.className = 'confirm-btns';

  const allow = document.createElement('button');
  allow.className = 'confirm-btn allow';
  allow.textContent = '✅ Разрешить';
  allow.addEventListener('click', () => confirmAct(data.action_id, true));

  const deny = document.createElement('button');
  deny.className = 'confirm-btn deny';
  deny.textContent = '❌ Запретить';
  deny.addEventListener('click', () => confirmAct(data.action_id, false));

  btns.appendChild(allow);
  btns.appendChild(deny);
  box.appendChild(btns);

  chat.appendChild(box);
  scrollChat();
}

async function confirmAct(actionId, approved) {
  document.getElementById('cfm_' + actionId)?.remove();
  addThinking('Выполняю...');

  // Перезапускаем SSE при одобрении — pipeline продолжается
  if (approved && curSession) {
    startPipelineSSE(curSession,
      ['manager', 'architect', 'coder', 'critic', 'tester']);
  }

  const d = await apiPost('/confirm', { action_id: actionId, approved });
  removeThinking();

  if (d.steps) addSteps(d.steps);
  addMsg(d.response || '(нет ответа)', 'bot', d.agent);
  setStatus('Готов');
  waiting = false;
  document.getElementById('sendBtn').disabled = false;
}

// ── Stream mode ───────────────────────────────────────────────────────────────
async function sendStream(msg) {
  document.querySelector('.welcome')?.remove();
  const chat = document.getElementById('chat');

  addMsg(msg, 'user');

  const wrap = document.createElement('div');
  wrap.className = 'msg-wrap bot';

  const a = AG[curAgent] || AG.single;
  const lbl = document.createElement('div');
  lbl.className = 'msg-label';
  lbl.textContent = `${a.emoji} ${a.name} • ${new Date().toLocaleTimeString('ru')}`;
  lbl.style.color = a.color;

  const msgEl = document.createElement('div');
  msgEl.className = 'msg bot';

  const cursor = document.createElement('span');
  cursor.className = 'stream-cursor';

  wrap.appendChild(lbl);
  wrap.appendChild(msgEl);
  chat.appendChild(wrap);
  msgEl.appendChild(cursor);
  scrollChat();

  try {
    const response = await fetch('/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message: msg, agent: curAgent, session: curSession }),
    });

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        try {
          const parsed = JSON.parse(line.slice(6));
          if (parsed.token) {
            // Убираем cursor, добавляем токен, возвращаем cursor
            cursor.remove();
            msgEl.textContent += parsed.token;
            msgEl.appendChild(cursor);
            scrollChat();
          }
          if (parsed.done) break;
        } catch (_) { /* ignore parse errors */ }
      }
    }
  } catch (e) {
    msgEl.textContent = '❌ Ошибка: ' + e.message;
  }

  cursor.remove();
  setStatus('Готов');
  waiting = false;
  document.getElementById('sendBtn').disabled = false;
}

// ── Main send ─────────────────────────────────────────────────────────────────
async function send() {
  const inp = document.getElementById('inp');
  const text = inp.value.trim();
  if (!text || waiting) return;

  waiting = true;
  inp.value = '';
  inp.style.height = 'auto';
  document.getElementById('sendBtn').disabled = true;
  setStatus('Обрабатываю...', true);

  if (curMode === 'stream') {
    await sendStream(text);
    return;
  }

  addMsg(text, 'user');

  const thinkingMessages = {
    debate: '⚔️ Дебаты (Кодер↔Критик)...',
    multi:  '🔗 Pipeline (Manager→Architect→Coder→Critic→Tester)...',
    single: '🤖 Думает...',
  };
  addThinking(thinkingMessages[curMode] || '🤖 Думает...');

  try {
    // Сохраняем текущую сессию в localStorage
    localStorage.setItem('lastSession', curSession);

    // Запускаем SSE до отправки запроса
    const pipelineAgents = curMode === 'multi'
        ? ['manager', 'architect', 'coder', 'critic', 'tester']
        : [curAgent];
    startPipelineSSE(curSession, pipelineAgents);

    const d = await apiPost('/chat', {
      message: text,
      agent: curAgent,
      session: curSession,
      mode: curMode,
      images: pendingImages.slice(),
    });
    if (pendingImages.length > 0) clearImage();

    removeThinking();

    if (d.type === 'confirm') {
      addSteps(d.steps || []);
      addConfirm(d);
      setStatus('Ожидание подтверждения');
      return; // waiting остаётся true до confirmAct
    }

    if (d.type === 'debate') {
      addMultiOrDebate(d.results || [], 'debate-wrap');
    } else if (d.type === 'multi_done') {
      addMultiOrDebate(d.results || [], 'multi-wrap');
    } else if (d.type === 'multi_confirm') {
      addMultiOrDebate((d.results || []).slice(0, -1), 'multi-wrap');
      addConfirm(d.pending);
      setStatus('Ожидание подтверждения');
      return;
    } else if (d.type === 'error') {
      addMsg('❌ ' + d.response, 'bot', 'single');
    } else {
      addSteps(d.steps || []);
      addMsg(d.response || '(нет ответа)', 'bot', d.agent || curAgent);
    }

  } catch (e) {
    removeThinking();
    addMsg('❌ Ошибка сети: ' + e.message, 'bot', 'single');
  }

  setStatus('Готов');
  waiting = false;
  document.getElementById('sendBtn').disabled = false;
}

// ── File upload ───────────────────────────────────────────────────────────────
// ── Типы файлов ───────────────────────────────────────────────────
const IMAGE_EXTS = ['jpg','jpeg','png','webp','gif','bmp'];
const VIDEO_EXTS = ['mp4','avi','mov','mkv','webm'];
const TEXT_EXTS  = ['txt','py','js','ts','jsx','tsx','json','md','yaml','yml','toml',
                    'csv','html','css','log','sh','bat','ini','env','xml','sql',
                    'go','rs','rb','php','java','c','cpp','h'];

function clearImage() {
  pendingImages = [];
  const p = document.getElementById('imagePreview');
  if (p) p.style.display = 'none';
}

async function uploadToServer(file) {
  const fd = new FormData();
  fd.append('file', file);
  const resp = await fetch('/upload', { method: 'POST', body: fd });
  return resp.json();
}

function loadFile(input) {
  const file = input.files[0];
  if (!file) return;
  input.value = '';
  const ext = file.name.split('.').pop().toLowerCase();
  const inp = document.getElementById('inp');

  // ── Картинки: base64 для vision-превью + на диск для analyze_image ──
  if (IMAGE_EXTS.includes(ext)) {
    if (file.size > 10 * 1024 * 1024) { addMsg('❌ Изображение > 10MB', 'bot', 'single'); return; }
    const reader = new FileReader();
    reader.onload = e => {
      const dataUrl = e.target.result;
      pendingImages = [dataUrl.split(',')[1]];
      const preview = document.getElementById('imagePreview');
      const img = document.getElementById('previewImg');
      const lbl = document.getElementById('previewLabel');
      if (preview) { preview.style.display = 'block'; }
      if (img) img.src = dataUrl;
      if (lbl) lbl.textContent = '📷 ' + file.name + ' (' + (file.size/1024).toFixed(0) + 'KB)';
    };
    reader.readAsDataURL(file);
    // Параллельно на диск — для multi-агентов через analyze_image
    uploadToServer(file).then(r => {
      if (r.ok && inp && !inp.value) {
        inp.value = 'Проанализируй изображение ' + r.path +
                    ' (analyze_image) и скажи что на нём.';
        inp.dispatchEvent(new Event('input'));
      } else if (inp && !inp.value) {
        inp.value = 'Что на этом изображении?';
      }
    }).catch(() => { if (inp && !inp.value) inp.value = 'Что на этом изображении?'; });
    return;
  }

  if (VIDEO_EXTS.includes(ext)) { extractVideoFrames(file); return; }

  // ── Мелкий текст: инлайн в сообщение (мгновенно в контексте) ──
  if (TEXT_EXTS.includes(ext) && file.size <= 100 * 1024) {
    const reader = new FileReader();
    reader.onload = e => {
      const content = e.target.result;
      if (content.includes('\u0000')) { addMsg('❌ Бинарный файл с текстовым расширением', 'bot', 'single'); return; }
      inp.value = '[Файл: ' + file.name + ']\n```\n' + content.slice(0,3000) + '\n```\n\nПомоги.';
      inp.dispatchEvent(new Event('input'));
    };
    reader.readAsText(file, 'utf-8');
    return;
  }

  // ── ВСЁ ОСТАЛЬНОЕ (pdf, docx, xlsx, zip, большой код, любой бинарь) ──
  // на диск → агент работает через read_file / extract_archive
  if (file.size > 50 * 1024 * 1024) { addMsg('❌ Файл > 50MB', 'bot', 'single'); return; }
  addMsg('⏳ Загружаю ' + file.name + ' (' + (file.size/1024).toFixed(0) + 'KB)...', 'bot', 'single');
  uploadToServer(file).then(r => {
    if (!r.ok) { addMsg('❌ Загрузка не удалась: ' + (r.error || '?'), 'bot', 'single'); return; }
    addMsg('✅ Загружен: ' + r.path, 'bot', 'single');
    const isArchive = ['zip','tar','gz','tgz','bz2','rar','7z'].includes(ext);
    const hint = isArchive
      ? 'Распакуй архив ' + r.path + ' (extract_archive) и изучи содержимое.'
      : 'Прочитай файл ' + r.path + ' (read_file) и проанализируй.';
    if (inp) {
      inp.value = inp.value ? inp.value + '\n' + hint : hint;
      inp.dispatchEvent(new Event('input'));
    }
  }).catch(e => addMsg('❌ Ошибка загрузки: ' + e, 'bot', 'single'));
}

function extractVideoFrames(file) {
  const MAX_FRAMES = 4;
  const video = document.createElement('video');
  video.src = URL.createObjectURL(file);
  video.muted = true;
  const lbl = document.getElementById('previewLabel');
  const preview = document.getElementById('imagePreview');
  if (preview) preview.style.display = 'block';
  if (lbl) lbl.textContent = '🎬 Извлекаю кадры...';
  video.addEventListener('loadedmetadata', () => {
    const dur = video.duration;
    const frames = [];
    const times = Array.from({length:MAX_FRAMES}, (_,i)=>(dur/(MAX_FRAMES+1))*(i+1));
    const canvas = document.createElement('canvas');
    canvas.width = 640; canvas.height = 360;
    const ctx = canvas.getContext('2d');
    let idx = 0;
    function capture() {
      if (idx >= times.length) {
        pendingImages = frames;
        if (lbl) lbl.textContent = '🎬 ' + file.name + ' (' + frames.length + ' кадров)';
        const img = document.getElementById('previewImg');
        if (img) img.src = 'data:image/jpeg;base64,' + frames[0];
        const inp = document.getElementById('inp');
        if (inp && !inp.value) inp.value = 'Проанализируй видео (' + Math.round(dur) + 'с).';
        return;
      }
      video.currentTime = times[idx];
    }
    video.addEventListener('seeked', () => {
      // Задержка 50ms гарантирует что браузер отрендерил кадр (Gemini #4)
      setTimeout(() => {
        ctx.drawImage(video, 0, 0, 640, 360);
        frames.push(canvas.toDataURL('image/jpeg', 0.7).split(',')[1]);
        idx++; capture();
      }, 50);
    });
    capture();
  });
}

// ── Keyboard ──────────────────────────────────────────────────────────────────
document.getElementById('inp').addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    send();
  }
});

// ── Init ──────────────────────────────────────────────────────────────────────
buildAgentList();
loadSessions();
loadFiles('');
loadModels();

// ── Settings Modal ────────────────────────────────────────────────────────────
let _settingsData = {};  // { agents: [...], availableModels: [...] }
let _pendingSettings = {};  // { "agent_model:coder": "qwen3-coder:30b", ... }

async function openSettings() {
  document.getElementById('settingsModal').style.display = 'flex';
  await loadSettingsData();
}

function closeSettings() {
  document.getElementById('settingsModal').style.display = 'none';
  _pendingSettings = {};
}

async function loadSettingsData() {
  const container = document.getElementById('agentModelsList');
  container.innerHTML = '<div style="color:#888;text-align:center;padding:20px;">Загрузка...</div>';

  try {
    const [settingsResp, modelsResp] = await Promise.all([
      fetch('/settings').then(r => r.json()),
      fetch('/settings/models').then(r => r.json()),
    ]);

    _settingsData = settingsResp;
    const availableModels = modelsResp.models || [];

    // Обновляем переключатель авто-подтверждения
    const toggle = document.getElementById('autoApproveToggle');
    const slider = document.getElementById('autoApproveSlider');
    const thumb = document.getElementById('autoApproveThumb');
    if (toggle) {
      toggle.checked = settingsResp.auto_approve || false;
      updateToggleStyle(toggle.checked, slider, thumb);
    }

    let html = '';
    for (const agent of (settingsResp.agents || [])) {
      const key = `agent_model:${agent.key}`;
      const current = _pendingSettings[key] || agent.current_model || agent.default_model;

      const options = availableModels.map(m =>
        `<option value="${m}" ${m === current ? 'selected' : ''}>${m}</option>`
      ).join('');

      // Если текущая модель не в списке — добавляем её
      const allModels = availableModels.includes(current)
        ? availableModels
        : [current, ...availableModels];
      const optionsFull = allModels.map(m =>
        `<option value="${m}" ${m === current ? 'selected' : ''}>${m}</option>`
      ).join('');

      // ── Параметры: температура / лимит токенов / лимит шагов ──
      const curTemp = _pendingSettings[`agent_temp:${agent.key}`]
        ?? (agent.current_temperature || agent.default_temperature);
      const curNP = _pendingSettings[`agent_npredict:${agent.key}`]
        ?? (agent.current_num_predict || agent.default_num_predict);
      const curSteps = _pendingSettings[`agent_steps:${agent.key}`]
        ?? (agent.current_max_steps || agent.default_max_steps);
      const npOptions = [2048, 4096, 8192, 16384, 32768].map(n =>
        `<option value="${n}" ${Number(curNP) === n ? 'selected' : ''}>${n >= 1024 ? (n/1024)+'K' : n}</option>`
      ).join('');

      html += `
        <div style="margin-bottom:10px;padding:10px 12px;background:#0d0d1a;border-radius:8px;">
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
            <span style="font-size:16px;">${agent.emoji || '🤖'}</span>
            <span style="color:#fff;font-weight:bold;font-size:13px;">${agent.name}</span>
            <span style="color:#555;font-size:11px;margin-left:auto;">по умолчанию: ${agent.default_model}</span>
          </div>
          <select id="setting_${agent.key}"
            onchange="_pendingSettings['${key}'] = this.value"
            style="width:100%;background:#1a1a2e;color:#fff;border:1px solid #444;
                   border-radius:6px;padding:6px;font-size:13px;margin-bottom:6px;">
            ${optionsFull}
          </select>
          <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
            <div style="flex:1;min-width:150px;">
              <div style="color:#888;font-size:11px;margin-bottom:2px;">
                🌡 Температура: <span id="tval_${agent.key}" style="color:#10b981;">${Number(curTemp).toFixed(2)}</span>
                <span style="color:#555;">(деф. ${Number(agent.default_temperature).toFixed(2)})</span>
              </div>
              <input type="range" min="0" max="1.5" step="0.05" value="${curTemp}"
                oninput="document.getElementById('tval_${agent.key}').textContent=Number(this.value).toFixed(2);
                         _pendingSettings['agent_temp:${agent.key}']=this.value"
                style="width:100%;accent-color:#10b981;">
            </div>
            <div style="min-width:90px;">
              <div style="color:#888;font-size:11px;margin-bottom:2px;">📏 Токены ответа</div>
              <select onchange="_pendingSettings['agent_npredict:${agent.key}']=this.value"
                style="width:100%;background:#1a1a2e;color:#fff;border:1px solid #444;
                       border-radius:6px;padding:5px;font-size:12px;">
                ${npOptions}
              </select>
            </div>
            <div style="min-width:70px;">
              <div style="color:#888;font-size:11px;margin-bottom:2px;">👣 Шагов (макс)</div>
              <input type="number" min="1" max="50" value="${curSteps}"
                onchange="_pendingSettings['agent_steps:${agent.key}']=this.value"
                style="width:100%;background:#1a1a2e;color:#fff;border:1px solid #444;
                       border-radius:6px;padding:5px;font-size:12px;">
            </div>
          </div>
        </div>`;
    }

    container.innerHTML = html || '<div style="color:#888">Нет агентов</div>';
  } catch (e) {
    container.innerHTML = `<div style="color:#e74c3c">Ошибка загрузки: ${e.message}</div>`;
  }
}

async function saveSettings() {
  if (Object.keys(_pendingSettings).length === 0) {
    closeSettings();
    return;
  }

  const btn = document.querySelector('#settingsModal button[onclick="saveSettings()"]');
  btn.textContent = '⏳ Сохранение...';
  btn.disabled = true;

  try {
    for (const [key, value] of Object.entries(_pendingSettings)) {
      await fetch('/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key, value }),
      });
    }
    btn.textContent = '✅ Сохранено!';
    setTimeout(() => {
      btn.textContent = '💾 Сохранить';
      btn.disabled = false;
      _pendingSettings = {};
      closeSettings();
    }, 1000);
  } catch (e) {
    btn.textContent = `❌ Ошибка: ${e.message}`;
    btn.disabled = false;
  }
}

// Закрываем по клику на фон
document.getElementById('settingsModal')?.addEventListener('click', e => {
  if (e.target.id === 'settingsModal') closeSettings();
});

// ── Pipeline Progress Panel ───────────────────────────────────────────────────
let _pipelineES = null;      // EventSource
let _pipelineStart = 0;      // timestamp старта
let _pipelineTimer = null;   // setInterval для таймера
let _agentStates = {};       // { agent_key: {status, start, elapsed} }

const STATUS = {
    waiting:   { icon: '⚪', color: '#555' },
    running:   { icon: '🟡', color: '#f59e0b' },
    thinking:  { icon: '🔵', color: '#3b82f6' },
    tool:      { icon: '⚡', color: '#8b5cf6' },
    approval:  { icon: '⏸', color: '#f97316' },
    done:      { icon: '🟢', color: '#10b981' },
    error:     { icon: '🔴', color: '#ef4444' },
};

// Свёрнутое состояние панели «Пайплайн» (в памяти на сессию страницы).
let _pipelineCollapsed = false;

function applyPipelineCollapsed() {
    const agentsEl = document.getElementById('pipelineAgents');
    const btn = document.getElementById('pipelineToggle');
    if (!agentsEl || !btn) return;
    if (_pipelineCollapsed) {
        agentsEl.style.display = 'none';   // прячем список агентов
        btn.textContent = '▸';             // стрелка «развернуть»
    } else {
        agentsEl.style.display = 'flex';
        btn.textContent = '▾';             // стрелка «свернуть»
    }
}

function togglePipelinePanel() {
    _pipelineCollapsed = !_pipelineCollapsed;
    applyPipelineCollapsed();
}

function startPipelineSSE(sessionId, agents) {
    stopPipelineSSE();
    _agentStates = {};
    _pipelineStart = Date.now();

    // Инициализируем агентов
    const agentNames = {
        single: '🤖 Агент', manager: '🧠 Менеджер',
        architect: '📐 Архитектор', coder: '💻 Кодер',
        critic: '🔍 Критик', tester: '🧪 Тестер',
    };
    agents.forEach(a => {
        _agentStates[a] = {status: 'waiting', start: 0, elapsed: 0,
                           label: agentNames[a] || a, tool: null};
    });

    renderPipelinePanel(agents);
    document.getElementById('pipelinePanel').style.display = 'block';
    // Восстанавливаем свёрнутое состояние, если пользователь сворачивал ранее
    applyPipelineCollapsed();

    // Таймер
    _pipelineTimer = setInterval(() => {
        const el = document.getElementById('pipelineTimer');
        if (el) el.textContent = ((Date.now() - _pipelineStart) / 1000).toFixed(1) + 's';
        // Обновляем elapsed для текущих агентов
        Object.keys(_agentStates).forEach(k => {
            const s = _agentStates[k];
            if (s.status === 'running' || s.status === 'thinking' || s.status === 'tool') {
                s.elapsed = (Date.now() - s.start) / 1000;
                renderAgentRow(k);
            }
        });
    }, 200);

    // SSE подключение
    _pipelineES = new EventSource(`/events/${sessionId}`);
    _pipelineES.onmessage = (e) => {
        try { handlePipelineEvent(JSON.parse(e.data)); }
        catch (_) {}
    };
    _pipelineES.onerror = () => {
        // Пробуем переподключиться через 3 секунды вместо полной остановки
        if (_pipelineES) { _pipelineES.close(); _pipelineES = null; }
        setTimeout(() => {
            if (_pipelineTimer) {  // если pipeline ещё активен
                _pipelineES = new EventSource(`/events/${sessionId}`);
                _pipelineES.onmessage = (e) => {
                    try { handlePipelineEvent(JSON.parse(e.data)); } catch (_) {}
                };
                _pipelineES.onerror = () => { if (_pipelineES) { _pipelineES.close(); _pipelineES = null; } };
            }
        }, 3000);
    };
}

function stopPipelineSSE() {
    if (_pipelineES) { _pipelineES.close(); _pipelineES = null; }
    if (_pipelineTimer) { clearInterval(_pipelineTimer); _pipelineTimer = null; }
}

function handlePipelineEvent(ev) {
    const a = ev.agent;
    if (!a || !_agentStates[a]) return;

    // Накапливаем ленту действий (без кода — чтобы не спамить)
    if (!_agentStates[a].actions) _agentStates[a].actions = [];

    switch (ev.type) {
        case 'agent_start':
            _agentStates[a].status = 'running';
            _agentStates[a].start = Date.now();
            _agentStates[a].tool = null;
            _agentStates[a].actions = [];
            break;
        case 'agent_thinking':
            _agentStates[a].status = 'thinking';
            break;
        case 'agent_thought':
            // Мысль агента: что он решил сделать и зачем (текст до tool call).
            // Показываем в ленте действий курсивом — это контекст для tool call ниже.
            if (ev.thought) {
                _agentStates[a].actions.push({ kind: 'thought', text: ev.thought });
            }
            break;
        case 'checklist': {
            // Чеклист файлов: 📋 3/8 | осталось: x.py, y.py — в шапке чата
            let bar = document.getElementById('checklistBar');
            if (!bar) {
                bar = document.createElement('div');
                bar.id = 'checklistBar';
                bar.style.cssText = 'padding:6px 14px;background:#0d1f1a;border-bottom:1px solid #1a3a30;' +
                    'color:#10b981;font-size:12px;font-family:monospace;';
                const chatArea = document.querySelector('.chat-container') || document.body;
                chatArea.insertBefore(bar, chatArea.firstChild);
            }
            if (ev.done >= ev.total) {
                bar.textContent = `📋 Файлы: ${ev.done}/${ev.total} — все записаны ✅`;
                setTimeout(() => { bar.style.display = 'none'; }, 30000);
            } else {
                const rem = (ev.remaining || []).join(', ');
                bar.textContent = `📋 Файлы: ${ev.done}/${ev.total}` + (rem ? ` | осталось: ${rem}` : '');
                bar.style.display = 'block';
            }
            break;
        }
        case 'agent_step':
            // Системное действие (лимит времени/шагов и т.п.)
            if (ev.action) _agentStates[a].actions.push({ kind: 'sys', text: ev.action });
            break;
        case 'tool_call':
            _agentStates[a].status = 'tool';
            _agentStates[a].tool = ev.tool;
            _agentStates[a].actions.push({
                kind: 'call',
                tool: ev.tool,
                explain: explainAction(ev.tool, ev.params),
                params: summarizeParams(ev.tool, ev.params),
            });
            break;
        case 'tool_result':
            _agentStates[a].status = 'running';
            _agentStates[a].tool = null;
            // Привязываем результат к последнему вызову
            const acts = _agentStates[a].actions;
            for (let i = acts.length - 1; i >= 0; i--) {
                if (acts[i].kind === 'call' && acts[i].ok === undefined) {
                    acts[i].ok = ev.ok;
                    break;
                }
            }
            break;
        case 'agent_done':
            _agentStates[a].status = 'done';
            _agentStates[a].elapsed = ev.elapsed || 0;
            _agentStates[a].tool = null;
            break;
        case 'approval_needed':
            _agentStates[a].status = 'approval';
            _agentStates[a].tool = ev.tool;
            break;
        case 'pipeline_done':
            stopPipelineSSE();
            setTimeout(() => {
                const panel = document.getElementById('pipelinePanel');
                if (panel) panel.style.display = 'none';
            }, 4000);
            return;
    }
    renderAgentRow(a);
}

// Человекочитаемое объяснение действия по инструменту (без кода — не спамим).
// Универсально под любые задачи: описывает СМЫСЛ действия, не его содержимое.
function explainAction(tool, params) {
    const p = (params && typeof params === 'object') ? params : {};
    const path = p.path || p.name || '';
    const base = path ? String(path).replace(/\\/g, '/').split('/').pop() : '';
    switch (tool) {
        case 'write_file':    return `📝 Пишет файл ${base}`;
        case 'read_file':     return `📖 Читает ${base}`;
        case 'str_replace':   return `✏️ Правит ${base}`;
        case 'list_files':    return `📂 Смотрит файлы${path ? ' в ' + base : ''}`;
        case 'save_project':  return `💾 Сохраняет проект ${base || p.name || ''}`;
        case 'run_python':    return `▶️ Запускает Python-код`;
        case 'run_script':    return `▶️ Запускает ${base || 'скрипт'}`;
        case 'run_code':      return `▶️ Выполняет код`;
        case 'pip_install':   return `📦 Ставит пакеты: ${(p.packages || []).join(', ') || ''}`;
        case 'check_package': return `🔎 Проверяет пакет ${(p.packages || p.package || '')}`;
        case 'create_dir':    return `📁 Создаёт папку ${base}`;
        case 'web_search':    return `🌐 Ищет в сети: ${(p.q || p.query || '').slice(0, 40)}`;
        case 'todo_tracker': {
            const act = p.action || '';
            if (act === 'add')  return `📋 Планирует: ${(p.task || '').slice(0, 50)}`;
            if (act === 'done') return `✅ Отмечает задачу #${p.id} выполненной`;
            if (act === 'list') return `📋 Смотрит список задач`;
            return `📋 Работа со списком задач`;
        }
        default:              return `⚙️ ${tool}`;
    }
}

// Краткое содержимое параметров действия — БЕЗ кода (чтобы не спамить).
// Для write_file/str_replace показываем только путь, длину контента опускаем.
function summarizeParams(tool, params) {
    if (!params) return '';
    const p = typeof params === 'object' ? params : {};
    // Поля с кодом/контентом не показываем — только метаданные
    const CODE_FIELDS = ['content', 'code', 'script', 'text', 'old_str', 'new_str'];
    const parts = [];
    for (const [k, v] of Object.entries(p)) {
        if (CODE_FIELDS.includes(k)) {
            const len = (typeof v === 'string') ? v.length : String(v).length;
            parts.push(`${k}: ${len} симв.`);
        } else {
            const s = String(v);
            parts.push(`${k}: ${s.length > 50 ? s.slice(0, 50) + '…' : s}`);
        }
    }
    return parts.join(', ');
}

function renderPipelinePanel(agents) {
    const container = document.getElementById('pipelineAgents');
    if (!container) return;
    container.innerHTML = '';
    agents.forEach(a => {
        const div = document.createElement('div');
        div.id = `agent_row_${a}`;
        container.appendChild(div);
        renderAgentRow(a);
    });
}

function renderAgentRow(agentKey) {
    const el = document.getElementById(`agent_row_${agentKey}`);
    if (!el) return;
    const s = _agentStates[agentKey];
    if (!s) return;
    const st = STATUS[s.status] || STATUS.waiting;
    const elapsed = s.status === 'done'
        ? `<span style="color:#10b981;margin-left:4px;font-size:11px;">${s.elapsed.toFixed(1)}s</span>`
        : s.status !== 'waiting'
            ? `<span style="color:#888;margin-left:4px;font-size:11px;">${s.elapsed ? s.elapsed.toFixed(1)+'s' : ''}</span>`
            : '';
    const toolStr = s.status === 'approval' && s.tool
        ? `<div style="color:#f97316;font-size:11px;margin-top:2px;padding-left:20px;">⏸ Ожидает подтверждения: ${s.tool}</div>`
        : s.tool
            ? `<div style="color:#8b5cf6;font-size:11px;margin-top:2px;padding-left:20px;">⚡ ${s.tool}</div>`
            : '';

    // Лента действий агента (последние 8, без кода — чтобы не спамить)
    let actionsStr = '';
    if (s.actions && s.actions.length) {
        const recent = s.actions.slice(-8);
        const rows = recent.map(ac => {
            if (ac.kind === 'sys') {
                return `<div style="color:#f59e0b;font-size:10px;padding-left:20px;">${ac.text}</div>`;
            }
            if (ac.kind === 'thought') {
                // Мысль агента — курсивом, приглушённо, перед tool call который она объясняет
                const t = (ac.text || '').replace(/</g, '&lt;').slice(0, 250);
                return `<div style="color:#94a3b8;font-size:10px;padding-left:20px;font-style:italic;border-left:2px solid #475569;margin:2px 0 2px 18px;padding-left:6px;">💭 ${t}</div>`;
            }
            const mark = ac.ok === false ? '✗' : (ac.ok === true ? '✓' : '·');
            const markColor = ac.ok === false ? '#ef4444' : (ac.ok === true ? '#10b981' : '#888');
            // Главное — человекочитаемое объяснение; тех.детали мелким серым
            const explain = ac.explain || ac.tool;
            const detail = ac.params ? `<span style="color:#555;font-size:9px;"> (${ac.params})</span>` : '';
            return `<div style="font-size:11px;padding-left:20px;color:#cbd5e1;">`
                + `<span style="color:${markColor};">${mark}</span> `
                + `${explain}${detail}</div>`;
        }).join('');
        const more = s.actions.length > 8
            ? `<div style="font-size:10px;padding-left:20px;color:#555;">…ещё ${s.actions.length - 8} действий выше</div>`
            : '';
        actionsStr = `<div style="margin-top:2px;max-height:140px;overflow-y:auto;">${more}${rows}</div>`;
    }

    el.innerHTML = `
        <div style="display:flex;align-items:center;gap:6px;color:${st.color};">
            <span style="font-size:14px;">${st.icon}</span>
            <span style="font-size:13px;flex:1;">${s.label}</span>
            ${elapsed}
        </div>${toolStr}${actionsStr}`;
}


// ── Auto-approve toggle ───────────────────────────────────────────────────────
function updateToggleStyle(enabled, slider, thumb) {
  if (!slider || !thumb) return;
  slider.style.background = enabled ? '#00d4aa' : '#333';
  thumb.style.transform = enabled ? 'translateX(22px)' : 'translateX(0)';
}

async function toggleAutoApprove(enabled) {
  const slider = document.getElementById('autoApproveSlider');
  const thumb = document.getElementById('autoApproveThumb');
  updateToggleStyle(enabled, slider, thumb);

  try {
    await apiPost('/settings', { key: 'auto_approve', value: enabled ? 'true' : 'false' });
    // Показываем статус в UI
    const status = enabled
      ? '⚡ Авто-подтверждение включено — инструменты запускаются без паузы'
      : '🔒 Авто-подтверждение выключено — требуется подтверждение';
    console.log(status);
  } catch (e) {
    console.error('Ошибка переключения auto_approve:', e);
  }
}
