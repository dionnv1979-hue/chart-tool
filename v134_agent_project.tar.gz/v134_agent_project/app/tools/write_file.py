"""Инструмент write_file — записывает файл в Projects. DANGEROUS."""
import asyncio
import os
import re as _re
import subprocess
import sys
import tempfile

from app.core.config import settings
from app.core.logger import get_logger
from app.schemas.tool import WriteFileParams
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)

_UNDEF_RE = _re.compile(r"undefined name '([^']+)'")


def _undefined_names(code: str) -> set[str] | None:
    """Множество неопределённых имён (bare NameError-кандидаты) в коде по pyflakes.

    None → pyflakes недоступен или сам код синтаксически битый (тогда guard
    молча пропускаем: синтаксис ловят другие проверки, а мы тут только про
    регрессию по неопределённым именам). pyflakes НЕ флагует атрибуты
    (self.score), только голые имена (board, game) — ровно класс бага из лога.
    """
    try:
        with tempfile.NamedTemporaryFile(
            "w", suffix=".py", delete=False, encoding="utf-8"
        ) as tf:
            tf.write(code)
            tmp = tf.name
    except OSError:
        return None
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "pyflakes", tmp],
            capture_output=True, text=True, timeout=15,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass
    out = (proc.stdout or "") + "\n" + (proc.stderr or "")
    if "No module named pyflakes" in out:
        return None  # pyflakes не установлен — не блокируем
    if "SyntaxError" in out or "invalid syntax" in out:
        return None  # битый синтаксис — не наша зона, пропускаем
    return set(_UNDEF_RE.findall(out))


def _line_similarity(a: str, b: str) -> float:
    """
    Доля общих строк между двумя версиями файла (по множеству непустых строк).
    Быстрая эвристика: 1.0 = идентичны, 0.0 = полностью разные.
    Используется чтобы поймать «переписал файл целиком ради одной строки».
    """
    la = {ln.strip() for ln in a.splitlines() if ln.strip()}
    lb = {ln.strip() for ln in b.splitlines() if ln.strip()}
    if not la or not lb:
        return 0.0
    common = len(la & lb)
    return common / max(len(la), len(lb))
_PROJECTS_DIR = os.path.realpath(settings.projects_dir)


def _safe_path(user_path: str) -> str | None:
    """
    Резолвит путь относительно Projects/.
    Поддерживает разные форматы которые могут прислать агенты:
        "README.md"                    → Projects/README.md
        "Projects/README.md"           → Projects/README.md (срезаем префикс)
        "./Projects/foo.py"            → Projects/foo.py
        "/абс/путь/внутри/Projects/x"  → проверяется на вхождение
        "/etc/passwd"                  → None (вне Projects)
        "../../etc/passwd"             → None (вышли за Projects через ..)

    Финальная защита: realpath() обязан быть внутри _PROJECTS_DIR.
    """
    # Нормализуем разделители и убираем ведущие "./"
    cleaned = user_path.replace("\\", "/")
    while cleaned.startswith("./"):
        cleaned = cleaned[2:]

    # #5: приводим корневую папку к каноническому имени проекта (если задано)
    from app.core.active_project import canonicalize_path
    if not os.path.isabs(cleaned):
        cleaned = canonicalize_path(cleaned)

    # Если уже абсолютный — оставляем как есть, проверим вхождение ниже
    if os.path.isabs(cleaned):
        candidate = cleaned
    else:
        # Убираем префикс "Projects/" если агент его сам добавил
        for prefix in ("Projects/", "projects/"):
            if cleaned.startswith(prefix):
                cleaned = cleaned[len(prefix):]
                break
        candidate = os.path.join(_PROJECTS_DIR, cleaned)

    real = os.path.realpath(os.path.abspath(candidate))
    try:
        if os.path.commonpath([real, _PROJECTS_DIR]) == _PROJECTS_DIR:
            return real
    except ValueError:
        pass
    return None


@tool
class WriteFileTool(BaseTool):
    name = "write_file"
    description = "Записать файл в Projects. params: path, content"
    params_schema = WriteFileParams
    dangerous = True

    async def execute(self, params: WriteFileParams) -> str:
        safe = _safe_path(params.path)
        if not safe:
            return f"[BLOCKED] Path traversal: {params.path}"
        # ── Запрет затенения stdlib: файл types.py/random.py/socket.py в проекте
        # перекрывает системный модуль → ImportError у ВСЕХ зависимостей
        # (partially initialized module). Чинится только переименованием,
        # поэтому блокируем на входе. (Кейс из лога: types.py убил 6 раундов.)
        import sys as _sys
        _stem = os.path.splitext(os.path.basename(safe))[0].lower()
        _allowed_anyway = {"test", "main", "tests", "setup", "run", "app"}
        if (safe.endswith(".py") and _stem in _sys.stdlib_module_names
                and _stem not in _allowed_anyway):
            return (
                f"[BLOCKED] Имя файла '{_stem}.py' совпадает со стандартным "
                f"модулем Python и ЗАТЕНИТ его — импорты библиотек сломаются "
                f"(partially initialized module). Назови иначе, например "
                f"'{os.path.basename(os.path.dirname(safe)).lower() or 'app'}_{_stem}.py' "
                f"или 'game_{_stem}.py', и используй это имя в импортах."
            )
        # Защита от мусорного контента (tool-блоки попавшие в params.content)
        content = params.content.strip()
        is_garbage = (
            content.startswith("tool\n{")
            or content.startswith("[OK]")
            or content.startswith("[ERROR]")
            or content.startswith("[BLOCKED]")
            or bool(__import__("re").match(r"^tool\s*\n\s*\{", content))
        )
        if is_garbage:
            logger.warning(f"write_file: отклонён мусорный контент для {params.path}")
            return f"[ERROR] Контент выглядит как tool-вызов а не код. Передай реальный код файла."

        # ── REGRESSION GUARD: защита от деградации готового кода ───────────
        # Из лога: Кодер при "починке" переписывал game.py 8276→2866 символов,
        # board.py 3672→1928 — урезал рабочий код в 2-3 раза, ломая проект.
        # Если перезаписываем существующий файл КОДА и новый < 70% старого —
        # блокируем (вероятно модель режет рабочий код вместо точечного фикса).
        _CODE_EXT = (".py", ".js", ".ts", ".go", ".rs", ".java", ".cpp", ".c",
                     ".html", ".css", ".rb", ".php", ".sh", ".sql", ".jsx", ".tsx")
        if safe.endswith(_CODE_EXT) and os.path.exists(safe):
            try:
                old_size = os.path.getsize(safe)
            except OSError:
                old_size = 0
            new_size = len(content.encode("utf-8"))
            # Разрыв клинча: если base.py выдал одноразовое разрешение на
            # перезапись этого файла (Кодер застрял между блоками) — пропускаем
            # regression guard, НО только если новый файл не пустой огрызок
            # (>= 40% старого: достаточно чтобы быть реальным кодом, не заглушкой).
            from app.core.active_project import get_fix_mode, consume_force_rewrite
            if old_size > 200 and new_size >= old_size * 0.40 and consume_force_rewrite(params.path):
                logger.info(
                    f"write_file: клинч разорван — разрешена перезапись {params.path} "
                    f"({old_size}→{new_size} байт)"
                )
            else:
                # В режиме починки (traceback fix) порог мягче: точечный фикс может
                # законно убрать часть строк. Блокируем только ЭКСТРЕМАЛЬНУЮ
                # деградацию (<30% — это уже точно выпотрошенный файл). Вне режима
                # починки порог строгий (70%) — защита готового кода от урезания.
                threshold = 0.30 if get_fix_mode() else 0.70
                if old_size > 200 and new_size < old_size * threshold:
                    logger.warning(
                        f"write_file REGRESSION BLOCK: {params.path} "
                        f"{old_size}→{new_size} байт (-{100-new_size*100//old_size}%) "
                        f"[порог {int(threshold*100)}%]"
                    )
                    return (
                        f"[ERROR] ДЕГРАДАЦИЯ КОДА заблокирована: новый {params.path} "
                        f"({new_size} символов) в {old_size/max(new_size,1):.1f}x меньше "
                        f"текущего ({old_size} символов).\n"
                        f"Для исправления ОДНОЙ строки/импорта используй str_replace — "
                        f"это правильный инструмент для точечного фикса (добавить BLACK=(0,0,0), "
                        f"поправить импорт и т.п.).\n"
                        f"write_file нужен только когда переписываешь файл ПОЛНОСТЬЮ "
                        f"со всем кодом (все функции и классы)."
                    )

            # ── INCREMENTAL GUARD (находка из лога v96) ───────────────────
            # В режиме починки Кодер переписывал main.py целиком (3552→3535,
            # 99% идентичный) ради правки ОДНОЙ строки импорта — снова и снова.
            # Это медленно (110с генерации) и плодит новые баги. Если в fix-mode
            # перезаписываем существующий КОД почти тем же содержимым (размер в
            # пределах ±20%, файл крупный) — заставляем использовать str_replace.
            if get_fix_mode() and old_size > 800:
                try:
                    with open(safe, encoding="utf-8") as _f:
                        old_content = _f.read()
                except OSError:
                    old_content = ""
                if old_content:
                    similar = _line_similarity(old_content, content)
                    size_ratio = new_size / max(old_size, 1)
                    # Почти тот же файл (>=80% общих строк, размер близкий) →
                    # это точечная правка, переписанная целиком. Не даём.
                    if similar >= 0.80 and 0.8 <= size_ratio <= 1.25:
                        logger.warning(
                            f"write_file INCREMENTAL BLOCK: {params.path} "
                            f"переписан целиком при {int(similar*100)}% сходстве "
                            f"(нужен str_replace)"
                        )
                        return (
                            f"[ERROR] Ты переписываешь {params.path} целиком "
                            f"({int(similar*100)}% совпадает со старым) ради мелкой правки.\n"
                            f"Это медленно и рискованно. Используй str_replace: найди "
                            f"ТОЛЬКО ту строку, что надо изменить, и замени её.\n"
                            f"Пример: str_replace(path=\"{params.path}\", "
                            f"old_str=\"<старая строка>\", new_str=\"<новая строка>\").\n"
                            f"write_file для этого файла сейчас заблокирован — "
                            f"делай точечную правку."
                        )

            # ── UNDEFINED-NAME REGRESSION GUARD (находка из лога v131) ──────
            # В fix-mode Кодер переписал renderer.py и ввёл голое имя 'board'
            # (renderer.py:91,117), которого нигде нет → NameError, рабочий код
            # сломан, ещё 5 раундов впустую. Статические/размерные гарды это не
            # ловят (размер норм, синтаксис норм). Здесь: если правка вводит
            # НОВЫЕ неопределённые имена, которых не было в старой версии файла —
            # НЕ пишем (рабочая версия цела) и возвращаем точечную инструкцию.
            if get_fix_mode() and safe.endswith(".py"):
                new_undef = await asyncio.to_thread(_undefined_names, content)
                if new_undef:  # не None и не пусто
                    try:
                        with open(safe, encoding="utf-8") as _f:
                            _old_src = _f.read()
                    except OSError:
                        _old_src = ""
                    old_undef = await asyncio.to_thread(_undefined_names, _old_src) or set()
                    introduced = new_undef - old_undef
                    if introduced:
                        names = ", ".join(sorted(introduced)[:6])
                        logger.warning(
                            f"write_file UNDEFINED-NAME BLOCK: {params.path} "
                            f"вводит новые неопределённые имена: {names}"
                        )
                        return (
                            f"[ERROR] РЕГРЕССИЯ заблокирована: правка {params.path} "
                            f"вводит НЕОПРЕДЕЛЁННЫЕ имена, которых раньше не было: "
                            f"{names}.\n"
                            f"Они нигде не объявлены и не импортированы в файле → "
                            f"это NameError при запуске. Файл НЕ перезаписан — "
                            f"рабочая версия цела.\n"
                            f"Почини ТОЧЕЧНО через str_replace, используя ТОЛЬКО "
                            f"существующие имена: атрибуты (self.<поле>), переданные "
                            f"аргументы функции или импортированные модули. Не "
                            f"выдумывай новых переменных."
                        )

        try:
            parent = os.path.dirname(safe)
            if parent:
                os.makedirs(parent, exist_ok=True)
            # ── .bak снапшот перед перезаписью ────────────────────────────────
            # Если файл уже существует — сохраняем копию. При smoke-fail сразу
            # после этой записи есть шанс откатиться без полного repair-round.
            # Best-effort: ошибка записи .bak не блокирует основную запись.
            bak_path = safe + ".bak"
            if os.path.exists(safe) and safe.endswith(_CODE_EXT):
                try:
                    import shutil as _sh
                    _sh.copy2(safe, bak_path)
                except OSError:
                    pass
            with open(safe, "w", encoding="utf-8") as f:
                f.write(content)
            # ── Дисциплина Claude Code: verify + чеклист ────────────────────
            from app.core.active_project import (
                mark_file_read, mark_file_written, progress_line,
            )
            mark_file_read(safe)      # записал = знает содержимое
            from app.core.syntax_check import syntax_check as _sc
            _verify = _sc(safe, content)
            if not _verify:
                mark_file_written(safe)  # в чеклист — только синтаксически целые
            _prog = progress_line()
            _prog_part = f"\n{_prog}" if _prog else ""
            return f"[OK] Записан: {safe} ({len(content)} символов){_verify}{_prog_part}"
        except Exception as e:
            return f"[ERROR] {e}"
