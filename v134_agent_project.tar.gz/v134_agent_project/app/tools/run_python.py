"""Инструмент run_python — выполняет Python в sandbox."""
from app.core.logger import get_logger
from app.sandbox.docker_runner import get_docker_runner
from app.schemas.tool import RunPythonParams
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)


@tool
class RunPythonTool(BaseTool):
    name = "run_python"
    description = (
        "Выполнить Python код в изолированной среде. params: code. "
        "Для тестов используй unittest (встроен). pytest НЕ доступен."
    )
    params_schema = RunPythonParams
    dangerous = False

    async def execute(self, params: RunPythonParams) -> str:
        # Если передан project_dir — запускаем с PYTHONPATH, минуя sandbox.
        # Это позволяет Тестеру писать 'from game import Game' вместо
        # ручного копирования классов (копирование с потерями из-за LLM).
        # Безопасность: project_dir валидируется на вхождение в Projects/.
        if params.project_dir:
            import os, sys, asyncio as _aio, subprocess as _sp
            from app.core.config import settings as _s
            _projects = os.path.realpath(_s.projects_dir)
            _raw = params.project_dir.strip().lstrip("/\\")
            _candidate = os.path.realpath(os.path.join(_projects, _raw))
            # Проверяем path traversal
            if not _candidate.startswith(_projects + os.sep) and _candidate != _projects:
                return "[ERROR] project_dir вне папки Projects/ — запрещено."
            if not os.path.isdir(_candidate):
                return f"[ERROR] project_dir не найден: {_candidate}"
            # Записываем код во временный файл рядом с проектом
            import tempfile as _tf
            _env = os.environ.copy()
            _env["PYTHONPATH"] = _candidate + os.pathsep + _env.get("PYTHONPATH", "")
            try:
                with _tf.NamedTemporaryFile(
                    mode="w", suffix=".py", prefix="_agent_test_",
                    dir=_candidate, delete=False, encoding="utf-8"
                ) as _f:
                    _f.write(params.code)
                    _tmpfile = _f.name
                loop = _aio.get_running_loop()
                proc_result = await loop.run_in_executor(
                    None,
                    lambda: _sp.run(
                        [sys.executable, _tmpfile],
                        capture_output=True, text=True, timeout=30,
                        cwd=_candidate, env=_env,
                    ),
                )
                out = (proc_result.stdout or "")[:3000]
                err = (proc_result.stderr or "")[-2000:]
                rc = proc_result.returncode
                if rc == 0:
                    return f"[OK returncode=0]\n{out}" if out else "[OK returncode=0]"
                return f"[FAIL returncode={rc}]\n{out}\n{err}".strip()
            except _sp.TimeoutExpired:
                return "[TIMEOUT] Тест не завершился за 30с"
            except Exception as _e:
                return f"[ERROR] {_e}"
            finally:
                try:
                    os.unlink(_tmpfile)
                except Exception:
                    pass

        runner = get_docker_runner()
        # НЕ нормализуем escape-последовательности — это ломает намеренные \n в строках.
        # Модель должна присылать правильный код, не JSON-encoded.
        code = params.code
        result = await runner.run(code)
        return result.format_output()
