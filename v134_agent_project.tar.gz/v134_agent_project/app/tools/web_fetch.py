"""
Инструмент web_fetch — страница целиком по URL (аналог WebFetch Claude Code).

web_search даёт сниппеты-огрызки; web_fetch читает страницу полностью:
документацию API, статью с решением, README по ссылке, JSON-эндпоинт.

Обработка по Content-Type:
  text/html        → текст без тегов (script/style/nav вырезаются)
  application/json → как есть (форматирование сохранено)
  text/*           → как есть
  application/pdf  → текст через pypdf

Защиты:
  - только http/https
  - SSRF-блок: localhost и приватные диапазоны (10.x, 192.168.x,
    172.16-31.x, 127.x, *.local) — агенту незачем сканировать твою сеть.
    DNS-rebinding не покрыт (для локального инструмента — перебор).
  - скачивание до 5MB, в результат до 8000 символов
"""
import ipaddress
import re
from urllib.parse import urlparse

import httpx
from pydantic import BaseModel, Field

from app.core.logger import get_logger
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)

_MAX_DOWNLOAD = 5 * 1024 * 1024
_MAX_RESULT_CHARS = 8000
_TIMEOUT = 20

_TAG_STRIP = re.compile(
    r"<(script|style|noscript|svg|head|nav|footer|iframe)\b.*?</\1>",
    re.DOTALL | re.IGNORECASE,
)
_ALL_TAGS = re.compile(r"<[^>]+>")


def _is_private_host(host: str) -> bool:
    """SSRF-защита: локальные/приватные адреса запрещены."""
    h = (host or "").lower().strip("[]")
    if h in ("localhost",) or h.endswith(".local") or h.endswith(".internal"):
        return True
    try:
        ip = ipaddress.ip_address(h)
        return (ip.is_private or ip.is_loopback or ip.is_link_local
                or ip.is_reserved or ip.is_multicast)
    except ValueError:
        return False  # доменное имя — пропускаем (rebinding вне скоупа)


def _html_to_text(html: str) -> str:
    txt = _TAG_STRIP.sub(" ", html)
    # Блочные теги → переносы, чтобы текст не слипался
    txt = re.sub(r"</(p|div|li|h[1-6]|tr|br|article|section)>", "\n", txt,
                 flags=re.IGNORECASE)
    txt = _ALL_TAGS.sub(" ", txt)
    txt = (txt.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
              .replace("&quot;", '"').replace("&#39;", "'").replace("&nbsp;", " "))
    txt = re.sub(r"[ \t]+", " ", txt)
    txt = re.sub(r"\n\s*\n+", "\n\n", txt)
    return txt.strip()


class WebFetchParams(BaseModel):
    """Параметры инструмента web_fetch."""
    url: str = Field(..., min_length=8, max_length=2000,
                     description="Полный URL страницы (http/https)")


@tool
class WebFetchTool(BaseTool):
    name = "web_fetch"
    description = (
        "Прочитать веб-страницу ЦЕЛИКОМ по URL. params: url.\n"
        "Используй когда нужна полная страница: документация API, статья "
        "с решением из web_search, README, JSON-эндпоинт. "
        "web_search даёт сниппеты — web_fetch даёт весь текст."
    )
    params_schema = WebFetchParams
    dangerous = False

    async def execute(self, params: WebFetchParams) -> str:
        url = params.url.strip()
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            return f"[ERROR] Только http/https: {url[:80]}"
        if not parsed.hostname:
            return f"[ERROR] Невалидный URL: {url[:80]}"
        if _is_private_host(parsed.hostname):
            return f"[BLOCKED] Локальный/приватный адрес запрещён: {parsed.hostname}"

        try:
            async with httpx.AsyncClient(
                follow_redirects=True, timeout=_TIMEOUT,
                headers={"User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                                        "AppleWebKit/537.36 Chrome/120.0 Safari/537.36")},
            ) as client:
                async with client.stream("GET", url) as resp:
                    if resp.status_code != 200:
                        return f"[ERROR] HTTP {resp.status_code} для {url[:80]}"
                    ctype = resp.headers.get("content-type", "").lower()
                    chunks, total = [], 0
                    async for chunk in resp.aiter_bytes():
                        chunks.append(chunk)
                        total += len(chunk)
                        if total > _MAX_DOWNLOAD:
                            break
                    raw = b"".join(chunks)
        except httpx.TimeoutException:
            return f"[ERROR] Таймаут {_TIMEOUT}с: {url[:80]}"
        except Exception as e:
            return f"[ERROR] Не удалось загрузить: {e}"

        # ── По типу контента ────────────────────────────────────────────────
        if "application/pdf" in ctype:
            try:
                from io import BytesIO
                from pypdf import PdfReader
                reader = PdfReader(BytesIO(raw))
                parts = []
                for page in reader.pages[:20]:
                    t = (page.extract_text() or "").strip()
                    if t:
                        parts.append(t)
                    if sum(len(p) for p in parts) > _MAX_RESULT_CHARS:
                        break
                text = "\n\n".join(parts) or "(текстовый слой PDF пуст)"
                return f"[OK] PDF {url[:80]} ({len(reader.pages)} стр.):\n{text[:_MAX_RESULT_CHARS]}"
            except Exception as e:
                return f"[ERROR] PDF по URL не читается: {e}"

        try:
            body = raw.decode("utf-8")
        except UnicodeDecodeError:
            body = raw.decode("utf-8", errors="replace")

        if "application/json" in ctype:
            text = body
        elif "html" in ctype or body.lstrip()[:1] == "<":
            text = _html_to_text(body)
        else:
            text = body

        if not text.strip():
            return f"[OK] {url[:80]} — страница пуста после очистки"
        cut = "" if len(text) <= _MAX_RESULT_CHARS else f"\n… [обрезано, всего {len(text)} символов]"
        logger.info(f"web_fetch: {url[:60]} → {len(text)} chars ({ctype.split(';')[0]})")
        return f"[OK] {url[:100]}:\n{text[:_MAX_RESULT_CHARS]}{cut}"
