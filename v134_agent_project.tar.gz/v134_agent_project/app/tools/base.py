"""
Базовый класс инструмента + механизм авто-регистрации.

Паттерн:
    @tool
    class RunPythonTool(BaseTool):
        name = "run_python"
        description = "Выполнить Python код в sandbox"
        params_schema = RunPythonParams
        dangerous = False

        async def execute(self, params: RunPythonParams) -> str:
            ...

Регистрация происходит автоматически при импорте модуля.
ToolService.register_from_registry() подхватывает всё одним вызовом.
"""
from __future__ import annotations

import abc
from typing import ClassVar, Type

from pydantic import BaseModel

from app.core.logger import get_logger

logger = get_logger(__name__)

# Глобальный реестр: name → экземпляр BaseTool
_REGISTRY: dict[str, "BaseTool"] = {}


class ApprovalRequired(Exception):
    """
    Исключение-middleware для dangerous tools.
    Бросается из ToolService.execute() вместо выполнения инструмента.
    BaseAgent перехватывает и конвертирует в AgentRunResult(type='confirm').

    Преимущество: любой новый dangerous tool автоматически получает
    approval-поведение без изменений в агентах или графе.
    """
    def __init__(self, tool_name: str, params: dict) -> None:
        self.tool_name = tool_name
        self.params = params
        super().__init__(f"Approval required for: {tool_name}")


class BaseTool(abc.ABC):
    """
    Абстрактный базовый класс инструмента.

    Подклассы объявляют:
        name         : str  — уникальный ключ инструмента
        description  : str  — описание для LLM промпта
        params_schema: type — Pydantic модель параметров
        dangerous    : bool — требует ли подтверждения пользователя

    И реализуют:
        async execute(params: params_schema) -> str
    """
    name: ClassVar[str]
    description: ClassVar[str]
    params_schema: ClassVar[Type[BaseModel]]
    dangerous: ClassVar[bool] = False

    @abc.abstractmethod
    async def execute(self, params: BaseModel) -> str:
        """Выполнить инструмент. params уже провалидирован через params_schema."""
        ...

    def validate_params(self, raw: dict) -> BaseModel:
        """Провалидировать сырые params через Pydantic схему."""
        return self.params_schema.model_validate(raw)

    @classmethod
    def prompt_description(cls) -> str:
        """Строка описания для промпта агента."""
        danger_suffix = " ⚠️ [требует подтверждения]" if cls.dangerous else ""
        return f"- {cls.name}: {cls.description}{danger_suffix}"


def tool(cls: type) -> type:
    """
    Декоратор авто-регистрации инструмента.

    Использование:
        @tool
        class MyTool(BaseTool):
            name = "my_tool"
            ...

    Создаёт экземпляр и регистрирует в _REGISTRY при импорте модуля.
    Не нужно ничего вызывать вручную.
    """
    instance = cls()
    _REGISTRY[cls.name] = instance
    logger.debug(f"Tool auto-registered: {cls.name} (dangerous={cls.dangerous})")
    return cls


def get_registry() -> dict[str, BaseTool]:
    """Получить текущий реестр инструментов."""
    return _REGISTRY


def get_tool(name: str) -> BaseTool | None:
    """Найти инструмент по имени."""
    return _REGISTRY.get(name)
