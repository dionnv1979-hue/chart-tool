"""
Инструмент create_dir — создаёт папку внутри Projects/.
Не dangerous — создание пустой папки безопасно.
"""
import os

from app.core.config import settings
from app.core.logger import get_logger
from app.schemas.tool import CreateDirParams
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)

_PROJECTS_DIR = os.path.realpath(settings.projects_dir)


@tool
class CreateDirTool(BaseTool):
    name = "create_dir"
    description = (
        "Создать папку внутри Projects/. "
        "params: path (путь к папке). "
        "Пример: {\"path\": \"MyProject/src\"}"
    )
    params_schema = CreateDirParams
    dangerous = False

    async def execute(self, params: CreateDirParams) -> str:
        cleaned = params.path.replace("\\", "/")
        for prefix in ("Projects/", "projects/"):
            if cleaned.startswith(prefix):
                cleaned = cleaned[len(prefix):]
                break

        target = os.path.realpath(os.path.join(_PROJECTS_DIR, cleaned))
        try:
            if os.path.commonpath([target, _PROJECTS_DIR]) != _PROJECTS_DIR:
                return f"[BLOCKED] Путь вне Projects/: {params.path}"
        except ValueError:
            return f"[BLOCKED] Недопустимый путь: {params.path}"

        try:
            os.makedirs(target, exist_ok=True)
            logger.info(f"create_dir: {target}")
            return f"[OK] Создана папка: {target}"
        except Exception as e:
            return f"[ERROR] {e}"
