"""Инструмент str_replace — точечная замена строки в файле. DANGEROUS.

Codex-style edit: вместо переписывания всего файла подаём old_str → new_str.
old_str должен быть УНИКАЛЬНЫМ в файле (иначе непонятно где менять).

Когда использовать:
  - правка конкретной функции/строки
  - исправление бага в большом файле без перезаписи
  - итеративное улучшение кода

Когда НЕ использовать:
  - создание нового файла → write_file
  - перезапись всего файла → write_file
"""
import os

from app.core.logger import get_logger
from app.core.syntax_check import syntax_check as _syntax_check
from app.tools.base import BaseTool, tool
from app.tools.write_file import _safe_path
from pydantic import BaseModel, Field

logger = get_logger(__name__)


def _make_diff(old_str: str, new_str: str) -> str:
    """Компактный unified diff замены — наглядность как в Claude Code."""
    import difflib
    diff = list(difflib.unified_diff(
        old_str.splitlines(), new_str.splitlines(),
        lineterm="", n=1,
    ))[2:]  # срезаем заголовки ---/+++
    if not diff:
        return ""
    if len(diff) > 25:
        diff = diff[:25] + [f"… (+{len(diff) - 25} строк диффа)"]
    return "\n".join(diff)


def _try_fuzzy_replace(content: str, old_str: str, new_str: str) -> str | None:
    """
    Попытка заменить old_str → new_str с допуском по пробелам.

    Частый случай: модель копирует код, но путает отступы/пробелы, и точное
    совпадение не находится. Сопоставляем блок строк по СОДЕРЖАНИЮ (strip),
    игнорируя ведущие/хвостовые пробелы. Заменяем ТОЛЬКО если найдено ровно
    одно совпадение — иначе None (неоднозначно, не рискуем).

    Возвращает новый контент или None если однозначно сопоставить не удалось.
    """
    old_lines = old_str.split("\n")
    content_lines = content.split("\n")
    old_stripped = [ln.strip() for ln in old_lines]
    n = len(old_lines)
    if n == 0 or not any(old_stripped):
        return None

    matches = []
    for i in range(len(content_lines) - n + 1):
        window = content_lines[i:i + n]
        if [w.strip() for w in window] == old_stripped:
            matches.append(i)

    if len(matches) != 1:
        return None  # 0 или >1 — неоднозначно, не трогаем

    i = matches[0]
    # Сохраняем отступ первой строки оригинала для нового блока
    indent = content_lines[i][:len(content_lines[i]) - len(content_lines[i].lstrip())]
    new_lines = new_str.split("\n") if new_str else []
    # Применяем отступ только если new_str не задаёт свой
    if new_lines and not new_lines[0].startswith((" ", "\t")):
        new_lines = [(indent + nl if nl.strip() else nl) for nl in new_lines]

    result = content_lines[:i] + new_lines + content_lines[i + n:]
    return "\n".join(result)


class StrReplaceParams(BaseModel):
    """Параметры инструмента str_replace."""
    path: str = Field(
        ...,
        min_length=1,
        max_length=512,
        description="Путь к файлу относительно Projects/ (или .staging/)",
    )
    old_str: str = Field(
        ...,
        min_length=1,
        description="Текст для поиска — должен быть УНИКАЛЬНЫМ в файле. "
                    "Включай минимум 1-2 строки контекста чтобы быть уверенным в уникальности.",
    )
    new_str: str = Field(
        default="",
        description="Текст замены. Пустая строка удаляет old_str. "
                    "Сохраняй отступы такие же как в old_str.",
    )


@tool
class StrReplaceTool(BaseTool):
    name = "str_replace"
    description = (
        "Точечная замена строки в файле. Передай path, old_str (уникальный), new_str. "
        "Использует точное совпадение, не regex. "
        "Идеально для итеративных правок — не переписывает весь файл. "
        "Если old_str встречается > 1 раза — ошибка (добавь больше контекста). "
        "Если old_str не найден — ошибка (проверь точное совпадение, включая пробелы)."
    )
    params_schema = StrReplaceParams
    dangerous = False  # точечная правка существующего файла — approval не нужен

    async def execute(self, params: StrReplaceParams) -> str:
        # Резолвим путь — приоритет: Projects/, потом .staging/
        real = _safe_path(params.path)

        # Если файла нет в Projects/ — пробуем в .staging/
        if real is None or not os.path.exists(real):
            from app.core.workspace import get_staging_dir
            staging = get_staging_dir()
            cleaned = params.path.replace("\\", "/")
            for prefix in ("Projects/", "projects/", ".staging/"):
                if cleaned.startswith(prefix):
                    cleaned = cleaned[len(prefix):]
                    break
            staging_candidate = os.path.realpath(os.path.join(staging, cleaned))
            try:
                if os.path.commonpath([staging_candidate, staging]) == staging:
                    if os.path.exists(staging_candidate):
                        real = staging_candidate
            except ValueError:
                pass

        if real is None:
            return f"[ERROR] Путь вне Projects/ и .staging/: {params.path}"
        if not os.path.exists(real):
            return f"[ERROR] Файл не существует: {params.path} (искал в Projects/ и .staging/)"
        if not os.path.isfile(real):
            return f"[ERROR] Не файл: {params.path}"

        # ── Read-before-edit (дисциплина Claude Code) ──────────────────────
        # Слепая правка по памяти — главный источник промахов old_str.
        # Если файл не читался в этом прогоне — требуем прочитать. Текущее
        # содержимое могло измениться (другие правки, fuzzy-фиксы, .bak-откаты).
        from app.core.active_project import was_file_read, mark_file_read
        if not was_file_read(real):
            return (
                f"[BLOCKED] Файл не был прочитан в этом прогоне: {params.path}\n"
                f"Сначала вызови read_file({{path: \"{params.path}\"}}), убедись в "
                f"ТОЧНОМ текущем содержимом (отступы, кавычки), затем повтори "
                f"str_replace с old_str скопированным из прочитанного."
            )

        try:
            with open(real, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            return f"[ERROR] Не удалось прочитать файл: {e}"

        # Проверяем что old_str встречается ровно один раз
        count = content.count(params.old_str)
        if count == 0:
            # ── Умное восстановление вместо тупика read→fail→read ──────────
            # Частая причина: модель ошиблась в пробелах/отступах. Пробуем
            # сопоставить по СОДЕРЖАНИЮ строк, игнорируя пробелы в начале/конце.
            fuzzy_new = _try_fuzzy_replace(content, params.old_str, params.new_str)
            if fuzzy_new is not None:
                try:
                    with open(real, "w", encoding="utf-8") as f:
                        f.write(fuzzy_new)
                    mark_file_read(real)  # после правки агент знает содержимое
                    logger.info(f"str_replace: {params.path} (fuzzy match — отступы выровнены)")
                    return (
                        f"[OK] {params.path}: заменено (совпадение по содержимому, "
                        f"отступы выровнены автоматически)"
                        + _syntax_check(real, fuzzy_new)
                    )
                except Exception as e:
                    return f"[ERROR] Не удалось записать файл: {e}"

            # Fuzzy не помог. НЕ отправляем в read_file (это создаёт цикл).
            # Даём прямую инструкцию: перепиши файл целиком через write_file.
            lines = content.split("\n")
            preview = "\n".join(f"{i+1:3}| {ln}" for i, ln in enumerate(lines[:30]))
            return (
                f"[ERROR] old_str не найден в {params.path} (точного совпадения нет).\n"
                f"НЕ повторяй str_replace с тем же old_str и НЕ читай файл снова — "
                f"это не сработает.\n"
                f"ВМЕСТО ЭТОГО: перепиши весь файл через write_file с полным "
                f"исправленным содержимым (path={params.path}).\n"
                f"Текущее содержимое (первые 30 строк, с номерами):\n{preview}"
            )
        if count > 1:
            # Несколько совпадений. Раньше просили "добавь контекст" — модель
            # не справлялась и зацикливалась. Теперь: если замена явно одинаковая
            # для всех (типовой фикс опечатки/импорта) — меняем ВСЕ сразу.
            # Признак безопасности: old_str короткий и однострочный (точечный фикс).
            if "\n" not in params.old_str and len(params.old_str) <= 80:
                new_content = content.replace(params.old_str, params.new_str)
                try:
                    with open(real, "w", encoding="utf-8") as f:
                        f.write(new_content)
                    mark_file_read(real)
                    logger.info(f"str_replace: {params.path} — заменено все {count} вхождений")
                    return (
                        f"[OK] {params.path}: заменено все {count} вхождений "
                        f"(однострочный фикс применён ко всем)"
                        + _syntax_check(real, new_content)
                    )
                except Exception as e:
                    return f"[ERROR] Не удалось записать файл: {e}"
            # Многострочный old_str с несколькими совпадениями — неоднозначно.
            return (
                f"[ERROR] old_str встречается {count} раз в {params.path}.\n"
                f"НЕ пытайся снова str_replace — перепиши весь файл через "
                f"write_file(path={params.path}) с полным исправленным кодом."
            )

        # Замена
        new_content = content.replace(params.old_str, params.new_str, 1)

        try:
            with open(real, "w", encoding="utf-8") as f:
                f.write(new_content)
        except Exception as e:
            return f"[ERROR] Не удалось записать файл: {e}"

        # Считаем какие строки изменились (для отчёта)
        old_lines = params.old_str.count("\n") + 1
        new_lines = params.new_str.count("\n") + 1 if params.new_str else 0

        mark_file_read(real)  # после правки агент знает содержимое
        logger.info(f"str_replace: {params.path} (-{old_lines}/+{new_lines} lines)")
        _diff = _make_diff(params.old_str, params.new_str)
        _diff_part = f"\n{_diff}" if _diff else ""
        return (
            f"[OK] {params.path}: заменено "
            f"(-{old_lines}/+{new_lines} строк){_diff_part}"
            + _syntax_check(real, new_content)
        )
