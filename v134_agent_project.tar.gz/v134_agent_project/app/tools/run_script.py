"""
Инструмент run_script — запускает Python файл из Projects/ на реальном Python.

В отличие от run_python (Docker sandbox), этот инструмент:
- Имеет доступ ко всем установленным пакетам (numpy, requests, и др.)
- Запускает файл из Projects/ как настоящий скрипт
- Используется Тестером для реального тестирования кода

DANGEROUS: требует подтверждения. Запускает произвольный код на хост-системе.
"""
import asyncio
import os
import subprocess
import sys

from app.core.config import settings
from app.core.logger import get_logger
from app.schemas.tool import RunScriptParams
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)

_PROJECTS_DIR = os.path.realpath(settings.projects_dir)


@tool
class RunScriptTool(BaseTool):
    name = "run_script"
    description = (
        "Запустить Python файл из Projects/ на реальном Python (с доступом ко всем установленным пакетам). "
        "params: path (путь к .py файлу внутри Projects/), timeout (сек, по умолчанию 30). "
        "Используй для тестирования кода который требует внешние пакеты."
    )
    params_schema = RunScriptParams
    dangerous = True

    async def execute(self, params: RunScriptParams) -> str:
        # Резолвим путь внутри Projects/ или .staging/
        cleaned = params.path.replace("\\", "/")
        for prefix in ("Projects/", "projects/"):
            if cleaned.startswith(prefix):
                cleaned = cleaned[len(prefix):]
                break
        if os.path.isabs(cleaned):
            script_path = os.path.realpath(cleaned)
        else:
            # Сначала ищем в финальной папке
            candidate = os.path.realpath(os.path.join(_PROJECTS_DIR, cleaned))
            if not os.path.exists(candidate):
                # Fallback: ищем в staging
                staging_candidate = os.path.realpath(
                    os.path.join(_PROJECTS_DIR, ".staging", cleaned)
                )
                if os.path.exists(staging_candidate):
                    candidate = staging_candidate
                    logger.info(f"run_script: found in staging: {staging_candidate}")
            script_path = candidate

        # Проверяем что файл внутри Projects/
        try:
            if os.path.commonpath([script_path, _PROJECTS_DIR]) != _PROJECTS_DIR:
                return f"[BLOCKED] Файл вне Projects/: {params.path}"
        except ValueError:
            return f"[BLOCKED] Недопустимый путь: {params.path}"

        if not os.path.exists(script_path):
            return f"[ERROR] Файл не найден: {script_path}"
        if not script_path.endswith(".py"):
            return f"[ERROR] Только .py файлы: {params.path}"

        timeout = min(params.timeout or 30, 120)  # максимум 2 минуты
        logger.info(f"run_script: {script_path} (timeout={timeout}s)")

        try:
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                lambda: subprocess.run(
                    [sys.executable, script_path],
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                    cwd=os.path.dirname(script_path),
                )
            )
            stdout = result.stdout[:2000] if result.stdout else ""
            # stderr держим длиннее — там traceback (тип ошибки, файл, строка).
            # Берём ХВОСТ: у Python суть ошибки в конце трейсбэка.
            _raw_err = result.stderr or ""
            stderr = _raw_err[-4000:] if len(_raw_err) > 4000 else _raw_err

            if result.returncode == 0:
                out = f"[OK] Завершено успешно\n{stdout}" if stdout else "[OK] Завершено без вывода"
            else:
                # Показываем stderr явно — агент должен видеть ImportError, SyntaxError и т.д.
                error_detail = stderr or stdout or "(нет вывода)"
                out = (
                    f"[ERROR] Скрипт завершился с ошибкой (код {result.returncode}):\n"
                    f"{error_detail}\n"
                    f"Прочитай ошибку, исправь файл через write_file или str_replace."
                )

            logger.info(f"run_script done: rc={result.returncode} {script_path}")
            return out
        except subprocess.TimeoutExpired:
            # GUI-приложения (pygame, tkinter) держат event loop — timeout нормален
            return (
                f"[TIMEOUT] Скрипт работал дольше {timeout}с и был остановлен.\n"
                f"Для GUI-приложений (pygame, tkinter, Qt) это НОРМАЛЬНО — игра запустилась.\n"
                f"Не пытайся исправить timeout, просто сохраняй проект через save_project."
            )
        except Exception as e:
            return f"[ERROR] {e}"
