"""
Инструмент web_search — поиск с несколькими бэкендами.

ВАЖНО (история бага): api.duckduckgo.com — это Instant Answer API
(энциклопедия: Wikipedia abstracts, определения), а НЕ веб-поиск.
Погода/новости/актуальные данные через него НЕ находятся — всегда пусто.
Поэтому без платных ключей реальный поиск идёт через DDG HTML (скрейпинг
lite.duckduckgo.com — стабильная годами текстовая версия).

Порядок бэкендов:
  0. wttr.in        — погодные запросы напрямую (без ключа, русские города)
  1. SearXNG        — ЛОКАЛЬНЫЙ метапоиск в Docker (SEARXNG_URL, без лимитов)
  2. Brave API      — если BRAVE_API_KEY (2000 запросов/мес бесплатно)
  3. SerpAPI        — если SERPAPI_KEY
  4. DDG HTML       — реальный поиск без ключей (скрейпинг lite-версии)
  5. DDG Instant    — энциклопедический фолбэк (как раньше, последним)

Запуск SearXNG (один раз) — см. searxng_setup.yml в корне проекта:
  docker run -d --name searxng --restart unless-stopped -p 8888:8080
    -v <путь>/settings.yml:/etc/searxng/settings.yml searxng/searxng
"""
import asyncio
import json
import os
import re
import time
from collections import deque

import httpx

from app.core.config import settings
from app.core.logger import get_logger
from app.schemas.tool import WebSearchParams
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)

_call_times: deque = deque()
_lock: asyncio.Lock | None = None


# ── Погода: прямой канал wttr.in ─────────────────────────────────────────────

_WEATHER_RE = re.compile(r"\bпогод\w*|\bweather\b|\bтемператур\w*", re.IGNORECASE)
# Слова которые надо убрать из запроса чтобы остался город
_WEATHER_NOISE = re.compile(
    r"\bпогод\w*|\bweather\b|\bтемператур\w*|\bкака\w+|\bсейчас\b|\bсегодня\b|"
    r"\bзавтра\b|\bв\b|\bна\b|\bгороде?\b|\bскажи\b|\bкакой\b|\bбудет\b|"
    r"\bin\b|\bat\b|\bthe\b|\bnow\b|\btoday\b|\btomorrow\b|\bwhat\b|\bis\b",
    re.IGNORECASE,
)


def _is_weather_query(query: str) -> bool:
    return bool(_WEATHER_RE.search(query))


def _extract_city(query: str) -> str:
    """Убираем погодные слова — остаток считаем городом."""
    city = _WEATHER_NOISE.sub(" ", query)
    city = re.sub(r"[?!.,]+", " ", city)
    city = " ".join(city.split()).strip()
    return city


async def _weather_wttr(query: str, client: httpx.AsyncClient) -> list[str]:
    """
    Погода через wttr.in: бесплатно, без ключей, понимает русские названия.
    j1 = компактный JSON: текущая погода + прогноз на 3 дня.
    """
    city = _extract_city(query)
    if not city:
        return []
    resp = await client.get(
        f"https://wttr.in/{city}",
        params={"format": "j1", "lang": "ru"},
        headers={"Accept-Language": "ru"},
        timeout=15,
    )
    if resp.status_code != 200:
        return []
    data = resp.json()

    out: list[str] = []
    # Текущая погода
    cur = (data.get("current_condition") or [{}])[0]
    if cur:
        desc = ""
        for key in ("lang_ru", "weatherDesc"):
            v = cur.get(key)
            if v and isinstance(v, list) and v[0].get("value"):
                desc = v[0]["value"]
                break
        area = ""
        na = (data.get("nearest_area") or [{}])[0]
        if na.get("areaName"):
            area = na["areaName"][0].get("value", "")
        out.append(
            f"Погода {area or city} сейчас: {desc}, {cur.get('temp_C','?')}°C "
            f"(ощущается {cur.get('FeelsLikeC','?')}°C), "
            f"ветер {cur.get('windspeedKmph','?')} км/ч, "
            f"влажность {cur.get('humidity','?')}%"
        )
    # Прогноз: сегодня и завтра
    for i, day in enumerate((data.get("weather") or [])[:2]):
        label = "Сегодня" if i == 0 else "Завтра"
        hourly = day.get("hourly") or []
        midday = hourly[4] if len(hourly) > 4 else (hourly[0] if hourly else {})
        d_desc = ""
        for key in ("lang_ru", "weatherDesc"):
            v = midday.get(key)
            if v and isinstance(v, list) and v[0].get("value"):
                d_desc = v[0]["value"]
                break
        out.append(
            f"{label} ({day.get('date','')}): {d_desc}, "
            f"{day.get('mintempC','?')}…{day.get('maxtempC','?')}°C"
        )
    return out


# ── Реальный веб-поиск: DDG HTML (lite-версия, без ключей) ──────────────────

# lite.duckduckgo.com — текстовая версия, структура стабильна годами:
#   <a rel="nofollow" href="URL" class='result-link'>Title</a>
#   <td class='result-snippet'>Snippet</td>
_DDG_LINK_RE = re.compile(
    r"<a[^>]+class=['\"]result-link['\"][^>]*href=['\"]([^'\"]+)['\"][^>]*>(.*?)</a>"
    r"|<a[^>]+href=['\"]([^'\"]+)['\"][^>]*class=['\"]result-link['\"][^>]*>(.*?)</a>",
    re.DOTALL,
)
_DDG_SNIPPET_RE = re.compile(
    r"<td[^>]*class=['\"]result-snippet['\"][^>]*>(.*?)</td>", re.DOTALL
)
_TAG_RE = re.compile(r"<[^>]+>")


def _clean_html(text: str) -> str:
    text = _TAG_RE.sub("", text)
    text = (text.replace("&amp;", "&").replace("&lt;", "<")
                .replace("&gt;", ">").replace("&quot;", '"')
                .replace("&#x27;", "'").replace("&nbsp;", " "))
    return " ".join(text.split()).strip()


def _parse_ddg_lite(html: str, limit: int = 5) -> list[str]:
    """Парсим lite.duckduckgo.com: пары (ссылка+заголовок, сниппет)."""
    links: list[tuple[str, str]] = []
    for m in _DDG_LINK_RE.finditer(html):
        url = m.group(1) or m.group(3) or ""
        title = _clean_html(m.group(2) or m.group(4) or "")
        if url and title:
            links.append((url, title))
        if len(links) >= limit:
            break
    snippets = [_clean_html(s) for s in _DDG_SNIPPET_RE.findall(html)[:limit]]

    results = []
    for i, (url, title) in enumerate(links):
        snip = snippets[i] if i < len(snippets) else ""
        results.append(f"{title}: {snip} ({url})" if snip else f"{title} ({url})")
    return results


async def _search_ddg_html(query: str, client: httpx.AsyncClient) -> list[str]:
    """Реальный веб-поиск через lite.duckduckgo.com (без API-ключей)."""
    resp = await client.post(
        "https://lite.duckduckgo.com/lite/",
        data={"q": query},
        headers={
            "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                           "AppleWebKit/537.36 (KHTML, like Gecko) "
                           "Chrome/120.0 Safari/537.36"),
            "Content-Type": "application/x-www-form-urlencoded",
        },
        timeout=15,
    )
    if resp.status_code != 200:
        return []
    return _parse_ddg_lite(resp.text)


# ── Энциклопедический фолбэк (бывший "_search_duckduckgo") ──────────────────

async def _search_ddg_instant(query: str, client: httpx.AsyncClient) -> list[str]:
    """
    DuckDuckGo Instant Answer API — НЕ поиск, а энциклопедия (Wikipedia
    abstracts, определения). Оставлен ПОСЛЕДНИМ фолбэком: иногда даёт
    хорошую справку по терминам, но погоду/новости не знает в принципе.
    """
    resp = await client.get(
        "https://api.duckduckgo.com/",
        params={"q": query, "format": "json", "no_html": "1", "skip_disambig": "1"},
        timeout=15,
    )
    data = resp.json()
    abstract = data.get("AbstractText", "").strip()
    related = [
        t["Text"] for t in data.get("RelatedTopics", [])
        if isinstance(t, dict) and t.get("Text")
    ]
    results = ([abstract] if abstract else []) + related[:5]
    return results


async def _search_searxng(query: str, client: httpx.AsyncClient) -> list[str]:
    """
    SearXNG — локальный метапоисковик (свой Docker-контейнер).
    Сам ходит в Google/Bing/DDG/Yandex и агрегирует выдачу. Без ключей,
    без лимитов API-провайдеров. URL из env SEARXNG_URL
    (по умолчанию http://localhost:8888).

    Если контейнер не поднят — connection error, тихо скипаем
    и идём дальше по цепочке бэкендов.
    """
    base = os.environ.get("SEARXNG_URL", "http://localhost:8888").rstrip("/")
    resp = await client.get(
        f"{base}/search",
        params={"q": query, "format": "json"},
        timeout=10,
    )
    if resp.status_code != 200:
        return []
    data = resp.json()
    results = []
    for r in data.get("results", [])[:5]:
        title = r.get("title", "")
        content = r.get("content", "")
        url = r.get("url", "")
        if title:
            results.append(f"{title}: {content} ({url})" if content else f"{title} ({url})")
    return results


async def _search_brave(query: str, client: httpx.AsyncClient) -> list[str]:
    """Brave Search API (нужен BRAVE_API_KEY в .env)."""
    api_key = os.environ.get("BRAVE_API_KEY", "")
    if not api_key:
        return []
    resp = await client.get(
        "https://api.search.brave.com/res/v1/web/search",
        params={"q": query, "count": 5},
        headers={"Accept": "application/json", "X-Subscription-Token": api_key},
        timeout=15,
    )
    data = resp.json()
    results = []
    for r in data.get("web", {}).get("results", []):
        title = r.get("title", "")
        desc = r.get("description", "")
        url = r.get("url", "")
        if title or desc:
            results.append(f"{title}: {desc} ({url})")
    return results


async def _search_serpapi(query: str, client: httpx.AsyncClient) -> list[str]:
    """SerpAPI (нужен SERPAPI_KEY в .env)."""
    api_key = os.environ.get("SERPAPI_KEY", "")
    if not api_key:
        return []
    resp = await client.get(
        "https://serpapi.com/search",
        params={"q": query, "engine": "google", "api_key": api_key, "num": 5},
        timeout=15,
    )
    data = resp.json()
    results = []
    for r in data.get("organic_results", []):
        title = r.get("title", "")
        snippet = r.get("snippet", "")
        link = r.get("link", "")
        results.append(f"{title}: {snippet} ({link})")
    return results


@tool
class WebSearchTool(BaseTool):
    name = "web_search"
    description = (
        "Поиск информации в интернете. params: query (строка запроса).\n"
        "Понимает погодные запросы (wttr.in). Реальный веб-поиск через "
        "DuckDuckGo HTML без ключей; Brave/SerpAPI если есть ключи в .env."
    )
    params_schema = WebSearchParams
    dangerous = False

    async def execute(self, params: WebSearchParams) -> str:
        global _lock
        if _lock is None:
            _lock = asyncio.Lock()

        query = params.query.strip()
        if not query:
            return "[ERROR] Пустой запрос"

        async with _lock:
            now = time.time()
            while _call_times and now - _call_times[0] > 60:
                _call_times.popleft()
            if len(_call_times) >= 10:
                return "[ERROR] Rate limit: слишком много запросов (10/мин)"
            _call_times.append(now)

        async with httpx.AsyncClient(
            headers={"User-Agent": "Mozilla/5.0 compatible"},
            follow_redirects=True,
        ) as client:
            # ── Погода: прямой канал, минуя поисковики ─────────────────────
            if _is_weather_query(query):
                try:
                    results = await _weather_wttr(query, client)
                    if results:
                        logger.info(f"web_search via wttr.in: погода найдена")
                        return "[OK] " + "\n".join(results)
                    logger.info("web_search: wttr.in пуст — падаем в обычный поиск")
                except Exception as e:
                    logger.debug(f"web_search wttr.in: {e}")

            # ── Обычный поиск: бэкенды по очереди ──────────────────────────
            # SearXNG первым: локальный (свой Docker), быстрый, без лимитов.
            # Не поднят — connection error за ~50мс, идём дальше.
            for name, fn in [
                ("SearXNG", _search_searxng),
                ("Brave", _search_brave),
                ("SerpAPI", _search_serpapi),
                ("DDG-HTML", _search_ddg_html),
                ("DDG-Instant", _search_ddg_instant),
            ]:
                try:
                    results = await fn(query, client)
                    if results:
                        logger.info(f"web_search via {name}: {len(results)} results")
                        return "[OK] " + "\n".join(results[:5])
                except httpx.TimeoutException:
                    logger.debug(f"web_search {name}: timeout")
                    continue
                except Exception as e:
                    logger.debug(f"web_search {name}: {e}")
                    continue

            return (
                "[OK] Поиск не вернул результатов.\n"
                "Подсказка: добавь BRAVE_API_KEY или SERPAPI_KEY в .env для лучшего поиска.\n"
                f"Запрос: {query}"
            )
