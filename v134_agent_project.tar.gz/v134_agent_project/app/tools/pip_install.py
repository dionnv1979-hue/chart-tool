"""
Инструмент pip_install — устанавливает Python-пакеты на машину пользователя.

DANGEROUS: требует подтверждения через ApprovalMiddleware.
Устанавливает в тот же Python где запущен агент (sys.executable).

Использование агентом:
    ```tool
    {"tool": "pip_install", "params": {"packages": ["requests"]}}
    ```
"""
import subprocess
import sys

from app.core.logger import get_logger
from app.schemas.tool import PipInstallParams
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)

# Пакеты которые запрещено устанавливать — защита от опасных операций
_BLACKLIST = {
    "paramiko", "cryptography", "pycryptodome",  # ssh/crypto без явной нужды
    "scapy",        # сетевые атаки
    "pywin32",      # системные операции Windows
    "psutil",       # мониторинг процессов
    "pyautogui",    # управление мышью/клавиатурой
}


@tool
class PipInstallTool(BaseTool):
    name = "pip_install"
    description = (
        "Установить Python-пакеты на машину. params: packages (список пакетов). "
        "Пример: {\"packages\": [\"requests\"]}. "
        "Требует подтверждения пользователя."
    )
    params_schema = PipInstallParams
    dangerous = True

    async def execute(self, params: PipInstallParams) -> str:
        packages = params.packages
        if not packages:
            return "[ERROR] Список пакетов пустой"

        # Проверяем blacklist
        blocked = [p for p in packages if p.lower().split("==")[0].strip() in _BLACKLIST]
        if blocked:
            logger.warning(f"pip_install blocked: {blocked}")
            return f"[BLOCKED] Установка запрещена: {blocked}"

        logger.info(f"pip_install: installing {packages}")
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install"] + packages,
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode == 0:
                # Выводим последние строки (версия установленного)
                output = result.stdout.strip()
                last_lines = "\n".join(output.split("\n")[-5:])
                logger.info(f"pip_install ok: {packages}")
                return f"[OK] Установлено: {packages}\n{last_lines}"
            else:
                err = result.stderr.strip()[:500]
                logger.error(f"pip_install failed: {err}")
                return f"[ERROR] Установка не удалась:\n{err}"
        except subprocess.TimeoutExpired:
            return "[ERROR] Таймаут установки (>120s). Попробуй вручную: pip install " + " ".join(packages)
        except Exception as e:
            return f"[ERROR] {e}"
