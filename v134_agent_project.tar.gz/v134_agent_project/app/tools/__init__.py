"""
Авто-регистрация инструментов.
Импорт каждого модуля запускает @tool декоратор → инструмент попадает в _REGISTRY.
ToolService.register_from_registry() подхватывает всё одним вызовом.
"""
from app.core.logger import get_logger

logger = get_logger(__name__)


def discover_tools() -> None:
    """
    Импортирует все модули с инструментами.
    @tool декораторы срабатывают при импорте → авто-регистрация в _REGISTRY.
    Добавить новый инструмент = создать файл + добавить импорт сюда.
    """
    from app.tools import (  # noqa: F401
        read_file,
        write_file,
        str_replace,
        list_files,
        run_python,
        run_script,
        web_search,
        save_project,
        pip_install,
        check_package,
        create_dir,
        run_code,
        todo_tracker,
        analyze_image,
        grep_files,
        web_fetch,
        rename_file,
        extract_archive,
    )
    from app.tools.base import get_registry
    names = list(get_registry().keys())
    logger.info(f"Tools discovered ({len(names)}): {names}")
