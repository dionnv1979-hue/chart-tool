"""
Инструмент rename_file — переименование файла внутри проекта.

Главный кейс: файл проекта затеняет stdlib-модуль (types.py, random.py) —
лечится ТОЛЬКО переименованием, а создание копии под новым именем оставляет
старый файл на диске, и он продолжает ломать импорты (кейс из лога:
types.py пережил 6 repair-раундов).

Ограничения безопасности:
  - только внутри Projects/
  - new_name — только имя файла (без путей), та же папка
  - целевое имя не должно существовать и не должно само затенять stdlib
"""
import os
import sys

from pydantic import BaseModel, Field

from app.core.config import settings
from app.core.logger import get_logger
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)


class RenameFileParams(BaseModel):
    """Параметры инструмента rename_file."""
    path: str = Field(..., min_length=1, max_length=512,
                      description="Текущий путь файла (внутри Projects/)")
    new_name: str = Field(..., min_length=1, max_length=128,
                          description="НОВОЕ ИМЯ файла (только имя, без папок)")


@tool
class RenameFileTool(BaseTool):
    name = "rename_file"
    description = (
        "Переименовать файл проекта. params: path, new_name (только имя, "
        "без папок — файл остаётся в той же директории). Используй когда "
        "файл затеняет стандартный модуль (types.py → game_types.py) или "
        "имя ошибочно. После переименования ОБНОВИ импорты во всех файлах "
        "(grep_files по старому имени покажет где)."
    )
    params_schema = RenameFileParams
    dangerous = False

    async def execute(self, params: RenameFileParams) -> str:
        # Резолвим исходный путь так же, как read_file
        from app.tools.read_file import _resolve_read_path
        real = _resolve_read_path(params.path)
        base = os.path.realpath(settings.projects_dir)
        try:
            if os.path.commonpath([os.path.realpath(real), base]) != base:
                return f"[BLOCKED] Путь вне Projects/: {params.path}"
        except ValueError:
            return f"[BLOCKED] Недопустимый путь: {params.path}"
        if not os.path.isfile(real):
            return f"[ERROR] Файл не найден: {params.path}"

        new_name = os.path.basename(params.new_name.strip())
        if new_name != params.new_name.strip():
            return f"[ERROR] new_name должен быть именем файла без папок: {params.new_name}"
        if not new_name or new_name.startswith("."):
            return f"[ERROR] Недопустимое имя: {new_name}"

        # Целевое имя не должно само затенять stdlib
        stem = os.path.splitext(new_name)[0].lower()
        if (new_name.endswith(".py") and stem in sys.stdlib_module_names
                and stem not in {"test", "main", "tests", "setup", "run", "app"}):
            return (f"[BLOCKED] Новое имя '{new_name}' тоже затеняет стандартный "
                    f"модуль. Возьми, например, 'game_{stem}.py'.")

        target = os.path.join(os.path.dirname(real), new_name)
        if os.path.exists(target):
            return f"[ERROR] Файл с именем {new_name} уже существует в этой папке."

        try:
            os.rename(real, target)
        except OSError as e:
            return f"[ERROR] Переименование не удалось: {e}"

        # Чеклист: если старое имя было отмечено — отметим новое
        try:
            from app.core.active_project import was_file_read, mark_file_read, \
                mark_file_written
            mark_file_read(target)
            mark_file_written(target)
        except Exception:
            pass

        old_stem = os.path.splitext(os.path.basename(real))[0]
        logger.info(f"rename_file: {os.path.basename(real)} → {new_name}")
        return (
            f"[OK] Переименован: {os.path.basename(real)} → {new_name}\n"
            f"ТЕПЕРЬ ОБНОВИ ИМПОРТЫ: grep_files({{pattern: \"{old_stem}\"}}) "
            f"покажет все файлы с 'import {old_stem}' / 'from {old_stem} import' — "
            f"замени на '{os.path.splitext(new_name)[0]}' через str_replace."
        )
