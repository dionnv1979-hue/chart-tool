"""Инструмент save_project — сохраняет проект на диск. DANGEROUS."""
import os
import re

from app.core.config import settings
from app.core.logger import get_logger
from app.core.workspace import get_project_staging_path, get_project_final_path
from app.schemas.tool import SaveProjectParams
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)
_PROJECTS_DIR = os.path.realpath(settings.projects_dir)


def _strip_fences(content: str) -> str:
    """Убирает markdown-фенсы и префиксы результатов инструментов."""
    content = content.strip()
    # Снимаем префикс read_file: "[OK] path (N символов):\n<код>"
    m = re.match(r'^\[OK\]\s+\S.*?\(\d+\s*символ\w*\):\s*\n', content)
    if m:
        content = content[m.end():]
    # Убираем markdown-фенсы
    content = re.sub(r'^```[\w]*\n', '', content)
    content = re.sub(r'\n```$', '', content)
    return content.strip()


def _is_garbage(content: str) -> bool:
    """
    Проверяет что контент — мусор (tool-вызов, результат инструмента).
    НЕ блокирует реальный код даже если он начинается с # комментария.
    """
    s = content.strip()
    # Tool-блоки попавшие в контент
    if s.startswith('tool\n{') or s.startswith('```tool'):
        return True
    if re.match(r'^tool\s*\n\s*\{', s):
        return True
    # Результаты инструментов — только если ВСЁ содержимое это результат
    # (короткие строки типа "[OK] Записан: path (N символов):")
    # [OK] Записан: path (N символов): — результат write_file
    if re.match(r'^\[(?:OK|ERROR|BLOCKED|WARNING)\]\s+\S.*\(\d+ символ', s):
        return True
    # Просто [ERROR] или [OK] без кода
    if re.match(r'^\[(?:OK|ERROR|BLOCKED|WARNING)\]\s*$', s):
        return True
    return False


@tool
class SaveProjectTool(BaseTool):
    name = "save_project"
    description = (
        f"Сохранить проект → {settings.projects_dir}. "
        "params: name (str), files (dict filename→content), "
        "staging (bool, default=false — сохранить во временную папку для тестирования)"
    )
    params_schema = SaveProjectParams
    dangerous = True

    async def execute(self, params: SaveProjectParams) -> str:
        if not params.files:
            return "[ERROR] save_project: нет файлов для сохранения. Передай dict {filename: content}."

        safe_name = re.sub(r"[^\w\-]", "_", params.name)

        # #5: если зафиксировано каноническое имя проекта — используем его,
        # чтобы Кодер не плодил папки-дубликаты (Tetris vs TetrisGame).
        from app.core.active_project import get_active_project
        _active = get_active_project()
        if _active:
            _canon = re.sub(r"[^\w\-]", "_", _active)
            if _canon and _canon != safe_name:
                logger.info(f"save_project: имя '{safe_name}' → каноническое '{_canon}'")
                safe_name = _canon

        # ── Выбираем папку назначения ─────────────────────────────────────────
        if params.staging:
            # Staging: временная папка для разработки и тестирования
            project_path = get_project_staging_path(safe_name)
            mode_label = "STAGING"
        else:
            # Финальная: только готовый проверенный код
            project_path = get_project_final_path(safe_name)
            os.makedirs(project_path, exist_ok=True)
            mode_label = "FINAL"

        # Проверяем что нет файлов-заглушек (только pass или # TODO)
        stubs = []
        for fname, content in params.files.items():
            stripped = content.strip()
            if stripped in ("pass", "# TODO", "", "# Здесь будет реализация"):
                stubs.append(fname)
            elif stripped.startswith("# ") and len(stripped.split("\n")) <= 4 and "pass" in stripped:
                stubs.append(fname)
        if stubs and not params.staging:
            return (
                f"[ERROR] Файлы содержат только заглушки (pass/# TODO): {stubs}\n"
                f"Напиши реальный код во все файлы ПЕРЕД вызовом save_project.\n"
                f"Используй write_file или включи полный код в параметр files."
            )

        try:
            saved = []
            for fname, content in params.files.items():
                # Поддерживаем подпапки в имени файла (src/main.py)
                safe_rel = "/".join(
                    re.sub(r"[^\w\-\.]", "_", part)
                    for part in fname.replace("\\", "/").split("/")
                    if part
                )
                if not safe_rel:
                    continue
                fpath = os.path.join(project_path, safe_rel)
                os.makedirs(os.path.dirname(fpath), exist_ok=True)
                cleaned = _strip_fences(content)
                if _is_garbage(cleaned):
                    logger.warning(f"save_project: пропуск мусорного контента в {safe_rel}")
                    continue
                with open(fpath, "w", encoding="utf-8") as f:
                    f.write(cleaned)
                saved.append(fpath)

            logger.info(f"save_project [{mode_label}]: '{safe_name}' ({len(saved)} files)")

            if params.staging:
                files_list = "\n".join(f"  {f}" for f in saved)
                return (
                    f"[OK] Проект '{safe_name}' сохранён в STAGING\n"
                    f"  Путь: {project_path}\n"
                    f"{files_list}\n\n"
                    f"📋 Далее Тестер проверит код через run_script.\n"
                    f"После успешного тестирования система перенесёт в финальную папку."
                )

            return (
                f"[OK] Проект '{safe_name}' → {project_path}\n"
                + "\n".join(f"  {f}" for f in saved)
            )
        except Exception as e:
            return f"[ERROR] {e}"
