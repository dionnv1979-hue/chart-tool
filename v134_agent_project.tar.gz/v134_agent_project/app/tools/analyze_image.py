"""
Инструмент analyze_image — анализ изображения через vision-модель.

Зачем: основные агенты (qwen3-coder и т.п.) НЕ умеют видеть картинки.
Этот инструмент — мост: любой агент передаёт путь к изображению, внутри
вызывается vision-модель (qwen2.5vl), агент получает текстовое описание.

Так работает Claude Code: модель-оркестратор получает результат анализа,
сама картинку не «видит».

Поддержка: jpg, jpeg, png, webp, gif, bmp. Модель: env VISION_MODEL,
по умолчанию qwen2.5vl:7b.
"""
import base64
import os

from pydantic import BaseModel, Field

from app.core.config import settings
from app.core.logger import get_logger
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)

_IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp")
_MAX_IMAGE_BYTES = 15 * 1024 * 1024


def _resolve_image_path(user_path: str) -> str | None:
    """Резолвим путь как read_file: относительные — в Projects/."""
    from app.tools.read_file import _resolve_read_path
    real = _resolve_read_path(user_path)
    home = os.path.realpath(os.path.expanduser("~"))
    try:
        if os.path.commonpath([real, home]) != home:
            return None
    except ValueError:
        return None
    return real


class AnalyzeImageParams(BaseModel):
    """Параметры инструмента analyze_image."""
    path: str = Field(..., min_length=1, max_length=512,
                      description="Путь к изображению (jpg/png/webp/gif/bmp)")
    question: str = Field(
        default="",
        max_length=500,
        description="Что именно смотреть (опционально). Например: "
                    "'какой текст на скриншоте' или 'опиши ошибку в консоли'",
    )


@tool
class AnalyzeImageTool(BaseTool):
    name = "analyze_image"
    description = (
        "Проанализировать изображение (скриншот, фото, диаграмму) через "
        "vision-модель. params: path, question (опционально — что именно смотреть). "
        "Возвращает текстовое описание содержимого. Используй для: скриншотов "
        "ошибок, макетов UI, фото документов, диаграмм."
    )
    params_schema = AnalyzeImageParams
    dangerous = False

    async def execute(self, params: AnalyzeImageParams) -> str:
        real = _resolve_image_path(params.path)
        if real is None:
            return f"[BLOCKED] Путь вне домашней директории: {params.path}"
        if not os.path.isfile(real):
            return f"[ERROR] Файл не найден: {params.path}"
        if not real.lower().endswith(_IMAGE_EXTS):
            return (f"[ERROR] Не изображение: {params.path}. "
                    f"Поддержка: {', '.join(_IMAGE_EXTS)}")
        size = os.path.getsize(real)
        if size > _MAX_IMAGE_BYTES:
            return f"[ERROR] Изображение слишком большое: {size // 1024 // 1024}MB (макс 15MB)"

        try:
            with open(real, "rb") as f:
                img_b64 = base64.b64encode(f.read()).decode("ascii")
        except Exception as e:
            return f"[ERROR] Не удалось прочитать: {e}"

        # Vision-модель: env VISION_MODEL → дефолт qwen2.5vl:7b
        vision_model = os.environ.get("VISION_MODEL", "qwen2.5vl:7b")

        from app.core.dependencies import get_ollama_service
        ollama = get_ollama_service()
        if hasattr(ollama, "supports_vision") and not ollama.supports_vision(vision_model):
            return (f"[ERROR] Модель {vision_model} не поддерживает изображения. "
                    f"Установи vision-модель: ollama pull qwen2.5vl:7b "
                    f"(или задай VISION_MODEL в .env)")

        question = params.question.strip() or (
            "Опиши подробно что на изображении. Если это скриншот кода или "
            "ошибки — приведи текст дословно. Если UI — опиши элементы и их "
            "состояние. Если документ — извлеки текст."
        )
        prompt = f"{question}\n\nОтвечай по-русски, конкретно, без воды."

        logger.info(f"analyze_image: {os.path.basename(real)} "
                    f"({size // 1024}KB) → {vision_model}")
        result = await ollama.generate(
            prompt, images=[img_b64], model=vision_model, temperature=0.1,
        )
        if not result or result.startswith(("[TIMEOUT]", "[API ERROR")):
            return f"[ERROR] Vision-модель не ответила: {result[:100]}"
        return f"[OK] Анализ {os.path.basename(real)}:\n{result[:4000]}"
