"""Инструмент list_files — список файлов в директории."""
import json
import os

from app.core.config import settings
from app.core.logger import get_logger
from app.schemas.tool import ListFilesParams
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)

# Используем projects_dir из settings (не хардкод ~/Projects)
_PROJECTS_DIR = os.path.realpath(settings.projects_dir)
# Разрешаем также desktop/agent_project для чтения
_AGENT_DIR = os.path.realpath(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
_HOME = os.path.realpath(os.path.expanduser("~"))


def _is_allowed(path: str) -> bool:
    """Разрешаем доступ к Projects/, agent_project/ и домашней директории."""
    real = os.path.realpath(path)
    try:
        if os.path.commonpath([real, _PROJECTS_DIR]) == _PROJECTS_DIR:
            return True
        if os.path.commonpath([real, _AGENT_DIR]) == _AGENT_DIR:
            return True
        if os.path.commonpath([real, _HOME]) == _HOME:
            return True
    except ValueError:
        pass
    return False


@tool
class ListFilesTool(BaseTool):
    name = "list_files"
    description = (
        f"Список файлов в директории. params: path (опционально). "
        f"По умолчанию показывает {settings.projects_dir}"
    )
    params_schema = ListFilesParams
    dangerous = False

    async def execute(self, params: ListFilesParams) -> str:
        target = params.path or _PROJECTS_DIR
        # Относительный путь → в Projects/ с канонизацией корня проекта (#5),
        # чтобы автофикс смотрел в реальную папку проекта, а не в CWD.
        if not os.path.isabs(target):
            cleaned = target.replace("\\", "/")
            while cleaned.startswith("./"):
                cleaned = cleaned[2:]
            from app.core.active_project import canonicalize_path
            cleaned = canonicalize_path(cleaned)
            for prefix in ("Projects/", "projects/"):
                if cleaned.startswith(prefix):
                    cleaned = cleaned[len(prefix):]
                    break
            target = os.path.join(_PROJECTS_DIR, cleaned) if cleaned else _PROJECTS_DIR
        abs_target = os.path.realpath(os.path.abspath(target))

        if not _is_allowed(abs_target):
            return json.dumps({"ok": False, "error": "Access denied"})

        if not os.path.exists(abs_target):
            # Подсказка: покажем Projects/ если путь не найден
            hint = f"Не существует: {abs_target}. Попробуй path={_PROJECTS_DIR}"
            return json.dumps({"ok": False, "error": hint})
        if not os.path.isdir(abs_target):
            return json.dumps({"ok": False, "error": f"Не директория: {abs_target}"})

        try:
            items = []
            for name in sorted(os.listdir(abs_target)):
                full = os.path.join(abs_target, name)
                is_dir = os.path.isdir(full)
                items.append({
                    "name": name,
                    "kind": "dir" if is_dir else "file",
                    "size": 0 if is_dir else os.path.getsize(full),
                    "path": full,
                })
            logger.debug(f"list_files: {abs_target} → {len(items)} items")
            return json.dumps({"ok": True, "path": abs_target, "items": items})
        except Exception as e:
            return json.dumps({"ok": False, "error": str(e)})
