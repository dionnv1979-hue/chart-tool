"""Инструмент todo_tracker — управление списком задач агента.

Codex-style task tracking: агент ведёт явный список TODO и отмечает выполненные.
Помогает не теряться в длинных задачах, видеть прогресс, не делать дважды.

Операции:
  - add:    добавить задачу
  - done:   отметить задачу выполненной
  - list:   показать текущий список
  - clear:  очистить список

TODO хранятся в файле .todo.json в корне staging для текущего проекта.
"""
import json
import os

from app.core.logger import get_logger
from app.core.workspace import get_staging_dir
from app.tools.base import BaseTool, tool
from pydantic import BaseModel, Field
from typing import Literal

logger = get_logger(__name__)

_TODO_FILE = "_agent_todos.json"

# Текущий session_id — устанавливается из execute()
_current_session: str = "default"


def set_todo_session(session_id: str) -> None:
    """Устанавливает session_id для изоляции задач между запросами."""
    global _current_session
    _current_session = session_id or "default"


# #6: счётчик фейковых "done" по сессиям — для эскалации предупреждений
_fake_counts: dict[str, int] = {}


def _bump_fake_count() -> int:
    """Увеличить счётчик фейковых done для текущей сессии. Вернуть новое значение."""
    _fake_counts[_current_session] = _fake_counts.get(_current_session, 0) + 1
    return _fake_counts[_current_session]


def _reset_fake_count() -> None:
    """Сбросить счётчик фейков (после реальной работы)."""
    _fake_counts.pop(_current_session, None)


def _todo_path() -> str:
    """Путь к файлу со списком задач — изолирован по session_id."""
    fname = f"_todos_{_current_session[:16]}.json"
    return os.path.join(get_staging_dir(), fname)


def _load_todos() -> list[dict]:
    """Загружает список TODO. Каждый item: {id, task, done}."""
    path = _todo_path()
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []


def _save_todos(todos: list[dict]) -> None:
    """Сохраняет список TODO."""
    path = _todo_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(todos, f, ensure_ascii=False, indent=2)


def _format_todos(todos: list[dict]) -> str:
    """Форматирует список для вывода агенту."""
    if not todos:
        return "(список пуст)"
    lines = []
    for t in todos:
        mark = "✅" if t.get("done") else "⏳"
        lines.append(f"  {mark} #{t['id']}: {t['task']}")
    done_count = sum(1 for t in todos if t.get("done"))
    return f"TODO ({done_count}/{len(todos)} выполнено):\n" + "\n".join(lines)


class TodoTrackerParams(BaseModel):
    """Параметры инструмента todo_tracker."""
    action: Literal["add", "done", "list", "clear"] = Field(
        ...,
        description="Действие: add (добавить), done (отметить выполненной), "
                    "list (показать), clear (очистить)",
    )
    task: str | None = Field(
        default=None,
        max_length=500,
        description="Текст задачи (для action=add)",
    )
    id: int | None = Field(
        default=None,
        description="Номер задачи (для action=done)",
    )


@tool
class TodoTrackerTool(BaseTool):
    name = "todo_tracker"
    description = (
        "Управление списком задач (TODO). "
        "Действия: "
        "add ({action:'add', task:'описание'}) — добавить задачу, "
        "done ({action:'done', id:1}) — отметить выполненной, "
        "list ({action:'list'}) — показать текущий список, "
        "clear ({action:'clear'}) — очистить весь список. "
        "Используй чтобы декомпозировать большую задачу и отслеживать прогресс."
    )
    params_schema = TodoTrackerParams
    dangerous = False

    async def execute(self, params: TodoTrackerParams) -> str:
        # Изолируем задачи по session (передаётся через meta агентом)
        # session_id доступен если агент его передал; иначе используем текущий
        todos = _load_todos()

        if params.action == "add":
            if not params.task:
                return "[ERROR] Для action=add нужно указать task"
            # Проверяем на дубликат (не добавляем если такая задача уже есть)
            task_lower = params.task.lower().strip()
            for existing in todos:
                if existing["task"].lower().strip() == task_lower:
                    status = "✅ выполнена" if existing["done"] else "⏳ в процессе"
                    return (f"[INFO] Задача с таким текстом уже есть (#{existing['id']}, {status})\n\n"
                            f"{_format_todos(todos)}")
            next_id = max((t["id"] for t in todos), default=0) + 1
            import time as _t
            todos.append({"id": next_id, "task": params.task, "done": False, "created_at": _t.time()})
            _save_todos(todos)
            logger.info(f"todo added: #{next_id}: {params.task}")
            return f"[OK] Добавлена задача #{next_id}: {params.task}\n\n{_format_todos(todos)}"

        if params.action == "done":
            if params.id is None:
                return "[ERROR] Для action=done нужно указать id"
            for t in todos:
                if t["id"] == params.id:
                    if t["done"]:
                        return f"[INFO] Задача #{params.id} уже выполнена\n\n{_format_todos(todos)}"
                    # Детектируем имитацию: задача создана менее 3 секунд назад
                    import time
                    created_at = t.get("created_at", 0)
                    if created_at and (time.time() - created_at) < 3:
                        # #6: считаем повторные фейки — эскалируем сообщение,
                        # чтобы модель не игнорировала предупреждение по кругу.
                        fakes = _bump_fake_count()
                        logger.warning(
                            f"FAKE TODO: #{params.id} marked done "
                            f"{time.time()-created_at:.1f}s after creation! (фейк #{fakes})"
                        )
                        if fakes >= 3:
                            return (
                                f"[BLOCKED] Задача #{params.id}: повторная имитация работы "
                                f"({fakes}-й раз отмечаешь done сразу после создания).\n"
                                f"Прекрати помечать задачи выполненными без реальной работы.\n"
                                f"Сделай ОДНО из: напиши файл через write_file, "
                                f"либо дай финальный ответ. todo_tracker done больше "
                                f"не сработает, пока не появится результат."
                            )
                        return (
                            f"[WARNING] Задача #{params.id} создана {time.time()-created_at:.0f}с назад.\n"
                            f"Отметить как выполненную можно только после реальной работы.\n"
                            f"Напиши код через write_file, потом вызови todo_tracker done."
                        )
                    t["done"] = True
                    _reset_fake_count()  # реальная работа — сбрасываем счётчик фейков
                    _save_todos(todos)
                    logger.info(f"todo done: #{params.id}")
                    return f"[OK] Задача #{params.id} выполнена\n\n{_format_todos(todos)}"
            return f"[ERROR] Задача #{params.id} не найдена"

        if params.action == "list":
            result = _format_todos(todos)
            if todos and all(not t.get("done") for t in todos):
                result += (
                    "\n\n[НАПОМИНАНИЕ] Все задачи в процессе. "
                    "Напиши реальный код, затем вызови done. "
                    "НЕ вызывай list снова — это трата шагов."
                )
            return result

        if params.action == "clear":
            count = len(todos)
            _save_todos([])
            logger.info(f"todos cleared ({count})")
            return f"[OK] Список очищен ({count} задач удалено)"

        return f"[ERROR] Неизвестное действие: {params.action}"
