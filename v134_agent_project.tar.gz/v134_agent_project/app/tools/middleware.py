"""
Tool middleware chain.
Паттерн: каждый middleware получает контекст и next() функцию.
Middlewares применяются по порядку списка.

Tool → [MetricsMiddleware → ApprovalMiddleware → RetryMiddleware] → execute()

Добавить новый middleware:
1. Наследуй ToolMiddleware
2. Реализуй process()
3. Добавь в DEFAULT_MIDDLEWARES

Использование в ToolService:
    chain = MiddlewareChain(middlewares=[MetricsMiddleware(), ApprovalMiddleware()])
    result = await chain.run(tool, params)
"""
from __future__ import annotations

import abc
import time
from typing import Callable, Awaitable

from app.core.logger import get_logger
from app.tools.base import ApprovalRequired, BaseTool

logger = get_logger(__name__)


class ToolContext:
    """Контекст выполнения инструмента. Передаётся через всю цепочку."""

    def __init__(self, tool: BaseTool, raw_params: dict) -> None:
        self.tool = tool
        self.raw_params = raw_params
        self.started_at: float = time.monotonic()
        # Metadata для логов/метрик
        self.meta: dict = {}


class ToolMiddleware(abc.ABC):
    """Базовый класс middleware."""

    @abc.abstractmethod
    async def process(
        self,
        ctx: ToolContext,
        call_next: Callable[[ToolContext], Awaitable[str]],
    ) -> str: ...


# ── ApprovalMiddleware ────────────────────────────────────────────────────────

class ApprovalMiddleware(ToolMiddleware):
    """
    Перехватывает dangerous tools — бросает ApprovalRequired.
    BaseAgent ловит и конвертирует в confirm response.
    skip_approval=True в ctx.meta → выполняем без паузы (после подтверждения).
    """

    async def process(self, ctx: ToolContext, call_next) -> str:
        # Проверяем глобальный переключатель auto_approve
        from app.core.auto_approve import is_auto_approve
        if ctx.tool.dangerous and not ctx.meta.get("skip_approval", False) and not is_auto_approve():
            raise ApprovalRequired(ctx.tool.name, ctx.raw_params)
        return await call_next(ctx)


# ── MetricsMiddleware ─────────────────────────────────────────────────────────

class MetricsMiddleware(ToolMiddleware):
    """
    Замеряет время выполнения каждого инструмента.
    Пишет structured log с duration_ms.
    """

    async def process(self, ctx: ToolContext, call_next) -> str:
        from app.core.metrics import metrics
        start = time.monotonic()
        success = True
        try:
            result = await call_next(ctx)
            duration_ms = int((time.monotonic() - start) * 1000)
            ctx.meta["duration_ms"] = duration_ms
            logger.info(
                f"[TOOL] {ctx.tool.name} ok",
                extra={"tool": ctx.tool.name, "duration_ms": duration_ms, "dangerous": ctx.tool.dangerous},
            )
            return result
        except ApprovalRequired:
            raise
        except Exception as e:
            success = False
            duration_ms = int((time.monotonic() - start) * 1000)
            logger.error(
                f"[TOOL] {ctx.tool.name} error in {duration_ms}ms: {e}",
                extra={"tool": ctx.tool.name, "duration_ms": duration_ms, "error": str(e)},
            )
            raise
        finally:
            if "duration_ms" in ctx.meta or not success:
                duration_ms = ctx.meta.get("duration_ms", int((time.monotonic() - start) * 1000))
                metrics.record_tool(
                    tool=ctx.tool.name,
                    duration_ms=duration_ms,
                    success=success,
                    dangerous=ctx.tool.dangerous,
                )


# ── RetryMiddleware ───────────────────────────────────────────────────────────

class RetryMiddleware(ToolMiddleware):
    """
    Retry для transient ошибок (сеть, таймаут).
    Не повторяет опасные инструменты и ApprovalRequired.
    """

    def __init__(self, max_retries: int = 2, retry_on: tuple = (ConnectionError, TimeoutError)):
        self._max = max_retries
        self._retry_on = retry_on

    async def process(self, ctx: ToolContext, call_next) -> str:
        last_exc = None
        for attempt in range(self._max + 1):
            try:
                return await call_next(ctx)
            except ApprovalRequired:
                raise
            except self._retry_on as e:
                last_exc = e
                if attempt < self._max:
                    logger.warning(
                        f"[TOOL] {ctx.tool.name} retry {attempt + 1}/{self._max}: {e}"
                    )
                    import asyncio
                    await asyncio.sleep(0.5 * (attempt + 1))
        raise last_exc  # type: ignore


# ── Middleware chain ──────────────────────────────────────────────────────────

class MiddlewareChain:
    """
    Цепочка middlewares.
    Каждый middleware оборачивает следующий как матрёшка.

    Порядок: первый в списке = внешний (выполняется первым).
    MetricsMiddleware → ApprovalMiddleware → RetryMiddleware → execute()
    """

    def __init__(self, middlewares: list[ToolMiddleware]) -> None:
        self._middlewares = middlewares

    async def run(self, tool: BaseTool, raw_params: dict, **meta) -> str:
        """
        Запустить цепочку.
        meta передаётся в ctx.meta (например skip_approval=True).
        """
        ctx = ToolContext(tool=tool, raw_params=raw_params)
        ctx.meta.update(meta)

        async def execute_tool(ctx: ToolContext) -> str:
            validated = tool.validate_params(ctx.raw_params)
            return await tool.execute(validated)

        # Строим цепочку в обратном порядке
        chain_fn = execute_tool
        for mw in reversed(self._middlewares):
            # Замыкание чтобы захватить правильный mw и chain_fn
            def make_next(m, nxt):
                async def _next(c: ToolContext) -> str:
                    return await m.process(c, nxt)
                return _next
            chain_fn = make_next(mw, chain_fn)

        return await chain_fn(ctx)


# ── Default chain для production ──────────────────────────────────────────────

def build_default_chain() -> MiddlewareChain:
    """
    Стандартная цепочка для production.
    Metrics → Approval → Retry
    """
    return MiddlewareChain([
        MetricsMiddleware(),
        ApprovalMiddleware(),
        RetryMiddleware(max_retries=1),
    ])
