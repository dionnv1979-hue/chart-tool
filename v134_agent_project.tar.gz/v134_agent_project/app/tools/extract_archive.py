"""
Инструмент extract_archive — распаковка архивов с изучением содержимого.

Поддержка (stdlib, без зависимостей): zip, tar, tar.gz/tgz, tar.bz2, tar.xz.
RAR/7z требуют внешних библиотек — честный отказ с подсказкой.

Распаковка в <имя_архива>_extracted/ рядом с архивом (внутри Projects/).
Возвращает дерево файлов — агент дальше работает через read_file.

Защиты:
  - path traversal: члены с '..' или абсолютными путями пропускаются
  - zip-bomb: лимит 500 файлов и 200MB распакованного объёма
"""
import os
import tarfile
import zipfile

from pydantic import BaseModel, Field

from app.core.logger import get_logger
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)

_MAX_FILES = 500
_MAX_TOTAL_BYTES = 200 * 1024 * 1024


def _is_within(base: str, target: str) -> bool:
    try:
        return os.path.commonpath([os.path.realpath(target),
                                   os.path.realpath(base)]) == os.path.realpath(base)
    except ValueError:
        return False


def _tree(root: str, limit: int = 100) -> str:
    """Компактное дерево содержимого (до limit записей)."""
    lines, count = [], 0
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames.sort(); filenames.sort()
        rel = os.path.relpath(dirpath, root)
        depth = 0 if rel == "." else rel.count(os.sep) + 1
        indent = "  " * depth
        if rel != ".":
            lines.append(f"{indent}📁 {os.path.basename(dirpath)}/")
            count += 1
        for fn in filenames:
            size = os.path.getsize(os.path.join(dirpath, fn))
            ks = f"{size//1024}KB" if size >= 1024 else f"{size}B"
            lines.append(f"{indent}  📄 {fn} ({ks})")
            count += 1
            if count >= limit:
                lines.append(f"  … (показано {limit}, есть ещё)")
                return "\n".join(lines)
    return "\n".join(lines) if lines else "(пусто)"


class ExtractArchiveParams(BaseModel):
    """Параметры инструмента extract_archive."""
    path: str = Field(..., min_length=1, max_length=512,
                      description="Путь к архиву (zip/tar/tar.gz/tgz/tar.bz2)")


@tool
class ExtractArchiveTool(BaseTool):
    name = "extract_archive"
    description = (
        "Распаковать архив (zip, tar, tar.gz, tgz, tar.bz2) в папку "
        "<имя>_extracted/ рядом и показать дерево содержимого. "
        "params: path. После распаковки изучай файлы через read_file."
    )
    params_schema = ExtractArchiveParams
    dangerous = False

    async def execute(self, params: ExtractArchiveParams) -> str:
        from app.tools.read_file import _resolve_read_path
        real = _resolve_read_path(params.path)
        home = os.path.realpath(os.path.expanduser("~"))
        try:
            if os.path.commonpath([real, home]) != home:
                return f"[BLOCKED] Путь вне домашней директории: {params.path}"
        except ValueError:
            return f"[BLOCKED] Недопустимый путь: {params.path}"
        if not os.path.isfile(real):
            return f"[ERROR] Архив не найден: {params.path}"

        low = real.lower()
        if low.endswith((".rar", ".7z")):
            return (f"[ERROR] Формат {os.path.splitext(real)[1]} не поддерживается "
                    f"(нужны внешние библиотеки). Переупакуй в zip.")

        base_name = os.path.basename(real)
        for ext in (".tar.gz", ".tar.bz2", ".tar.xz", ".tgz", ".tar", ".zip"):
            if low.endswith(ext):
                base_name = os.path.basename(real)[: -len(ext)]
                break
        dest = os.path.join(os.path.dirname(real), f"{base_name}_extracted")
        os.makedirs(dest, exist_ok=True)

        extracted, total_bytes, skipped = 0, 0, 0
        try:
            if low.endswith(".zip"):
                with zipfile.ZipFile(real) as zf:
                    for info in zf.infolist():
                        if extracted >= _MAX_FILES or total_bytes >= _MAX_TOTAL_BYTES:
                            skipped += 1
                            continue
                        name = info.filename
                        if name.startswith(("/", "\\")) or ".." in name.replace("\\", "/").split("/"):
                            skipped += 1
                            continue
                        target = os.path.join(dest, name)
                        if not _is_within(dest, target):
                            skipped += 1
                            continue
                        zf.extract(info, dest)
                        if not info.is_dir():
                            extracted += 1
                            total_bytes += info.file_size
            elif low.endswith((".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tar.xz")):
                with tarfile.open(real) as tf:
                    for member in tf.getmembers():
                        if extracted >= _MAX_FILES or total_bytes >= _MAX_TOTAL_BYTES:
                            skipped += 1
                            continue
                        name = member.name
                        if (name.startswith(("/", "\\"))
                                or ".." in name.replace("\\", "/").split("/")
                                or member.issym() or member.islnk()):
                            skipped += 1
                            continue
                        target = os.path.join(dest, name)
                        if not _is_within(dest, target):
                            skipped += 1
                            continue
                        tf.extract(member, dest)
                        if member.isfile():
                            extracted += 1
                            total_bytes += member.size
            else:
                return (f"[ERROR] Неизвестный формат архива: {base_name}. "
                        f"Поддержка: zip, tar, tar.gz, tgz, tar.bz2")
        except (zipfile.BadZipFile, tarfile.TarError) as e:
            return f"[ERROR] Архив повреждён или не читается: {e}"
        except Exception as e:
            return f"[ERROR] Распаковка не удалась: {e}"

        skip_note = f" (пропущено небезопасных/сверх лимита: {skipped})" if skipped else ""
        logger.info(f"extract_archive: {base_name} → {extracted} файлов, "
                    f"{total_bytes // 1024}KB{skip_note}")
        return (
            f"[OK] Распаковано: {extracted} файлов "
            f"({total_bytes // 1024}KB) в {dest}{skip_note}\n"
            f"Содержимое:\n{_tree(dest)}\n"
            f"Дальше: read_file для изучения конкретных файлов."
        )
