"""Инструмент read_file — читает файл с диска."""
import os

from app.core.config import settings
from app.core.logger import get_logger
from app.schemas.tool import ReadFileParams
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)

_HOME = os.path.realpath(os.path.expanduser("~"))
_PROJECTS_DIR = os.path.realpath(settings.projects_dir)


def _resolve_read_path(user_path: str) -> str:
    """
    Разрешаем путь так же, как write_file: относительные пути идут в Projects/
    с приведением корневой папки к каноническому имени проекта (#5).
    Это чинит баг автофикса: Кодер писал в Projects/NeonTetris, а читал из
    Desktop/agent_project/NeonTetris (CWD) → 'файл не найден'.
    """
    cleaned = user_path.replace("\\", "/")
    while cleaned.startswith("./"):
        cleaned = cleaned[2:]

    if os.path.isabs(cleaned):
        return os.path.realpath(os.path.abspath(cleaned))

    # Относительный путь — канонизируем корень проекта и кладём в Projects/
    from app.core.active_project import canonicalize_path
    cleaned = canonicalize_path(cleaned)
    for prefix in ("Projects/", "projects/"):
        if cleaned.startswith(prefix):
            cleaned = cleaned[len(prefix):]
            break
    return os.path.realpath(os.path.abspath(os.path.join(_PROJECTS_DIR, cleaned)))


_BINARY_HANDLERS_DOC = """
Диспетчер форматов: read_file понимает не только текст.
  .pdf  → текст через pypdf (pip install pypdf)
  .docx → текст из word/document.xml (zip+regex, без зависимостей)
  .xlsx → первые строки листов через openpyxl (pip install openpyxl)
  картинки → метаданные + подсказка analyze_image
  архивы   → подсказка extract_archive
  прочий бинарь → сигнатура и размер
"""


def _read_pdf(path: str) -> str:
    try:
        from pypdf import PdfReader
    except ImportError:
        return ("[ERROR] Для чтения PDF нужен pypdf: pip install pypdf "
                "(добавлен в requirements.txt — перезапусти start.bat)")
    try:
        reader = PdfReader(path)
        pages = len(reader.pages)
        chunks = []
        total = 0
        for i, page in enumerate(reader.pages[:30]):
            txt = (page.extract_text() or "").strip()
            if txt:
                chunks.append(f"--- стр. {i+1} ---\n{txt}")
                total += len(txt)
            if total > 8000:
                chunks.append(f"… [обрезано, всего {pages} страниц]")
                break
        body = "\n\n".join(chunks) if chunks else "(текстовый слой пуст — возможно скан; используй analyze_image на скриншоте страницы)"
        return f"[OK] PDF {os.path.basename(path)} ({pages} стр.):\n{body[:9000]}"
    except Exception as e:
        return f"[ERROR] PDF не читается: {e}"


def _read_docx(path: str) -> str:
    """DOCX = zip с XML. Текст из <w:t> — без зависимостей."""
    import re as _re
    import zipfile as _zip
    try:
        with _zip.ZipFile(path) as z:
            xml = z.read("word/document.xml").decode("utf-8", errors="replace")
        # Параграфы → переносы, текстовые runs → конкатенация
        xml = _re.sub(r"</w:p>", "\n", xml)
        texts = _re.findall(r"<w:t[^>]*>(.*?)</w:t>", xml, _re.DOTALL)
        body = "".join(texts)
        body = (body.replace("&amp;", "&").replace("&lt;", "<")
                    .replace("&gt;", ">").replace("&quot;", '"'))
        body = _re.sub(r"\n{3,}", "\n\n", body).strip()
        if not body:
            return f"[OK] DOCX {os.path.basename(path)}: документ пуст"
        suffix = f"\n… [обрезано, всего {len(body)} символов]" if len(body) > 8000 else ""
        return f"[OK] DOCX {os.path.basename(path)} ({len(body)} символов):\n{body[:8000]}{suffix}"
    except KeyError:
        return f"[ERROR] Не DOCX (нет word/document.xml): {path}"
    except Exception as e:
        return f"[ERROR] DOCX не читается: {e}"


def _read_xlsx(path: str) -> str:
    try:
        import openpyxl
    except ImportError:
        return ("[ERROR] Для чтения XLSX нужен openpyxl: pip install openpyxl "
                "(добавлен в requirements.txt — перезапусти start.bat)")
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        out = []
        for sheet in wb.worksheets[:3]:
            out.append(f"=== Лист: {sheet.title} ({sheet.max_row}x{sheet.max_column}) ===")
            for row in sheet.iter_rows(min_row=1, max_row=min(sheet.max_row or 1, 40),
                                       values_only=True):
                cells = ["" if c is None else str(c)[:40] for c in row[:15]]
                out.append(" | ".join(cells))
            if (sheet.max_row or 0) > 40:
                out.append(f"… [ещё {sheet.max_row - 40} строк]")
        wb.close()
        body = "\n".join(out)
        return f"[OK] XLSX {os.path.basename(path)}:\n{body[:8000]}"
    except Exception as e:
        return f"[ERROR] XLSX не читается: {e}"


_IMG_EXTS = (".jpg", ".jpeg", ".png", ".webp", ".gif", ".bmp")
_ARCHIVE_EXTS = (".zip", ".tar", ".gz", ".tgz", ".bz2", ".xz", ".rar", ".7z")


def _read_binary_dispatch(real_path: str) -> str | None:
    """Не-UTF8 форматы. None = текстовый файл, читать как обычно."""
    low = real_path.lower()
    if low.endswith(".pdf"):
        return _read_pdf(real_path)
    if low.endswith(".docx"):
        return _read_docx(real_path)
    if low.endswith(".xlsx"):
        return _read_xlsx(real_path)
    if low.endswith(_IMG_EXTS):
        size = os.path.getsize(real_path)
        return (f"[OK] Изображение {os.path.basename(real_path)} ({size // 1024}KB).\n"
                f"Для анализа содержимого: analyze_image({{path: \"{os.path.basename(real_path)}\", "
                f"question: \"что смотреть\"}})")
    if low.endswith(_ARCHIVE_EXTS):
        return (f"[OK] Архив {os.path.basename(real_path)} "
                f"({os.path.getsize(real_path) // 1024}KB).\n"
                f"Для распаковки: extract_archive({{path: \"{os.path.basename(real_path)}\"}})")
    return None


@tool
class ReadFileTool(BaseTool):
    name = "read_file"
    description = (
        "Прочитать файл. params: path. Понимает: текст/код, PDF, DOCX, XLSX. "
        "Картинки → направит в analyze_image, архивы → в extract_archive."
    )
    params_schema = ReadFileParams
    dangerous = False

    async def execute(self, params: ReadFileParams) -> str:
        real_path = _resolve_read_path(params.path)
        try:
            if os.path.commonpath([real_path, _HOME]) != _HOME:
                return f"[BLOCKED] Путь вне домашней директории: {params.path}"
        except ValueError:
            return f"[BLOCKED] Недопустимый путь: {params.path}"

        try:
            # Бинарные форматы — через диспетчер (PDF/DOCX/XLSX/картинки/архивы)
            _bin = _read_binary_dispatch(real_path) if os.path.isfile(real_path) else None
            if _bin is not None:
                from app.core.active_project import mark_file_read
                mark_file_read(real_path)
                return _bin
            with open(real_path, encoding="utf-8") as f:
                content = f.read()
            # Отмечаем прочтение — открывает право на str_replace этого файла
            from app.core.active_project import mark_file_read
            mark_file_read(real_path)
            size = len(content)
            # До 12000 — целиком. Прежний порог 6000 резал типовые game-файлы
            # (renderer.py был 7196 симв.) ровно по середине: строка из traceback
            # попадала в выкинутый кусок, и Кодер чинил вслепую → ломал рабочий
            # код. Больше порога — широкое окно начало+конец; середина помечена.
            if size <= 12000:
                return f"[OK] {real_path} ({size} символов):\n{content}"
            head, tail = content[:7000], content[-3000:]
            return (f"[OK] {real_path} ({size} символов, показаны начало и конец):\n"
                    f"{head}\n\n... [пропущено {size - 10000} символов из середины — "
                    f"если нужная строка тут, читай файл повторно с указанием её номера] ...\n\n{tail}")
        except FileNotFoundError:
            return f"[ERROR] Файл не найден: {real_path}"
        except PermissionError:
            return f"[ERROR] Нет доступа: {real_path}"
        except UnicodeDecodeError:
            # Неизвестный бинарь: сигнатура + размер вместо голой ошибки
            try:
                with open(real_path, "rb") as bf:
                    head = bf.read(32)
                size = os.path.getsize(real_path)
                return (f"[OK] Бинарный файл {os.path.basename(real_path)} "
                        f"({size // 1024}KB). Сигнатура: {head.hex(' ')[:60]}\n"
                        f"Текстом не читается. Если это архив/картинка/документ — "
                        f"проверь расширение.")
            except Exception:
                return f"[ERROR] Не UTF-8: {real_path}"
        except Exception as e:
            return f"[ERROR] {e}"
