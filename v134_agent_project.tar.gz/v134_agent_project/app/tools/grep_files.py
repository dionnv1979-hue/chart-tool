"""
Инструмент grep_files — поиск по проекту (аналог Grep/Glob из Claude Code).

Два режима в одном инструменте (определяется автоматически):
  - pattern содержит * или ? без пробелов → поиск ФАЙЛОВ по маске имени
    ("*.py", "test_*", "board*")
  - иначе → поиск СТРОКИ в содержимом файлов (plain substring,
    регистронезависимо; НЕ regex — модели путаются в экранировании)

Вывод: file:line: строка (до 50 совпадений). Решает "где используется
класс Board" за один вызов вместо чтения файлов по одному.

Лимиты: 300 файлов, 500KB/файл, только текстовые расширения.
"""
import fnmatch
import os

from pydantic import BaseModel, Field

from app.core.config import settings
from app.core.logger import get_logger
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)

_TEXT_EXTS = (
    ".py", ".js", ".ts", ".jsx", ".tsx", ".json", ".md", ".txt", ".yaml",
    ".yml", ".toml", ".ini", ".cfg", ".html", ".css", ".sql", ".sh", ".bat",
    ".go", ".rs", ".rb", ".php", ".java", ".c", ".cpp", ".h", ".csv", ".xml",
    ".env", ".log",
)
_MAX_FILES = 300
_MAX_FILE_BYTES = 500 * 1024
_MAX_MATCHES = 50
_SKIP_DIRS = {"__pycache__", ".git", "node_modules", ".venv", "venv",
              "_extracted", ".staging"}


def _project_root(sub: str) -> str | None:
    """Корень поиска: Projects/<sub> или весь Projects/. None = вне дома."""
    base = os.path.realpath(settings.projects_dir)
    if not sub:
        # Дефолт: активный проект, иначе вся Projects/
        from app.core.active_project import get_active_project
        active = get_active_project()
        target = os.path.join(base, active) if active else base
    else:
        cleaned = sub.replace("\\", "/").lstrip("./")
        for prefix in ("Projects/", "projects/"):
            if cleaned.startswith(prefix):
                cleaned = cleaned[len(prefix):]
                break
        target = os.path.join(base, cleaned)
    real = os.path.realpath(target)
    try:
        if os.path.commonpath([real, base]) != base and real != base:
            return None
    except ValueError:
        return None
    return real if os.path.isdir(real) else (base if os.path.isdir(base) else None)


class GrepFilesParams(BaseModel):
    """Параметры инструмента grep_files."""
    pattern: str = Field(..., min_length=1, max_length=200,
                         description="Текст для поиска в содержимом, ИЛИ маска "
                                     "имени файла (*.py, test_*)")
    path: str = Field(default="",
                      description="Папка поиска внутри Projects/ "
                                  "(пусто = активный проект или вся Projects/)")


@tool
class GrepFilesTool(BaseTool):
    name = "grep_files"
    description = (
        "Поиск по проекту. params: pattern, path (опц).\n"
        "pattern с * или ? → поиск файлов по маске имени (например '*.py').\n"
        "Иначе → поиск текста в содержимом файлов (регистронезависимо, "
        "НЕ regex). Вывод: файл:строка: содержимое. "
        "Используй чтобы найти где определён/используется класс или функция."
    )
    params_schema = GrepFilesParams
    dangerous = False

    async def execute(self, params: GrepFilesParams) -> str:
        root = _project_root(params.path)
        if root is None:
            return f"[BLOCKED] Путь вне Projects/: {params.path}"

        pattern = params.pattern.strip()
        name_mode = ("*" in pattern or "?" in pattern) and " " not in pattern

        matches: list[str] = []
        files_seen = 0
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = sorted(d for d in dirnames if d not in _SKIP_DIRS)
            for fn in sorted(filenames):
                if files_seen >= _MAX_FILES or len(matches) >= _MAX_MATCHES:
                    break
                fpath = os.path.join(dirpath, fn)
                rel = os.path.relpath(fpath, root)

                if name_mode:
                    if fnmatch.fnmatch(fn.lower(), pattern.lower()):
                        size = os.path.getsize(fpath)
                        matches.append(f"{rel} ({size // 1024}KB)" if size >= 1024
                                       else f"{rel} ({size}B)")
                    continue

                # Режим содержимого: только текстовые, с лимитом размера
                if not fn.lower().endswith(_TEXT_EXTS):
                    continue
                try:
                    if os.path.getsize(fpath) > _MAX_FILE_BYTES:
                        continue
                    files_seen += 1
                    with open(fpath, encoding="utf-8", errors="ignore") as f:
                        for i, line in enumerate(f, 1):
                            if pattern.lower() in line.lower():
                                snippet = line.strip()[:120]
                                matches.append(f"{rel}:{i}: {snippet}")
                                if len(matches) >= _MAX_MATCHES:
                                    break
                except OSError:
                    continue
            if files_seen >= _MAX_FILES or len(matches) >= _MAX_MATCHES:
                break

        mode_label = "файлы по маске" if name_mode else "вхождения в содержимом"
        if not matches:
            return (f"[OK] Ничего не найдено ({mode_label}: '{pattern}') "
                    f"в {os.path.basename(root) or 'Projects'}/")
        more = f"\n… (лимит {_MAX_MATCHES}, уточни запрос)" if len(matches) >= _MAX_MATCHES else ""
        logger.info(f"grep_files: '{pattern}' → {len(matches)} matches")
        return (f"[OK] Найдено {len(matches)} ({mode_label}: '{pattern}'):\n"
                + "\n".join(matches) + more)
