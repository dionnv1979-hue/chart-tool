"""
Инструмент run_code — универсальный запуск кода на любом языке.

Автоматически определяет runtime для языка.
Если runtime не установлен — сообщает как установить.

Поддерживаемые языки:
    python, javascript (node), typescript, bash, powershell,
    php, ruby, go, rust, c, cpp, java, sql
"""
import asyncio
import os
import shutil
import subprocess
import sys
import tempfile
from typing import Optional

from app.core.config import settings
from app.core.logger import get_logger
from app.schemas.tool import RunCodeParams
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)


# ── Runtime конфигурация ──────────────────────────────────────────────────────
# Для каждого языка: расширение файла, команда запуска, как установить
_RUNTIMES: dict[str, dict] = {
    "python": {
        "ext": ".py",
        "cmd": [sys.executable, "{file}"],
        "install": "уже установлен",
    },
    "javascript": {
        "ext": ".js",
        "cmd": ["node", "{file}"],
        "bin": "node",
        "install": "https://nodejs.org  или: winget install OpenJS.NodeJS",
    },
    "typescript": {
        "ext": ".ts",
        "cmd": ["npx", "--yes", "ts-node", "{file}"],
        "bin": "npx",
        "install": "npm install -g ts-node typescript",
    },
    "bash": {
        "ext": ".sh",
        "cmd": ["bash", "{file}"],
        "bin": "bash",
        "install": "Git Bash или WSL",
    },
    "powershell": {
        "ext": ".ps1",
        "cmd": ["pwsh", "-File", "{file}"],
        "bin": "pwsh",
        "install": "https://github.com/PowerShell/PowerShell",
    },
    "php": {
        "ext": ".php",
        "cmd": ["php", "{file}"],
        "bin": "php",
        "install": "https://www.php.net/downloads  или: winget install PHP.PHP",
    },
    "ruby": {
        "ext": ".rb",
        "cmd": ["ruby", "{file}"],
        "bin": "ruby",
        "install": "https://rubyinstaller.org (Windows)",
    },
    "go": {
        "ext": ".go",
        "cmd": ["go", "run", "{file}"],
        "bin": "go",
        "install": "https://go.dev/dl/  или: winget install GoLang.Go",
    },
    "rust": {
        "ext": ".rs",
        "cmd": None,  # требует компиляции
        "bin": "rustc",
        "compile": ["rustc", "{file}", "-o", "{out}"],
        "run": ["{out}"],
        "install": "https://rustup.rs",
    },
    "c": {
        "ext": ".c",
        "cmd": None,
        "bin": "gcc",
        "compile": ["gcc", "{file}", "-o", "{out}"],
        "run": ["{out}"],
        "install": "winget install GnuWin32.Gcc  или MinGW",
    },
    "cpp": {
        "ext": ".cpp",
        "cmd": None,
        "bin": "g++",
        "compile": ["g++", "{file}", "-o", "{out}"],
        "run": ["{out}"],
        "install": "winget install GnuWin32.Gcc  или MinGW",
    },
    "java": {
        "ext": ".java",
        "cmd": None,
        "bin": "javac",
        "compile": ["javac", "{file}"],
        "run": ["java", "-cp", "{dir}", "{classname}"],
        "install": "https://adoptium.net  или: winget install EclipseAdoptium.Temurin.21.JDK",
    },
    "sql": {
        "ext": ".sql",
        "cmd": ["sqlite3", ":memory:", ".read {file}"],
        "bin": "sqlite3",
        "install": "https://sqlite.org/download.html  или: winget install SQLite.SQLite",
    },
}

# Псевдонимы языков
_ALIASES = {
    "js": "javascript",
    "ts": "typescript",
    "node": "javascript",
    "sh": "bash",
    "shell": "bash",
    "ps1": "powershell",
    "ps": "powershell",
    "c++": "cpp",
    "golang": "go",
    "rb": "ruby",
}


def _normalize_lang(lang: str) -> str:
    return _ALIASES.get(lang.lower().strip(), lang.lower().strip())


def _find_bin(name: str) -> Optional[str]:
    return shutil.which(name)


@tool
class RunCodeTool(BaseTool):
    name = "run_code"
    description = (
        "Запустить код на любом языке программирования. "
        "params: language (python/javascript/typescript/bash/go/rust/c/cpp/java/php/ruby/sql), "
        "code (исходный код). "
        "Автоматически определяет нужный runtime. "
        "Если язык не установлен — покажет как установить."
    )
    params_schema = RunCodeParams
    dangerous = False

    async def execute(self, params: RunCodeParams) -> str:
        lang = _normalize_lang(params.language)
        code = params.code
        timeout = min(params.timeout or 30, 120)

        if lang not in _RUNTIMES:
            supported = ", ".join(sorted(_RUNTIMES.keys()))
            return f"[ERROR] Неизвестный язык: {params.language}\nПоддерживаемые: {supported}"

        cfg = _RUNTIMES[lang]

        # Проверяем наличие runtime
        bin_name = cfg.get("bin")
        if bin_name and bin_name != sys.executable:
            if not _find_bin(bin_name):
                install_hint = cfg.get("install", "нет информации")
                return (
                    f"[NOT INSTALLED] {lang} runtime не найден ({bin_name}).\n"
                    f"Установка: {install_hint}\n\n"
                    f"После установки перезапусти сервер и попробуй снова."
                )

        # Создаём временный файл с кодом
        ext = cfg["ext"]
        with tempfile.NamedTemporaryFile(
            suffix=ext, delete=False, mode="w", encoding="utf-8"
        ) as f:
            f.write(code)
            tmp_file = f.name

        try:
            return await self._run_lang(lang, cfg, tmp_file, timeout)
        finally:
            # Убираем временные файлы
            try:
                os.unlink(tmp_file)
            except Exception:
                pass

    async def _run_lang(self, lang: str, cfg: dict, tmp_file: str, timeout: int) -> str:
        """Запускает код в зависимости от типа языка."""
        loop = asyncio.get_running_loop()
        base = os.path.splitext(tmp_file)[0]
        out_bin = base + (".exe" if sys.platform == "win32" else "")

        if cfg.get("cmd"):
            # Интерпретируемый язык — прямой запуск
            cmd = [
                c.replace("{file}", tmp_file).replace("{dir}", os.path.dirname(tmp_file))
                for c in cfg["cmd"]
            ]
            return await self._exec(cmd, timeout, loop)

        elif "compile" in cfg:
            # Компилируемый язык
            # 1. Компиляция
            compile_cmd = [
                c.replace("{file}", tmp_file)
                 .replace("{out}", out_bin)
                 .replace("{dir}", os.path.dirname(tmp_file))
                for c in cfg["compile"]
            ]

            compile_result = await self._exec(compile_cmd, 60, loop, capture_stderr=True)
            if "[ERROR]" in compile_result or "[TIMEOUT]" in compile_result:
                return f"[COMPILE ERROR]\n{compile_result}"

            # 2. Запуск
            if lang == "java":
                # Java: определяем имя класса из кода
                classname = self._extract_java_class(
                    open(tmp_file).read()
                ) or "Main"
                run_cmd = [
                    c.replace("{dir}", os.path.dirname(tmp_file))
                     .replace("{classname}", classname)
                    for c in cfg["run"]
                ]
            else:
                run_cmd = [
                    c.replace("{out}", out_bin)
                    for c in cfg["run"]
                ]

            run_result = await self._exec(run_cmd, timeout, loop)

            # Убираем скомпилированный файл
            try:
                os.unlink(out_bin)
            except Exception:
                pass

            return f"[COMPILE OK]\n{run_result}"

        return "[ERROR] Неизвестный тип запуска для этого языка"

    async def _exec(
        self, cmd: list[str], timeout: int, loop, capture_stderr: bool = False
    ) -> str:
        try:
            result = await loop.run_in_executor(
                None,
                lambda: subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                    encoding="utf-8",
                    errors="replace",
                )
            )
            stdout = (result.stdout or "")[:2000]
            stderr = (result.stderr or "")[:500]

            if result.returncode == 0:
                return f"[OK]\n{stdout}" if stdout else "[OK] (нет вывода)"
            else:
                parts = [f"[ERROR] rc={result.returncode}"]
                if stdout:
                    parts.append(stdout)
                if stderr:
                    parts.append(f"[stderr]:\n{stderr}")
                return "\n".join(parts)
        except subprocess.TimeoutExpired:
            return f"[TIMEOUT] Выполнение дольше {timeout}с"
        except Exception as e:
            return f"[ERROR] {e}"

    @staticmethod
    def _extract_java_class(code: str) -> Optional[str]:
        import re
        m = re.search(r"public\s+class\s+(\w+)", code)
        return m.group(1) if m else None
