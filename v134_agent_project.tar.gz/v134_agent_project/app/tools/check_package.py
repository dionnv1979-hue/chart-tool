"""
Инструмент check_package — проверяет установлен ли Python пакет.
Безопасный инструмент (не dangerous), не требует подтверждения.
"""
import importlib.util
import subprocess
import sys

from app.core.logger import get_logger
from app.schemas.tool import CheckPackageParams
from app.tools.base import BaseTool, tool

logger = get_logger(__name__)


@tool
class CheckPackageTool(BaseTool):
    name = "check_package"
    description = (
        "Проверить установлен ли Python пакет. "
        "params: package (имя пакета). "
        "Пример: {\"package\": \"requests\"}. "
        "Возвращает версию если установлен, или сообщение что нужно установить."
    )
    params_schema = CheckPackageParams
    dangerous = False

    async def execute(self, params: CheckPackageParams) -> str:
        pkg = params.package.strip().split("==")[0].split(">=")[0]
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "show", pkg],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                lines = result.stdout.strip().split("\n")
                info = {l.split(": ")[0]: l.split(": ", 1)[1]
                        for l in lines if ": " in l}
                version = info.get("Version", "?")
                location = info.get("Location", "")
                logger.info(f"check_package: {pkg} v{version} installed")
                return f"[OK] {pkg} v{version} установлен → {location}"
            else:
                logger.info(f"check_package: {pkg} not installed")
                return (
                    f"[NOT INSTALLED] {pkg} не установлен. "
                    f"Для установки вызови: pip_install({{\"packages\": [\"{pkg}\"]}})"
                )
        except Exception as e:
            return f"[ERROR] {e}"
