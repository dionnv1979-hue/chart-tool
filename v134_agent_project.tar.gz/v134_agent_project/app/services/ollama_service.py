"""
Сервис для работы с Ollama API.
Инкапсулирует все HTTP запросы к Ollama.
Поддерживает обычную генерацию и стриминг.
"""
import json
from dataclasses import dataclass
from typing import AsyncGenerator, Optional

import httpx

from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)


class OllamaService:
    """
    Асинхронный клиент для Ollama API.
    Dependency injection: создаётся один раз и инжектится в сервисы.
    """

    def __init__(self) -> None:
        self._base_url = settings.ollama_base_url
        self._current_model = settings.default_model
        # Переиспользуем клиент для connection pooling.
        # Гранулярный таймаут: быстрый connect, общий потолок на чтение.
        # Простой модели (idle) ловим отдельно — стримингом в generate().
        self._client = httpx.AsyncClient(
            timeout=httpx.Timeout(
                connect=15.0,
                read=float(settings.ollama_timeout),
                write=30.0,
                pool=15.0,
            ),
            limits=httpx.Limits(max_connections=10, max_keepalive_connections=5),
        )

    @property
    def current_model(self) -> str:
        return self._current_model

    @current_model.setter
    def current_model(self, model: str) -> None:
        if model == self._current_model:
            return  # no-op — модель уже выбрана
        logger.info(f"Model switched: {self._current_model} → {model}")
        self._current_model = model

    def _generation_options(self) -> dict:
        """Общие параметры генерации для всех запросов."""
        return {
            "num_ctx": settings.num_ctx,
            "num_gpu": settings.num_gpu,
            "num_thread": settings.num_thread,
            "num_predict": settings.num_predict,  # лимит длины ответа (анти-зацикливание)
            "temperature": settings.temperature,
        }

    # ── Vision модели (поддерживают изображения) ─────────────────────────────
    # Модели которые НЕ поддерживают Ollama native JSON format (format= параметр)
    # Для них generate_structured() сразу возвращает None → regex fallback
    _NO_STRUCTURED_OUTPUT = {
        "qwen3",           # qwen3:30b, qwen3:8b и т.д.
        "qwen3-coder",     # qwen3-coder:30b
        "qwen2.5-coder",   # qwen2.5-coder:14b
        "llama3",          # llama3.x серия
        "mistral",         # mistral серия
        "gemma",           # gemma серия
        # Поддерживают structured: llava, qwen2-vl, некоторые специальные модели
    }

    _VISION_MODELS = {
        "llava", "llava-phi3", "llava-llama3", "llava-mistral",
        "moondream", "bakllava", "qwen2-vl", "qwen2.5-vl",
        "minicpm-v", "llama3.2-vision", "granite3.2-vision",
        "mistral-small3.1",
        # gemma3 убран — только gemma3:12b поддерживает vision, но не все варианты
    }

    def supports_vision(self, model: Optional[str] = None) -> bool:
        """Определяет поддерживает ли модель изображения."""
        m = (model or self._current_model).lower()
        return any(v in m for v in self._VISION_MODELS)

    async def generate(
        self,
        prompt: str,
        model: Optional[str] = None,
        images: Optional[list[str]] = None,
        temperature: Optional[float] = None,
        num_predict: Optional[int] = None,
    ) -> str:
        """
        Синхронная (не-стриминговая) генерация.
        images: list[str] — base64-encoded изображения (без data: prefix).
        num_predict: переопределение лимита токенов ответа (None = глобальный).
        Если модель не поддерживает vision — возвращает понятное сообщение.
        """
        target_model = model or self._current_model

        # Проверяем vision поддержку если переданы изображения
        if images:
            if not self.supports_vision(target_model):
                return (
                    f"⚠️ Модель `{target_model}` не поддерживает изображения.\n\n"
                    f"Для работы с фото/видео установи vision модель:\n"
                    f"```\nollama pull llava:7b\n```\n"
                    f"или\n"
                    f"```\nollama pull qwen2-vl:7b\n```\n"
                    f"Затем выбери её в выпадающем меню МОДЕЛЬ."
                )

        opts = self._generation_options()
        if temperature is not None:
            opts["temperature"] = temperature
        if num_predict is not None and num_predict > 0:
            opts["num_predict"] = num_predict
        payload = {
            "model": target_model,
            "prompt": prompt,
            "stream": True,  # стримим ВНУТРИ — чтобы ловить зависание по простою
            "options": opts,
        }
        if images:
            payload["images"] = images
        # Retry при 503 (Ollama занята/грузит модель) и пустом ответе — 3 попытки
        import asyncio as _aio
        for _attempt in range(3):
            try:
                logger.debug(f"Ollama generate: model={target_model} prompt_len={len(prompt)}")
                result, err = await self._stream_collect(payload, target_model)
                if err == "503" and _attempt < 2:
                    wait = 15 * (_attempt + 1)
                    logger.warning(f"Ollama 503 (attempt {_attempt+1}/3), retry in {wait}s")
                    await _aio.sleep(wait)
                    continue
                if err:
                    return err  # уже отформатированное сообщение об ошибке
                # Пустой ответ — модель иногда «немеет» при высокой загрузке.
                # Backoff 1s / 2s / 4s даёт ей время освободить VRAM.
                if not result and _attempt < 2:
                    wait = 2 ** _attempt  # 1, 2 секунды
                    logger.warning(
                        f"Ollama пустой ответ (attempt {_attempt+1}/3), "
                        f"retry in {wait}s (model={target_model})"
                    )
                    await _aio.sleep(wait)
                    continue
                logger.debug(f"Ollama response: len={len(result)}")
                return result
            except httpx.TimeoutException:
                logger.error(f"Ollama timeout after {settings.ollama_timeout}s")
                return "[TIMEOUT] Ollama не ответил вовремя"
            except Exception as e:
                logger.error(f"Ollama unexpected error: {e}")
                return f"❌ {e}"
        return "[API ERROR 503] Ollama недоступна (3 попытки исчерпаны)"

    async def _stream_collect(self, payload: dict, target_model: str) -> tuple[str, str]:
        """
        Собрать полный ответ из стрима, прерывая по простою (idle).
        Живая модель шлёт токены непрерывно; зависшая — молчит.
        Если за ollama_idle_timeout не пришло ни одного токена — прерываем.

        Returns:
            (текст, ошибка). Если ошибка непустая — текст игнорируется.
            ошибка == "503" — особый код для retry, иначе готовое сообщение.
        """
        import asyncio as _aio
        import json as _json

        idle = float(settings.ollama_idle_timeout)
        chunks: list[str] = []
        try:
            async with self._client.stream(
                "POST", f"{self._base_url}/api/generate", json=payload
            ) as resp:
                if resp.status_code == 503:
                    return "", "503"
                if resp.status_code >= 400:
                    body = (await resp.aread())[:200].decode("utf-8", "replace")
                    logger.error(f"Ollama HTTP error: {resp.status_code} {body}")
                    return "", f"[API ERROR {resp.status_code}]"

                line_iter = resp.aiter_lines()
                while True:
                    try:
                        # Ждём следующую строку не дольше idle — иначе модель зависла
                        line = await _aio.wait_for(line_iter.__anext__(), timeout=idle)
                    except StopAsyncIteration:
                        break
                    except (_aio.TimeoutError, TimeoutError):
                        logger.error(
                            f"Ollama idle timeout: нет токенов {idle}s "
                            f"(модель {target_model} зависла)"
                        )
                        if chunks:
                            # Что-то успели получить — возвращаем частичный ответ
                            return "".join(chunks), ""
                        return "", "[TIMEOUT] Ollama зависла (нет ответа)"
                    if not line:
                        continue
                    try:
                        obj = _json.loads(line)
                    except _json.JSONDecodeError:
                        continue
                    token = obj.get("response", "")
                    if token:
                        chunks.append(token)
                    if obj.get("done"):
                        break
        except httpx.TimeoutException:
            raise  # обработается уровнем выше
        text = "".join(chunks)
        # ── Детекция обрыва по num_predict ──────────────────────────────────
        # Если модель оборвала ответ посередине кода (незакрытый def/class/скобка),
        # логируем предупреждение. base.py добавит подсказку в следующий промпт.
        # Берём ФАКТИЧЕСКИЙ лимит из payload (агент мог переопределить).
        _np = (payload.get("options") or {}).get("num_predict", settings.num_predict)
        if text and len(text) >= _np * 3:  # ~3 символа/токен
            stripped = text.rstrip()
            _truncated = (
                stripped.endswith(("def ", "class ", "async def ", "    "))
                or stripped.count("(") > stripped.count(")")
                or stripped.count("{") > stripped.count("}")
                or (stripped.count('"""') % 2 == 1)
                or (stripped.count("'''") % 2 == 1)
            )
            if _truncated:
                logger.warning(
                    f"⚠️ Ответ модели обрезан по num_predict={_np} "
                    f"(len={len(text)}, модель={target_model}). "
                    f"Код может быть неполным — рассмотри увеличение num_predict."
                )
                # Добавляем маркер чтобы base.py мог выдать подсказку кодеру
                text = text + "\n# [TRUNCATED_BY_NUM_PREDICT]"
        return text, ""

    async def generate_stream(
        self, prompt: str, model: Optional[str] = None
    ) -> AsyncGenerator[str, None]:
        """
        Стриминговая генерация.
        Возвращает async generator токенов.
        """
        target_model = model or self._current_model
        payload = {
            "model": target_model,
            "prompt": prompt,
            "stream": True,
            "options": self._generation_options(),
        }
        try:
            async with self._client.stream(
                "POST",
                f"{self._base_url}/api/generate",
                json=payload,
            ) as response:
                response.raise_for_status()
                async for line in response.aiter_lines():
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        token = data.get("response", "")
                        if token:
                            yield token
                        if data.get("done", False):
                            break
                    except json.JSONDecodeError:
                        continue
        except httpx.HTTPStatusError as e:
            yield f"[API ERROR {e.response.status_code}]"
        except httpx.TimeoutException:
            yield "[TIMEOUT]"
        except Exception as e:
            yield f"❌ {e}"

    async def list_models(self) -> list[dict]:
        """
        Получить список установленных моделей из Ollama.
        Возвращает список dict с ключами name, size, modified.
        """
        try:
            response = await self._client.get(
                f"{self._base_url}/api/tags",
                timeout=10,
            )
            response.raise_for_status()
            data = response.json()
            models = []
            for m in data.get("models", []):
                models.append({
                    "name": m.get("name", ""),
                    "size": m.get("size", 0),
                    "modified": m.get("modified_at", ""),
                })
            logger.debug(f"Ollama models: {[m['name'] for m in models]}")
            return models
        except Exception as e:
            logger.error(f"Failed to list Ollama models: {e}")
            return []

    async def is_model_available(self, model_name: str) -> bool:
        """Проверить установлена ли модель в Ollama."""
        models = await self.list_models()
        return any(m["name"] == model_name for m in models)

    async def detect_and_set_model(self) -> bool:
        """
        Автоопределение модели при старте:
        1. Если текущая модель установлена — оставляем.
        2. Иначе берём первую установленную.
        3. Иначе оставляем дефолтную.
        Возвращает True если Ollama доступен.
        """
        models = await self.list_models()
        if not models:
            logger.warning("Ollama недоступен или нет установленных моделей")
            return False

        installed_names = [m["name"] for m in models]

        if self._current_model in installed_names:
            logger.info(f"Current model is available: {self._current_model}")
            return True

        old_model = self._current_model
        self._current_model = installed_names[0]
        logger.warning(
            f"Model '{old_model}' not installed → switched to '{self._current_model}'. "
            f"Available: {', '.join(installed_names)}"
        )
        return True

    def _supports_structured_output(self, model: str) -> bool:
        """Проверяет поддерживает ли модель Ollama native JSON format."""
        model_lower = model.lower()
        for prefix in self._NO_STRUCTURED_OUTPUT:
            if model_lower.startswith(prefix):
                return False
        return True

    async def generate_structured(
        self,
        prompt: str,
        json_schema: dict,
        model: Optional[str] = None,
    ) -> dict | None:
        """
        Генерация с принудительным JSON output через Ollama format.
        Возвращает dict или None при ошибке или если модель не поддерживает.
        Используется для structured tool calling.
        """
        target_model = model or self._current_model

        # Быстрый выход если модель не поддерживает structured output
        if not self._supports_structured_output(target_model):
            return None

        payload = {
            "model": target_model,
            "prompt": prompt,
            "stream": False,
            "format": json_schema,
            "options": self._generation_options(),
        }
        try:
            r = await self._client.post(
                f"{self._base_url}/api/generate", json=payload
            )
            r.raise_for_status()
            data = r.json()
            text = data.get("response", "")
            return json.loads(text)
        except json.JSONDecodeError as e:
            logger.warning(f"Structured output JSON parse error: {e}")
            return None
        except Exception as e:
            logger.error(f"Structured output error: {e}")
            return None

    # ── JSON schema для tool calling ─────────────────────────────────────────
    # Ollama format schema: заставляет модель вернуть строго этот формат
    TOOL_CALL_SCHEMA = {
        "type": "object",
        "properties": {
            "thought": {
                "type": "string",
                "description": "Краткая мысль: что я сейчас сделаю и зачем (1-2 предложения)"
            },
            "type": {
                "type": "string",
                "enum": ["tool_call", "final_answer"]
            },
            "tool": {
                "type": "string",
                "description": "Имя инструмента (только если type=tool_call)"
            },
            "params": {
                "type": "object",
                "description": "Параметры инструмента (только если type=tool_call)"
            },
            "answer": {
                "type": "string",
                "description": "Финальный ответ пользователю (только если type=final_answer)"
            }
        },
        "required": ["type", "thought"]
    }

    async def close(self) -> None:
        """Закрыть HTTP клиент."""
        await self._client.aclose()


# Синглтон сервиса — будет создан в lifespan и инжектирован
_ollama_service: OllamaService | None = None


def get_ollama_service() -> OllamaService:
    """FastAPI dependency — возвращает синглтон OllamaService."""
    global _ollama_service
    if _ollama_service is None:
        _ollama_service = OllamaService()
    return _ollama_service
