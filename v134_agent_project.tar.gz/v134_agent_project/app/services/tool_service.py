"""
ToolService — единственная точка выполнения инструментов.
Использует MiddlewareChain: Metrics → Approval → Retry → execute().
Никаких if-цепочек. Никакой бизнес-логики здесь.
"""
import json

from pydantic import ValidationError

from app.core.logger import get_logger
from app.tools.base import ApprovalRequired, BaseTool, get_registry
from app.tools.middleware import MiddlewareChain, build_default_chain

logger = get_logger(__name__)

# Частые ошибки локальных моделей в именах полей: что модель пишет → как правильно.
# Применяется только если правильного поля нет, а ошибочное — есть. Универсально:
# работает для любого инструмента, имена полей — общие синонимы.
_PARAM_ALIASES = {
    "package": "packages",      # pip_install: модель шлёт строку вместо списка
    "file": "path",
    "filename": "path",
    "filepath": "path",
    "dir": "path",
    "directory": "path",
    "cmd": "command",
    "script": "code",
    "source": "code",
    "text": "content",
    "data": "content",
    "query": "q",
}


class ToolResult:
    def __init__(self, tool_name: str, output: str, success: bool = True) -> None:
        self.tool_name = tool_name
        self.output = output
        self.success = success

    def __str__(self) -> str:
        return self.output


class ToolService:
    """
    Сервис инструментов поверх _REGISTRY.
    chain: MiddlewareChain — Metrics → Approval → Retry → execute()
    """

    def __init__(self, chain: MiddlewareChain | None = None) -> None:
        self._chain = chain or build_default_chain()

    def register_from_registry(self) -> None:
        """Подхватить все инструменты из авто-реестра после discover_tools()."""
        names = list(get_registry().keys())
        logger.info(f"ToolService: {len(names)} tools — {names}")

    def _get_tool(self, name: str) -> BaseTool | None:
        return get_registry().get(name)

    def is_registered(self, name: str) -> bool:
        return name in get_registry()

    def is_dangerous(self, name: str) -> bool:
        t = self._get_tool(name)
        return t.dangerous if t else False

    def get_tools_description(
        self, allowed: list[str] | None = None
    ) -> str:
        """
        Описание инструментов для промпта.
        allowed=None → все инструменты (для single агента).
        allowed=[...] → только перечисленные (для специализированных агентов).
        """
        registry = get_registry()
        if allowed is not None:
            tools = [registry[n] for n in allowed if n in registry]
        else:
            tools = list(registry.values())
        return "\n".join(t.prompt_description() for t in tools)

    async def execute(
        self,
        tool_name: str,
        params: dict,
        *,
        skip_approval: bool = False,
        allowed: list[str] | None = None,
    ) -> ToolResult:
        """
        Выполнить инструмент через middleware chain.

        allowed=None → без ограничений (single агент).
        allowed=[...] → только эти инструменты (специализированный агент).

        Порядок:
            MetricsMiddleware → ApprovalMiddleware → RetryMiddleware → tool.execute()
        """
        # Проверяем права агента
        if allowed is not None and tool_name not in allowed:
            logger.warning(f"Tool '{tool_name}' not in agent's allowed_tools: {allowed}")
            return ToolResult(
                tool_name,
                f"[DENIED] Инструмент '{tool_name}' недоступен этому агенту. "
                f"Доступны: {', '.join(allowed)}",
                success=False,
            )

        tool = self._get_tool(tool_name)
        if tool is None:
            return ToolResult(tool_name, f"[ERROR] Unknown tool: {tool_name}", success=False)

        # #4: Автокоррекция частых ошибок в именах полей (package→packages и т.п.)
        params = self._autocorrect_params(tool, params)

        try:
            output = await self._chain.run(tool, params, skip_approval=skip_approval)
            return ToolResult(tool_name, output, success=True)
        except ApprovalRequired:
            raise  # Пробрасываем вверх — BaseAgent ловит
        except ValidationError as e:
            # #4: вместо сырого дампа Pydantic — понятная подсказка модели
            hint = self._build_schema_hint(tool, params, e)
            logger.warning(f"Tool {tool_name} validation failed, hint returned")
            return ToolResult(tool_name, hint, success=False)
        except Exception as e:
            logger.error(f"Tool chain error: {tool_name}: {e}", exc_info=True)
            return ToolResult(tool_name, f"[ERROR] {e}", success=False)

    def _autocorrect_params(self, tool: BaseTool, params: dict) -> dict:
        """
        Чинит частые ошибки локальных моделей в именах полей.
        Только если правильного поля НЕТ, а ошибочный синоним ЕСТЬ —
        переименовываем. Значения-строки для list-полей оборачиваем в список.
        """
        if not isinstance(params, dict):
            return params
        try:
            schema_fields = tool.params_schema.model_fields
        except Exception:
            return params

        fixed = dict(params)
        for wrong, right in _PARAM_ALIASES.items():
            if wrong in fixed and right not in fixed and right in schema_fields:
                fixed[right] = fixed.pop(wrong)
                logger.info(f"Autocorrect param: '{wrong}' → '{right}' for {tool.name}")

        # Оборачиваем строку в список ТОЛЬКО для полей с реальным list-типом
        # (packages: "pygame" → ["pygame"]). Проверяем тип через typing-интроспекцию,
        # а не по подстроке "list" в тексте аннотации — иначе Literal['add','list',...]
        # ложно считается списком (баг: action="add" → ["add"] → literal_error).
        import typing
        for fname, finfo in schema_fields.items():
            if fname in fixed and isinstance(fixed[fname], str):
                if self._is_list_field(finfo.annotation):
                    fixed[fname] = [fixed[fname]]
                    logger.info(f"Autocorrect: wrapped '{fname}' string into list for {tool.name}")
        return fixed

    @staticmethod
    def _is_list_field(annotation) -> bool:
        """
        True только если аннотация — настоящий list/List/Sequence (в т.ч. Optional[list]).
        НЕ срабатывает на Literal[...], даже если один из вариантов называется 'list'.
        """
        import typing
        origin = typing.get_origin(annotation)
        if origin in (list, tuple, set, frozenset):
            return True
        # Optional[list[...]] / Union[list[...], None] — разбираем аргументы
        if origin is typing.Union:
            return any(
                typing.get_origin(arg) in (list, tuple, set, frozenset)
                for arg in typing.get_args(annotation)
            )
        return False

    def _build_schema_hint(self, tool: BaseTool, params: dict, err: ValidationError) -> str:
        """Понятная подсказка модели: какие поля нужны и пример вызова."""
        try:
            fields = tool.params_schema.model_fields
        except Exception:
            return f"[ERROR] Неверные параметры для {tool.name}: {err}"

        required = [n for n, f in fields.items() if f.is_required()]
        optional = [n for n, f in fields.items() if not f.is_required()]

        def _type_of(name: str) -> str:
            try:
                annotation = fields[name].annotation
                if self._is_list_field(annotation):
                    return "list[...]"
                ann = str(annotation).lower()
                if "literal" in ann:
                    # Показываем допустимые значения Literal-поля
                    import typing
                    args = typing.get_args(annotation)
                    if args:
                        return "одно из: " + ", ".join(repr(a) for a in args)
                    return "строка"
                if "int" in ann:
                    return "число"
                if "bool" in ann:
                    return "true/false"
                return "строка"
            except Exception:
                return "..."

        example = {n: ("[...]" if _type_of(n) == "list[...]" else f"<{n}>") for n in required}
        lines = [
            f"[ERROR] Неверные параметры для `{tool.name}`.",
            f"Получено: {json.dumps(params, ensure_ascii=False)}",
            "",
            "Обязательные поля: "
            + (", ".join(f"{n} ({_type_of(n)})" for n in required) or "нет"),
        ]
        if optional:
            lines.append("Необязательные: " + ", ".join(optional))
        lines.append("")
        lines.append("Правильный вызов:")
        lines.append("```tool")
        lines.append(json.dumps({"tool": tool.name, "params": example}, ensure_ascii=False))
        lines.append("```")
        return "\n".join(lines)

    def parse_tool_call_from_text(
        self, text: str, allowed: list[str] | None = None
    ) -> tuple[str | None, dict | None]:
        """
        Извлечь tool call из текста LLM.

        Поддерживает форматы:
          ```tool
          {"tool": "name", "params": {...}}
          ```
          и ```json {"tool": ...} ```

        Использует json-парсер а не regex для вложенного JSON.
        allowed=None → принимаем любой зарегистрированный инструмент.
        allowed=[...] → только из списка агента.
        """
        import re

        # Ищем блоки ```tool ... ``` и ```json ... ```
        block_pattern = re.compile(r"```(?:tool|json)\s*(.+?)\s*```", re.DOTALL)

        for block_match in block_pattern.finditer(text):
            raw = block_match.group(1).strip()

            # Находим первую { и ищем парный } через json decoder
            # Это правильно обрабатывает вложенные JSON (файлы с кодом внутри params)
            start = raw.find("{")
            if start == -1:
                continue

            # Пробуем декодировать с нарастающей длиной
            decoder = json.JSONDecoder()
            try:
                data, _ = decoder.raw_decode(raw, start)
            except json.JSONDecodeError:
                # Fallback: берём только первый объект через regex (старый способ)
                m = re.search(r"\{[^{}]*\}", raw)
                if not m:
                    continue
                try:
                    data = json.loads(m.group(0))
                except json.JSONDecodeError:
                    continue

            name = data.get("tool")
            p = data.get("params", {})
            if not name:
                continue
            if not self.is_registered(name):
                continue
            if allowed is not None and name not in allowed:
                logger.warning(f"Agent tried to call '{name}' but it's not in allowed_tools")
                continue
            return name, p

        return None, None


_tool_service: ToolService | None = None


def get_tool_service() -> ToolService:
    global _tool_service
    if _tool_service is None:
        _tool_service = ToolService()
    return _tool_service
