"""
Session service — управление жизненным циклом сессий и историей.
Прослойка между API и Repository.
"""
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.constants import SESSIONS_LIST_LIMIT
from app.agents.prompts import AGENTS
from app.core.logger import get_logger
from app.memory.repository import MessageRepository, SessionRepository
from app.memory.models import Message

logger = get_logger(__name__)


class SessionService:
    """
    Управляет сессиями и сообщениями.
    Принимает db: AsyncSession через DI.
    """

    def __init__(self, db: AsyncSession) -> None:
        self._db = db
        self._msg_repo = MessageRepository(db)
        self._session_repo = SessionRepository(db)

    async def save_user_message(self, session_id: str, content: str) -> None:
        """Сохранить сообщение пользователя."""
        await self._msg_repo.save(
            session_id=session_id,
            role="user",
            agent="user",
            content=content,
        )

    async def save_assistant_message(
        self,
        session_id: str,
        agent: str,
        content: str,
    ) -> None:
        """Сохранить сообщение агента."""
        if not content:
            return
        await self._msg_repo.save(
            session_id=session_id,
            role="assistant",
            agent=agent,
            content=content,
        )

    async def get_history_for_prompt(
        self,
        session_id: str,
        limit: int | None = None,
    ) -> list[Message]:
        """
        История для подачи в промпт агента.
        Возвращает Message объекты (SQLAlchemy), не dict.
        """
        n = limit if limit is not None else settings.history_limit
        return await self._msg_repo.get_history(session_id=session_id, limit=n)

    async def get_history_for_api(
        self,
        session_id: str,
        limit: int = 50,
    ) -> list[Message]:
        """История для /history endpoint."""
        return await self._msg_repo.get_history_for_api(
            session_id=session_id,
            limit=limit,
        )

    async def clear_session(self, session_id: str) -> int:
        """Удалить все сообщения сессии. Возвращает кол-во удалённых."""
        count = await self._msg_repo.delete_session_messages(session_id)
        logger.info(f"Session cleared: {session_id} ({count} messages)")
        return count

    async def list_sessions(self, limit: int = SESSIONS_LIST_LIMIT) -> list[str]:
        """Список активных сессий."""
        return await self._session_repo.list_recent(limit=limit)

    def format_history_for_prompt(self, messages: list[Message]) -> str:
        """
        Форматирует историю в текстовый блок для промпта.

        Логика умного усечения:
        - Последние RECENT_FULL сообщений → полностью (по 600 символов)
        - Более старые → дайджест: что было написано, какие ошибки чинили
        - Общий лимит по символам — TOTAL_CHARS_LIMIT (защита от блоат)

        Это защищает агента от 50+ сообщений в контексте, которые
        замедляют Ollama и засоряют внимание модели.
        """
        if not messages:
            return ""

        RECENT_FULL = 6              # последние N — полностью
        TOTAL_CHARS_LIMIT = 8000     # общий потолок ~2k токенов

        # Разделяем на «недавние» и «старые»
        recent = messages[-RECENT_FULL:] if len(messages) > RECENT_FULL else messages
        older = messages[:-RECENT_FULL] if len(messages) > RECENT_FULL else []

        parts: list[str] = []

        # ── Умный дайджест старых сообщений ──────────────────────────────────
        # Вместо «[N сообщений обрезаны]» строим мини-сводку из реального контента:
        # запрос пользователя + что сделали агенты + какие ошибки чинили.
        if older:
            first_user = next((m for m in older if m.role == "user"), None)
            # Собираем упоминания ошибок и фиксов из ответов агентов
            error_hints: list[str] = []
            files_written: list[str] = []
            import re as _re
            for m in older:
                if m.role != "assistant":
                    continue
                txt = m.content[:300]
                # Файлы которые писали
                for fname in _re.findall(r"\b([\w\-]+\.(?:py|js|ts|go|html|css))\b", txt):
                    if fname not in files_written:
                        files_written.append(fname)
                # Ошибки которые чинили
                for etype in ("ImportError", "NameError", "ModuleNotFoundError",
                              "TypeError", "AttributeError", "SyntaxError"):
                    if etype in txt and etype not in " ".join(error_hints):
                        # Берём строку с ошибкой как подсказку
                        for line in txt.splitlines():
                            if etype in line:
                                error_hints.append(line.strip()[:80])
                                break

            digest_parts = [f"[Дайджест: {len(older)} старых сообщений]"]
            if first_user:
                digest_parts.append(f"Исходный запрос: {first_user.content[:120]}")
            if files_written:
                digest_parts.append(f"Писали файлы: {', '.join(files_written[:8])}")
            if error_hints:
                digest_parts.append(f"Чинили ошибки: {' | '.join(error_hints[:3])}")
            parts.append("\n".join(digest_parts))

        # Полные последние сообщения
        for msg in recent:
            if msg.role == "user":
                label = "Пользователь"
            else:
                agent_def = AGENTS.get(msg.agent, {})
                label = f"[{agent_def.get('name', msg.agent)}]"
            parts.append(f"{label}: {msg.content[:600]}")

        text = "\n\n".join(parts)

        # Жёсткий потолок на случай если даже recent оказались огромными
        if len(text) > TOTAL_CHARS_LIMIT:
            text = text[:TOTAL_CHARS_LIMIT] + "\n[...история обрезана по лимиту символов]"

        return text
