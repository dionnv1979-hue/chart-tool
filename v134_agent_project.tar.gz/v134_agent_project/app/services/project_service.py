"""
Project service — сохранение и перечисление проектов.
Работает с файловой системой и Repository.
"""
import os
import re

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.constants import PROJECTS_API_LIMIT
from app.core.logger import get_logger
from app.memory.repository import ProjectRepository
from app.memory.models import Project

logger = get_logger(__name__)


class ProjectService:
    """Управление проектами на диске и в БД."""

    def __init__(self, db: AsyncSession) -> None:
        self._db = db
        self._repo = ProjectRepository(db)
        self._projects_dir = os.path.realpath(settings.projects_dir)

    async def save_project(
        self,
        name: str,
        files: dict[str, str],
        session_id: str = "",
    ) -> str:
        """
        Сохранить проект на диск и записать в БД.

        Args:
            name: название проекта (будет санитизировано)
            files: dict {filename: content}
            session_id: ID сессии для связи

        Returns:
            Текстовое описание результата
        """
        safe_name = re.sub(r"[^\w\-]", "_", name)
        project_path = os.path.join(self._projects_dir, safe_name)

        try:
            os.makedirs(project_path, exist_ok=True)
            saved_files = []

            for fname, content in files.items():
                # Санитизируем имя файла
                safe_fname = re.sub(r"[^\w\-\.]", "_", os.path.basename(fname))
                if not safe_fname:
                    continue
                file_path = os.path.join(project_path, safe_fname)
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(content)
                saved_files.append(file_path)

            # Записываем в БД
            await self._repo.save(
                name=safe_name,
                path=project_path,
                session_id=session_id,
            )

            result = (
                f"[OK] Проект '{safe_name}' сохранён → {project_path}\n"
                f"Файлы:\n" + "\n".join(f"  {f}" for f in saved_files)
            )
            logger.info(f"Project saved: {safe_name} ({len(saved_files)} files)")
            return result

        except Exception as e:
            logger.error(f"Project save error: {e}", exc_info=True)
            return f"[ERROR] {e}"

    async def list_projects(self, limit: int = PROJECTS_API_LIMIT) -> list[Project]:
        """Список последних проектов из БД."""
        return await self._repo.list_recent(limit=limit)

    def get_projects_dir(self) -> str:
        return self._projects_dir

    def ensure_projects_dir(self) -> None:
        """Создать директорию проектов если не существует."""
        os.makedirs(self._projects_dir, exist_ok=True)
        logger.info(f"Projects directory: {self._projects_dir}")
