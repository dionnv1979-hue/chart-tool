"""
Services package — lazy imports для избежания circular imports.

Импортируй напрямую из модулей:
    from app.services.ollama_service import OllamaService
    from app.services.tool_service import ToolService
    from app.services.session_service import SessionService

from app.services import X НЕ работает намеренно —
__all__ без реальных импортов вводил в заблуждение.
"""
# Намеренно пустой — импортируй из конкретных модулей
