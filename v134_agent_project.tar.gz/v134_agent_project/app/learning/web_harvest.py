"""
Web Harvest — добыча знаний из интернета в простое.

Цель: ошибки, для которых fix_memory НЕ смогла построить рецепт
(_build_recipe вернул ""), копятся в unsolved.json. В простое воркер:
  1. Берёт нерешённую сигнатуру
  2. Ищет в интернете (web_search: DuckDuckGo/Brave/SerpAPI)
  3. LLM суммирует сниппеты в конкретный рецепт фикса
  4. Записывает в fix_memory с пометкой source=web

Так система реально "берёт знания из интернета" — но точечно, под свои
реальные пробелы, а не абстрактным самообразованием.

Защита от мусора:
  - рецепт принимается только если содержит конкретное действие
  - web-рецепты помечены и в подсказке выглядят как "(из веба, непроверено)"
  - после первого УСПЕШНОГО применения (smoke прошёл) пометка снимается
    обычным механизмом remember_fix — проверенный рецепт перезаписывает web-вариант
"""
from __future__ import annotations

import json
import os
import re
import time

from app.core.logger import get_logger

logger = get_logger(__name__)

_MAX_UNSOLVED = 50
_HARVEST_COOLDOWN = 3600 * 24  # одну сигнатуру не ищем чаще раза в сутки


def _unsolved_path() -> str:
    try:
        home = os.path.expanduser("~")
        desktop = os.path.join(home, "Desktop")
        base = desktop if os.path.isdir(desktop) else home
        mem_dir = os.path.join(base, "agent_memory")
        os.makedirs(mem_dir, exist_ok=True)
        return os.path.join(mem_dir, "unsolved.json")
    except Exception:
        from app.core.config import settings
        base = os.path.dirname(os.path.realpath(settings.projects_dir))
        return os.path.join(base, "agent_unsolved.json")


def _load() -> dict:
    try:
        path = _unsolved_path()
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return {}


def _save(data: dict) -> None:
    try:
        if len(data) > _MAX_UNSOLVED:
            items = sorted(data.items(), key=lambda kv: kv[1].get("count", 0), reverse=True)
            data = dict(items[:_MAX_UNSOLVED])
        with open(_unsolved_path(), "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
    except Exception as e:
        logger.warning(f"unsolved save skipped: {e}")


def remember_unsolved(error_text: str) -> None:
    """
    Записать сигнатуру ошибки, для которой не нашлось рецепта.
    Вызывается из fix_memory.remember_fix когда _build_recipe вернул "".
    Best-effort.
    """
    try:
        from app.memory.fix_memory import error_signature
        sig = error_signature(error_text)
        if not sig:
            return
        data = _load()
        entry = data.get(sig, {"count": 0, "last_harvest": 0})
        entry["count"] = entry.get("count", 0) + 1
        entry["sample"] = error_text.strip()[-300:]
        entry["ts"] = int(time.time())
        data[sig] = entry
        _save(data)
        logger.info(f"web_harvest: нерешённая сигнатура [{sig}] count={entry['count']}")
    except Exception:
        pass


_SUMMARIZE_PROMPT = """Ты — эксперт по отладке Python. По результатам веб-поиска
составь ОДИН конкретный рецепт исправления ошибки.

ОШИБКА:
{error}

РЕЗУЛЬТАТЫ ПОИСКА:
{snippets}

ТРЕБОВАНИЯ:
- Конкретное действие: что именно поменять в коде (1-2 предложения)
- Если результаты поиска НЕ дают ясного ответа — верни ровно: НЕЯСНО
- Не выдумывай: рецепт только из информации в результатах

Рецепт:"""


def _recipe_is_concrete(recipe: str) -> bool:
    """Рецепт должен содержать конкретное действие, не общие слова."""
    if not recipe or len(recipe) < 20 or "НЕЯСНО" in recipe.upper():
        return False
    return bool(re.search(
        r"\b(import|install|замени|добав|удали|поменя|исправ|передай|"
        r"add|replace|change|remove|fix|use)\w*\b",
        recipe.lower(),
    ))


async def harvest_one(ollama) -> bool:
    """
    Обработать ОДНУ нерешённую сигнатуру: web search → LLM → fix_memory.
    Возвращает True если что-то сделано. Вызывается из IdleWorker.
    """
    data = _load()
    if not data:
        return False

    now = int(time.time())
    # Самая частая сигнатура, не искавшаяся последние сутки
    candidates = [
        (sig, e) for sig, e in data.items()
        if now - e.get("last_harvest", 0) > _HARVEST_COOLDOWN
    ]
    if not candidates:
        return False
    candidates.sort(key=lambda kv: kv[1].get("count", 0), reverse=True)
    sig, entry = candidates[0]

    # Помечаем попытку СРАЗУ (даже если не выйдет — не долбим каждый цикл)
    entry["last_harvest"] = now
    data[sig] = entry
    _save(data)

    try:
        # 1. Web search через существующий инструмент
        from app.tools.web_search import WebSearchTool
        from app.schemas.tool import WebSearchParams
        query = f"python {sig.replace(':', ' ')} fix"
        tool = WebSearchTool()
        result = await tool.execute(WebSearchParams(query=query[:200]))
        if not result.startswith("[OK]") or "не вернул результатов" in result:
            logger.info(f"web_harvest: поиск пуст для [{sig}]")
            return True  # попытка была — идём дальше

        snippets = result[4:][:2000]

        # 2. LLM суммирует в рецепт
        prompt = _SUMMARIZE_PROMPT.format(
            error=entry.get("sample", sig), snippets=snippets
        )
        recipe = await ollama.generate(prompt)
        if not recipe or recipe.startswith(("[TIMEOUT]", "[API ERROR")):
            return True

        recipe = recipe.strip()[:300]
        if not _recipe_is_concrete(recipe):
            logger.info(f"web_harvest: рецепт неконкретен для [{sig}] — отброшен")
            return True

        # 3. Записываем в fix_memory с пометкой web
        from app.memory.fix_memory import remember_fix
        remember_fix(entry.get("sample", sig),
                     fix_hint=f"{recipe} (из веба, непроверено)")
        # Решено — убираем из unsolved
        data.pop(sig, None)
        _save(data)
        logger.info(f"web_harvest: ✅ рецепт из веба для [{sig}]: {recipe[:60]}")
        return True
    except Exception as e:
        logger.warning(f"web_harvest error: {e}")
        return True


def unsolved_count() -> int:
    try:
        return len(_load())
    except Exception:
        return 0


__all__ = ["remember_unsolved", "harvest_one", "unsolved_count"]
