"""
Reflection — извлечение уроков из завершённого прогона (идея из Reflexion).

После завершения пайплайна save node пишет снапшот сессии в очередь
(pending_reflection/*.json). IdleWorker в простое берёт снапшоты по одному,
прогоняет через LLM с вопросом "какие уроки?" и складывает результат
в lessons.json.

Почему в простое, а не сразу: рефлексия — это LLM-вызов на 30B модели
(~1-2 мин). Делать её в конце прогона = задержка для пользователя.
В простое GPU всё равно свободна.

Фильтр качества: урок принимается только если он конкретен (есть
КОГДА/ДЕЛАЙ структура или конкретное имя технологии) — общие фразы
("пиши хороший код") отбрасываются.
"""
from __future__ import annotations

import json
import os
import re
import time

from app.core.logger import get_logger
from app.learning.lessons import add_lesson, extract_keywords

logger = get_logger(__name__)


def queue_dir() -> str:
    """Папка очереди рефлексии — рядом с fix_memory."""
    try:
        home = os.path.expanduser("~")
        desktop = os.path.join(home, "Desktop")
        base = desktop if os.path.isdir(desktop) else home
        d = os.path.join(base, "agent_memory", "pending_reflection")
        os.makedirs(d, exist_ok=True)
        return d
    except Exception:
        from app.core.config import settings
        d = os.path.join(os.path.dirname(os.path.realpath(settings.projects_dir)),
                         "pending_reflection")
        os.makedirs(d, exist_ok=True)
        return d


def enqueue_session(session_id: str, user_message: str,
                    required_files: list[str], tests_passed: bool,
                    error_history: list[str], packages: list[str] | None = None) -> None:
    """
    Положить снапшот сессии в очередь рефлексии. Вызывается из save node.
    Дёшево: просто запись JSON, никаких LLM.
    """
    try:
        snap = {
            "session_id": session_id,
            "ts": int(time.time()),
            "user_message": user_message[:500],
            "required_files": required_files[:20],
            "tests_passed": tests_passed,
            "error_history": [e[:400] for e in error_history[-5:]],
            "packages": packages or [],
        }
        path = os.path.join(queue_dir(), f"{int(time.time())}_{session_id[:12]}.json")
        with open(path, "w", encoding="utf-8") as f:
            json.dump(snap, f, ensure_ascii=False, indent=1)
        logger.info(f"reflection: сессия {session_id[:12]} в очереди рефлексии")
    except Exception as e:
        logger.warning(f"reflection enqueue skipped: {e}")


def pending_count() -> int:
    try:
        return len([f for f in os.listdir(queue_dir()) if f.endswith(".json")])
    except Exception:
        return 0


def _pop_oldest() -> tuple[str, dict] | None:
    """Взять самый старый снапшот из очереди (не удаляя — удалим после успеха)."""
    try:
        d = queue_dir()
        files = sorted(f for f in os.listdir(d) if f.endswith(".json"))
        if not files:
            return None
        path = os.path.join(d, files[0])
        with open(path, encoding="utf-8") as f:
            return path, json.load(f)
    except Exception:
        return None


_REFLECTION_PROMPT = """Ты — аналитик качества мультиагентной системы написания кода.
Проанализируй завершённый прогон и извлеки 1-2 КОНКРЕТНЫХ урока для будущих проектов.

ПРОГОН:
Задача: {task}
Файлы проекта: {files}
Зависимости: {packages}
Результат: {result}
Ошибки в процессе (если были):
{errors}

ТРЕБОВАНИЯ К УРОКАМ:
- Конкретика, не банальность. ПЛОХО: "нужно писать код внимательно".
  ХОРОШО: "В pygame-играх метод update() должен принимать dt — три проекта
  падали на несовпадении сигнатуры между game.py и main.py"
- Урок должен быть ПЕРЕНОСИМ на другие проекты того же типа
- Если прогон прошёл чисто без ошибок и нечему учиться — верни пустой список

ОТВЕТЬ СТРОГО JSON без пояснений:
{{"lessons": [{{"topic": "одно_слово_тема", "lesson": "текст урока 1-2 предложения"}}]}}"""


def _looks_concrete(lesson: str) -> bool:
    """
    Фильтр качества: урок должен содержать конкретику —
    имя технологии/файла/метода/ошибки, а не общие слова.
    """
    if len(lesson) < 30:
        return False
    # Есть техническое имя: CamelCase, snake_case, .py, известный термин
    has_tech = bool(re.search(
        r"[a-z_]+\.[a-z]{2,4}\b|[a-z]+_[a-z]+|[A-Z][a-z]+[A-Z]|"
        r"\b(import|def|class|pip|Error|Exception|API|JSON|HTTP)\b",
        lesson,
    ))
    # Общие фразы-маркеры мусора
    is_generic = bool(re.search(
        r"(внимательн|качествен|хорош(ий|о)|правильн|аккуратн|тщательн)",
        lesson.lower(),
    )) and not has_tech
    return has_tech and not is_generic


async def reflect_one(ollama) -> bool:
    """
    Обработать ОДИН снапшот из очереди: LLM-рефлексия → уроки в lessons.json.
    Возвращает True если что-то обработано (для цикла воркера).
    ollama — экземпляр OllamaService.
    """
    item = _pop_oldest()
    if item is None:
        return False
    path, snap = item

    try:
        errors_text = "\n".join(f"- {e}" for e in snap.get("error_history", [])) or "(не было)"
        prompt = _REFLECTION_PROMPT.format(
            task=snap.get("user_message", "?"),
            files=", ".join(snap.get("required_files", [])) or "?",
            packages=", ".join(snap.get("packages", [])) or "stdlib",
            result="УСПЕХ (тесты прошли)" if snap.get("tests_passed") else "ПРОВАЛ (тесты не прошли)",
            errors=errors_text,
        )

        response = await ollama.generate(prompt)
        if not response or response.startswith(("[TIMEOUT]", "[API ERROR")):
            logger.warning("reflection: LLM недоступен — снапшот остаётся в очереди")
            return False  # не удаляем — попробуем в следующем цикле

        # Парсим JSON (модель может обернуть в ```json)
        m = re.search(r"\{[\s\S]*\}", response)
        added = 0
        if m:
            try:
                data = json.loads(m.group(0))
                task_kw = extract_keywords(snap.get("user_message", ""))  # fallback
                for item_l in data.get("lessons", [])[:2]:
                    lesson_text = (item_l.get("lesson") or "").strip()
                    topic = (item_l.get("topic") or "").strip()
                    if _looks_concrete(lesson_text):
                        # Ключи — из ТЕКСТА УРОКА: там смысловые слова
                        # (mainloop, event_handler), а в баг-репорте юзера —
                        # частотный мусор ("теперь не могу"). + topic как ключ.
                        _lkw = extract_keywords(lesson_text, limit=10) or task_kw
                        if topic and topic not in _lkw:
                            _lkw = [topic] + _lkw[:9]
                        if add_lesson(topic, lesson_text,
                                      keywords=_lkw, source="reflection"):
                            added += 1
                    else:
                        logger.info(f"reflection: урок отброшен фильтром: {lesson_text[:60]}")
            except (json.JSONDecodeError, AttributeError):
                logger.info("reflection: невалидный JSON от модели — снапшот пропущен")

        # Снапшот обработан (даже если уроков 0) — удаляем из очереди
        os.unlink(path)
        logger.info(f"reflection: сессия {snap.get('session_id','?')[:12]} → {added} уроков")
        return True
    except Exception as e:
        logger.warning(f"reflection error: {e}")
        # Битый снапшот удаляем чтобы не застрять на нём навечно
        try:
            os.unlink(path)
        except Exception:
            pass
        return True


__all__ = ["enqueue_session", "reflect_one", "pending_count", "queue_dir"]
