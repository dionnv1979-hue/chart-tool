"""
IdleWorker — фоновый воркер самообучения в простое.

Цикл (каждые 60с проверка):
  система в простое >= idle_threshold (10 мин без активных прогонов)?
    ДА → обработать ОДНУ задачу обучения за цикл:
         1. pending_reflection не пуст → reflect_one (уроки из прогона)
         2. иначе unsolved не пуст     → harvest_one (знания из веба)
    НЕТ → спим дальше, GPU нужна пользователю

Почему по одной задаче за цикл: каждая = LLM-вызов на 30B (~1-2 мин).
Если пользователь вернулся — voркер закончит текущую и отдаст GPU
(проверка активности перед КАЖДОЙ задачей, не раз в час).

Активность трекается через mark_activity() — вызывается в начале
каждого прогона пайплайна. Перед LLM-вызовом воркер дополнительно
проверяет нет ли активных SSE-подписчиков (= открытых прогонов в UI).
"""
from __future__ import annotations

import asyncio
import time

from app.core.logger import get_logger

logger = get_logger(__name__)

# Глобальный таймстемп последней активности пользователя
_last_activity: float = time.time()

_IDLE_THRESHOLD = 600      # 10 минут простоя до начала обучения
_CHECK_INTERVAL = 60       # проверка раз в минуту
_worker_task: asyncio.Task | None = None
_learning_now: bool = False  # для UI: воркер сейчас учится


def mark_activity() -> None:
    """Отметить активность пользователя. Зовётся в начале каждого прогона."""
    global _last_activity
    _last_activity = time.time()


def is_idle() -> bool:
    """Система в простое достаточно долго?"""
    if time.time() - _last_activity < _IDLE_THRESHOLD:
        return False
    # Активные SSE-подписчики = открытые прогоны → не простой
    try:
        from app.core import events
        if getattr(events, "_queues", None):
            return len(events._queues) == 0
    except Exception:
        pass
    return True


def status() -> dict:
    """Статус воркера для API/UI."""
    from app.learning.reflection import pending_count
    from app.learning.web_harvest import unsolved_count
    from app.learning.lessons import stats as lessons_stats
    idle_sec = int(time.time() - _last_activity)
    return {
        "running": _worker_task is not None and not _worker_task.done(),
        "learning_now": _learning_now,
        "idle_seconds": idle_sec,
        "idle_threshold": _IDLE_THRESHOLD,
        "pending_reflections": pending_count(),
        "unsolved_errors": unsolved_count(),
        "lessons": lessons_stats(),
    }


async def _loop(ollama) -> None:
    """Главный цикл воркера."""
    global _learning_now
    logger.info(
        f"IdleWorker: запущен (порог простоя {_IDLE_THRESHOLD}s, "
        f"проверка каждые {_CHECK_INTERVAL}s)"
    )
    while True:
        try:
            await asyncio.sleep(_CHECK_INTERVAL)
            if not is_idle():
                continue

            # Простой подтверждён — одна задача обучения за цикл
            from app.learning.reflection import reflect_one, pending_count
            from app.learning.web_harvest import harvest_one, unsolved_count

            did_something = False
            if pending_count() > 0:
                _learning_now = True
                logger.info("IdleWorker: простой → рефлексия сессии")
                did_something = await reflect_one(ollama)
            elif unsolved_count() > 0:
                _learning_now = True
                logger.info("IdleWorker: простой → web-harvest нерешённой ошибки")
                did_something = await harvest_one(ollama)
            _learning_now = False

            if did_something:
                # Сразу проверяем следующую задачу на след. итерации
                # (без доп. ожидания THRESHOLD — простой уже подтверждён)
                continue
        except asyncio.CancelledError:
            logger.info("IdleWorker: остановлен")
            _learning_now = False
            raise
        except Exception as e:
            _learning_now = False
            logger.warning(f"IdleWorker error (цикл продолжается): {e}")


def start(ollama) -> None:
    """Запустить воркер. Вызывается из lifespan (startup)."""
    global _worker_task
    if _worker_task is not None and not _worker_task.done():
        return
    _worker_task = asyncio.create_task(_loop(ollama))


async def stop() -> None:
    """Остановить воркер. Вызывается из lifespan (shutdown)."""
    global _worker_task
    if _worker_task is not None:
        _worker_task.cancel()
        try:
            await _worker_task
        except asyncio.CancelledError:
            pass
        _worker_task = None


__all__ = ["start", "stop", "mark_activity", "is_idle", "status"]
