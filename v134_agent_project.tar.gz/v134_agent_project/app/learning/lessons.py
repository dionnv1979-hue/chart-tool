"""
Lessons — персистентная база уроков, извлечённых из прогонов.

Отличие от fix_memory:
  fix_memory: сигнатура_ошибки → рецепт фикса (узко, точечно)
  lessons:    тип_задачи/тема → общий урок уровня архитектуры/подхода

Примеры уроков:
  topic="pygame", lesson="В pygame-играх выноси константы (размеры, цвета,
    FPS) в constants.py — три проекта подряд имели рассинхрон magic numbers"
  topic="flask", lesson="Для Flask API сразу пиши requirements.txt с
    зафиксированными версиями — pip_install без версий дважды ломал запуск"

Хранилище — JSON рядом с fix_memory (~/Desktop/agent_memory/lessons.json).
Best-effort: любая ошибка тихо игнорируется, пайплайн не страдает.

Подмешивание: при новой задаче ищем уроки по пересечению ключевых слов
задачи с topic/keywords урока. Максимум 3 урока в контекст — без раздувания.
"""
from __future__ import annotations

import json
import os
import re
import time

from app.core.logger import get_logger

logger = get_logger(__name__)

_MAX_LESSONS = 100


def _store_path() -> str:
    """Файл уроков — в той же постоянной папке что fix_memory."""
    try:
        home = os.path.expanduser("~")
        desktop = os.path.join(home, "Desktop")
        base = desktop if os.path.isdir(desktop) else home
        mem_dir = os.path.join(base, "agent_memory")
        os.makedirs(mem_dir, exist_ok=True)
        return os.path.join(mem_dir, "lessons.json")
    except Exception:
        from app.core.config import settings
        base = os.path.dirname(os.path.realpath(settings.projects_dir))
        return os.path.join(base, "agent_lessons.json")


def _load() -> list[dict]:
    try:
        path = _store_path()
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
    except Exception:
        pass
    return []


def _save(lessons: list[dict]) -> None:
    try:
        # Сортируем по полезности (hits) и свежести, режем хвост
        lessons.sort(key=lambda x: (x.get("hits", 0), x.get("ts", 0)), reverse=True)
        with open(_store_path(), "w", encoding="utf-8") as f:
            json.dump(lessons[:_MAX_LESSONS], f, ensure_ascii=False, indent=1)
    except Exception as e:
        logger.warning(f"lessons save skipped: {e}")


# ── Стоп-слова для извлечения ключевых слов ─────────────────────────────────
_STOP = frozenset({
    "сделай", "создай", "напиши", "игру", "игра", "приложение", "программу",
    "проект", "файл", "код", "python", "make", "create", "write", "build",
    "the", "and", "для", "чтобы", "with", "это", "как",
    # Русские частотные (из живых баг-репортов — несут ноль смысла):
    "теперь", "проблема", "проблемы", "могу", "может", "нельзя", "надо",
    "нужно", "при", "запуске", "запустил", "запустила", "после", "снова",
    "опять", "есть", "нет", "очень", "просто", "работает", "работают",
    "сделай", "сделать", "проверь", "проверить", "исправь", "почему",
})


def extract_keywords(text: str, limit: int = 8) -> list[str]:
    """Ключевые слова из текста задачи: значимые слова 3+ символов."""
    words = re.findall(r"[a-zA-Zа-яА-ЯёЁ][a-zA-Zа-яА-ЯёЁ0-9_\-]{2,}", text.lower())
    seen, out = set(), []
    for w in words:
        if w in _STOP or w in seen:
            continue
        seen.add(w)
        out.append(w)
        if len(out) >= limit:
            break
    return out


def add_lesson(topic: str, lesson: str, keywords: list[str] | None = None,
               source: str = "reflection") -> bool:
    """
    Добавить урок. Дедупликация: если очень похожий урок уже есть
    (тот же topic + пересечение слов > 60%) — повышаем его hits вместо дубля.
    Returns True если урок добавлен/обновлён.
    """
    topic = (topic or "").strip().lower()[:40]
    lesson = (lesson or "").strip()[:400]
    if not lesson or len(lesson) < 20:
        return False  # слишком короткий — мусор

    lessons = _load()
    new_words = set(re.findall(r"\w{3,}", lesson.lower()))

    for existing in lessons:
        if existing.get("topic") != topic:
            continue
        old_words = set(re.findall(r"\w{3,}", existing.get("lesson", "").lower()))
        if old_words and len(new_words & old_words) / max(len(new_words | old_words), 1) > 0.6:
            existing["hits"] = existing.get("hits", 0) + 1
            existing["ts"] = int(time.time())
            _save(lessons)
            logger.info(f"lessons: дубликат урока [{topic}] — hits+1")
            return True

    lessons.append({
        "topic": topic,
        "lesson": lesson,
        "keywords": (keywords or extract_keywords(lesson))[:8],
        "source": source,          # reflection | web | manual
        "hits": 0,
        "ts": int(time.time()),
    })
    _save(lessons)
    logger.info(f"lessons: новый урок [{topic}]: {lesson[:60]}")
    return True


def recall_lessons(task_text: str, max_lessons: int = 3) -> str:
    """
    Найти релевантные уроки для задачи. Скоринг — пересечение ключевых слов.
    Возвращает готовый блок для подмешивания в промпт, или "".
    """
    if not task_text:
        return ""
    try:
        lessons = _load()
        if not lessons:
            return ""
        task_kw = set(extract_keywords(task_text, limit=12))
        if not task_kw:
            return ""

        scored = []
        for l in lessons:
            l_kw = set(l.get("keywords", [])) | {l.get("topic", "")}
            score = len(task_kw & l_kw)
            if score > 0:
                scored.append((score, l.get("hits", 0), l))
        if not scored:
            return ""
        scored.sort(key=lambda x: (x[0], x[1]), reverse=True)

        picked = scored[:max_lessons]
        # Помечаем использование (hits) — полезные уроки живут дольше
        for _, _, l in picked:
            l["hits"] = l.get("hits", 0) + 1
        _save(lessons)

        lines = ["💡 УРОКИ ИЗ ПРОШЛЫХ ПРОЕКТОВ (накоплено системой):"]
        for _, _, l in picked:
            src = " [из веба, непроверено]" if l.get("source") == "web" else ""
            lines.append(f"• {l['lesson']}{src}")
        return "\n".join(lines) + "\n"
    except Exception:
        return ""


def stats() -> dict:
    """Статистика базы уроков (для UI/API)."""
    try:
        lessons = _load()
        return {
            "total": len(lessons),
            "by_source": {
                src: sum(1 for l in lessons if l.get("source") == src)
                for src in {l.get("source", "?") for l in lessons}
            },
            "top": [
                {"topic": l["topic"], "lesson": l["lesson"][:80], "hits": l.get("hits", 0)}
                for l in sorted(lessons, key=lambda x: x.get("hits", 0), reverse=True)[:5]
            ],
        }
    except Exception:
        return {"total": 0, "by_source": {}, "top": []}


__all__ = ["add_lesson", "recall_lessons", "extract_keywords", "stats"]
