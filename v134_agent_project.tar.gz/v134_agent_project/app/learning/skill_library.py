"""
Skill Library — библиотека успешных архитектур проектов (идея из Voyager).

Когда проект завершился УСПЕШНО (smoke+тесты зелёные) — сохраняем "скилл":
  - тип задачи (ключевые слова из user_message)
  - структуру файлов которая сработала (required_files)
  - зависимости (installed_packages)
  - точку входа

При НОВОЙ похожей задаче ("сделай змейку" после успешного Тетриса) —
Архитектор получает проверенный шаблон структуры вместо изобретения с нуля.
Это снижает рассинхрон импортов и недописанные файлы: структура уже
доказала работоспособность.

Хранилище — JSON рядом с fix_memory. Best-effort, не ломает пайплайн.
"""
from __future__ import annotations

import json
import os
import time

from app.core.logger import get_logger
from app.learning.lessons import extract_keywords

logger = get_logger(__name__)

_MAX_SKILLS = 50


def _store_path() -> str:
    try:
        home = os.path.expanduser("~")
        desktop = os.path.join(home, "Desktop")
        base = desktop if os.path.isdir(desktop) else home
        mem_dir = os.path.join(base, "agent_memory")
        os.makedirs(mem_dir, exist_ok=True)
        return os.path.join(mem_dir, "skill_library.json")
    except Exception:
        from app.core.config import settings
        base = os.path.dirname(os.path.realpath(settings.projects_dir))
        return os.path.join(base, "agent_skills.json")


def _load() -> list[dict]:
    try:
        path = _store_path()
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
    except Exception:
        pass
    return []


def _save(skills: list[dict]) -> None:
    try:
        skills.sort(key=lambda x: (x.get("hits", 0), x.get("ts", 0)), reverse=True)
        with open(_store_path(), "w", encoding="utf-8") as f:
            json.dump(skills[:_MAX_SKILLS], f, ensure_ascii=False, indent=1)
    except Exception as e:
        logger.warning(f"skill_library save skipped: {e}")


def record_success(task_text: str, project_name: str,
                   files: list[str], packages: list[str] | None = None,
                   entry: str = "") -> None:
    """
    Записать успешный проект как скилл. Вызывается из save node ТОЛЬКО
    при tests_passed=True — в библиотеку попадают только доказанные структуры.
    """
    try:
        if not files or len(files) < 2:
            return  # однофайловые проекты не несут архитектурной ценности
        kw = extract_keywords(task_text, limit=8)
        if not kw:
            return
        # Дедуп по project_name: повторный успех того же проекта (багфиксы,
        # доработки) ОБНОВЛЯЕТ запись, а не плодит дубли с мусорными задачами
        # ("не могу управлять фигурами" — это не скилл, это баг-репорт).
        skills = _load()
        for sk in skills:
            if sk.get("project_name") == project_name:
                sk["files"] = sorted(set(files))
                if packages:
                    sk["packages"] = sorted(set(sk.get("packages", []) + list(packages)))
                if entry:
                    sk["entry"] = entry
                sk["ts"] = int(time.time())
                _save(skills)
                return

        skills = _load()
        kw_set = set(kw)

        # Дедуп: та же задача (пересечение keywords > 70%) — обновляем
        for s in skills:
            old_kw = set(s.get("keywords", []))
            if old_kw and len(kw_set & old_kw) / max(len(kw_set | old_kw), 1) > 0.7:
                s["files"] = sorted(files)
                s["packages"] = packages or []
                s["entry"] = entry
                s["hits"] = s.get("hits", 0) + 1
                s["ts"] = int(time.time())
                _save(skills)
                logger.info(f"skill_library: обновлён скилл [{s.get('task','')[:40]}]")
                return

        skills.append({
            "task": task_text[:150],
            "keywords": kw,
            "project_name": project_name,
            "files": sorted(files),
            "packages": packages or [],
            "entry": entry,
            "hits": 0,
            "ts": int(time.time()),
        })
        _save(skills)
        logger.info(f"skill_library: новый скилл [{task_text[:40]}] — {len(files)} файлов")
    except Exception as e:
        logger.warning(f"skill_library record skipped: {e}")


def recall_skill(task_text: str) -> str:
    """
    Найти подходящий скилл для новой задачи. Возвращает блок для
    промпта Архитектора, или "" если ничего релевантного.
    Порог: минимум 2 общих ключевых слова — иначе шаблон чужой задачи
    навредит больше чем поможет.
    """
    if not task_text:
        return ""
    try:
        skills = _load()
        if not skills:
            return ""
        task_kw = set(extract_keywords(task_text, limit=12))

        best, best_score = None, 0
        for s in skills:
            s_kw = set(s.get("keywords", []))
            score = len(task_kw & s_kw)
            if score > best_score:
                best, best_score = s, score

        # Адаптивный порог: для коротких задач ("сделай тетрис" → 1 ключевое
        # слово) требование 2 совпадений недостижимо. Минимум: 2 ИЛИ все
        # ключевые слова скилла покрыты (для скиллов с 1-2 словами).
        if not best:
            return ""
        _need = min(2, len(best.get("keywords", [])) or 2)
        if best_score < _need:
            return ""

        best["hits"] = best.get("hits", 0) + 1
        _save(skills)

        pkgs = f"\nЗависимости: {', '.join(best['packages'])}" if best.get("packages") else ""
        entry = f"\nТочка входа: {best['entry']}" if best.get("entry") else ""
        return (
            f"📚 ПРОВЕРЕННЫЙ ШАБЛОН (похожая задача уже решалась успешно):\n"
            f"Задача тогда: {best['task']}\n"
            f"Структура которая СРАБОТАЛА: {', '.join(best['files'])}"
            f"{pkgs}{entry}\n"
            f"Используй эту структуру как основу если подходит — она уже "
            f"прошла тесты. Адаптируй под текущую задачу, не копируй слепо.\n"
        )
    except Exception:
        return ""


__all__ = ["record_success", "recall_skill"]
