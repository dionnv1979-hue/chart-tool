"""
AST Guard — предварительная проверка кода до запуска Docker sandbox.
ВАЖНО: AST — второй эшелон защиты, НЕ основная.
Основная защита — Docker (network=none, memory, cpus, read-only, user=nobody).
AST нужен для быстрого отклонения очевидно опасного кода.
"""
import ast
import re

from app.core.constants import (
    FORBIDDEN_BUILTINS,
    FORBIDDEN_ATTRS,
    FORBIDDEN_DANGER_PATTERNS,
)
from app.core.logger import get_logger

logger = get_logger(__name__)


class ASTGuardResult:
    """Результат проверки AST."""

    def __init__(self, safe: bool, reason: str = "ok") -> None:
        self.safe = safe
        self.reason = reason

    def __bool__(self) -> bool:
        return self.safe

    def __repr__(self) -> str:
        return f"ASTGuardResult(safe={self.safe}, reason={self.reason!r})"


# Безопасные stdlib модули которые разрешено импортировать в sandbox.
# Соответствует SANDBOX_SAFE_PRELUDE из constants.py + часто используемые.
_SAFE_IMPORTS = frozenset({
    # Математика и числа
    "math", "cmath", "decimal", "fractions", "statistics", "random",
    # Структуры данных
    "collections", "heapq", "bisect", "array", "queue",
    # Строки и текст
    "re", "string", "textwrap", "unicodedata",
    # Данные и форматы
    "json", "csv", "base64", "hashlib", "hmac",
    # Утилиты
    "itertools", "functools", "operator", "copy", "pprint",
    "enum", "dataclasses", "typing", "abc",
    # Дата и время
    "datetime", "time", "calendar",
    # Тестирование
    "unittest",
    # IO (только in-memory, без файлов)
    "io", "struct", "codecs",
})


class ASTGuard:
    """
    Проверяет Python код на наличие опасных конструкций.
    Не является полной sandbox изоляцией — только быстрый фильтр.
    """

    def check(self, code: str) -> ASTGuardResult:
        """
        Проверить код.

        Returns:
            ASTGuardResult(safe=True) если код прошёл проверку
            ASTGuardResult(safe=False, reason=...) если найдено нарушение
        """
        # 1. Синтаксическая проверка
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return ASTGuardResult(safe=False, reason=f"SyntaxError: {e}")

        # 2. Обход AST дерева
        for node in ast.walk(tree):
            # Import: разрешаем безопасные stdlib модули
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module = alias.name.split(".")[0]  # берём корневой пакет
                    if module not in _SAFE_IMPORTS:
                        return ASTGuardResult(
                            safe=False,
                            reason=f"Запрещён import: {alias.name} (не в whitelist)",
                        )
            if isinstance(node, ast.ImportFrom):
                module = (node.module or "").split(".")[0]
                if module not in _SAFE_IMPORTS:
                    return ASTGuardResult(
                        safe=False,
                        reason=f"Запрещён from {node.module} import (не в whitelist)",
                    )

            # Запрещённые имена переменных/функций
            if isinstance(node, ast.Name) and node.id in FORBIDDEN_BUILTINS:
                return ASTGuardResult(
                    safe=False,
                    reason=f"Запрещено имя: {node.id}",
                )

            # Запрещённые атрибуты
            if isinstance(node, ast.Attribute) and node.attr in FORBIDDEN_ATTRS:
                return ASTGuardResult(
                    safe=False,
                    reason=f"Запрещён атрибут: {node.attr}",
                )

            # Запрещённые вызовы функций
            if isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_BUILTINS:
                    return ASTGuardResult(
                        safe=False,
                        reason=f"Запрещён вызов: {node.func.id}()",
                    )

        # 3. Regex паттерны для дополнительных опасных конструкций
        for pattern in FORBIDDEN_DANGER_PATTERNS:
            if re.search(pattern, code):
                return ASTGuardResult(
                    safe=False,
                    reason=f"Подозрительный паттерн: {pattern}",
                )

        return ASTGuardResult(safe=True)

    def check_and_raise(self, code: str) -> None:
        """Проверить и бросить ValueError если небезопасно."""
        result = self.check(code)
        if not result:
            raise ValueError(f"AST Guard blocked: {result.reason}")


# Синглтон
_ast_guard = ASTGuard()


def get_ast_guard() -> ASTGuard:
    return _ast_guard
