"""
Docker sandbox — изолированное выполнение Python кода.
Основная защита: Docker с --network none, --memory, --cpus, --read-only, --user nobody.
Fallback: subprocess + AST если Docker недоступен.
"""
import asyncio
import re
import shutil
import sys
import time
from typing import Optional

from app.core.config import settings
from app.core.constants import SANDBOX_SAFE_PRELUDE
from app.core.logger import get_logger
from app.sandbox.ast_guard import get_ast_guard

logger = get_logger(__name__)



# ── Классификация Python-ошибок ───────────────────────────────────────────────
# Маппинг типов ошибок → подсказка для агента.
# Помогает агенту не повторять бессмысленные действия (типа run_python с тем же кодом).

_ERROR_HINTS: dict[str, str] = {
    "SyntaxError":         "Синтаксическая ошибка в коде — проверь скобки, кавычки, отступы.",
    "IndentationError":    "Неверные отступы — Python требует одинаковых отступов в блоке.",
    "ModuleNotFoundError": "Модуль недоступен в sandbox. Доступны только stdlib: math, random, re, json, collections, itertools, statistics, unittest. Внешние пакеты недоступны — установи через pip_install.",
    "ImportError":         "Импорт не удался. Sandbox имеет только stdlib.",
    "NameError":           "Имя переменной/функции не определено — проверь опечатки.",
    "TypeError":           "Неверный тип данных в операции.",
    "ValueError":          "Неверное значение аргумента.",
    "AttributeError":      "Объект не имеет такого атрибута — проверь название.",
    "ZeroDivisionError":   "Деление на ноль.",
    "FileNotFoundError":   "Файл не найден. В sandbox нет доступа к файловой системе хоста.",
    "PermissionError":     "Нет доступа. Sandbox запрещает запись/чтение системных путей.",
    "RecursionError":      "Слишком глубокая рекурсия — добавь базовый случай или используй итерацию.",
    "KeyError":            "Ключ отсутствует в словаре — проверь .get() или предварительную проверку.",
    "IndexError":          "Индекс вне диапазона — проверь длину коллекции.",
}


def classify_error(stderr: str) -> tuple[str | None, str | None]:
    """
    Извлекает тип Python-ошибки из stderr и возвращает (тип, подсказку).

    >>> classify_error("Traceback...\nModuleNotFoundError: No module named 'requests'")
    ('ModuleNotFoundError', 'Модуль недоступен в sandbox...')
    """
    if not stderr:
        return None, None
    # Ищем "<ErrorType>: ..." в конце traceback
    match = re.search(r"\n([A-Z][A-Za-z]+(?:Error|Warning|Exception)):\s", stderr)
    if not match:
        # Fallback: ищем в первой строке (без traceback)
        match = re.search(r"^([A-Z][A-Za-z]+(?:Error|Warning|Exception)):\s", stderr)
    if not match:
        return None, None
    error_type = match.group(1)
    hint = _ERROR_HINTS.get(error_type)
    return error_type, hint


class SandboxResult:
    """Результат выполнения кода в sandbox."""

    def __init__(
        self,
        stdout: str,
        stderr: str,
        timed_out: bool = False,
        blocked: bool = False,
        block_reason: str = "",
    ) -> None:
        self.stdout = stdout
        self.stderr = stderr
        self.timed_out = timed_out
        self.blocked = blocked
        self.block_reason = block_reason

    def format_output(self) -> str:
        """Форматировать вывод для ответа агента."""
        if self.blocked:
            return f"[BLOCKED] {self.block_reason}"
        if self.timed_out:
            return f"[TIMEOUT] Выполнение остановлено после {settings.sandbox_timeout}с"
        out = self.stdout or ""
        err = self.stderr or ""
        if err:
            # Классифицируем ошибку и даём подсказку агенту
            error_type, hint = classify_error(err)
            error_block = f"[OK] stdout:\n{out}\n[stderr]:\n{err[:400]}"
            if error_type and hint:
                error_block += f"\n\n💡 {error_type}: {hint}"
            return error_block
        return f"[OK]\n{out}" if out else "[OK] (нет вывода)"


class DockerRunner:
    """
    Запускает Python код в изолированном Docker контейнере.
    Каждый запрос = новый контейнер, который удаляется после завершения.
    """

    def __init__(self) -> None:
        self._docker_available: Optional[bool] = None
        self._image_ready: Optional[bool] = None

    @property
    def docker_available(self) -> bool:
        """Проверяем наличие Docker один раз при первом обращении."""
        if self._docker_available is None:
            self._docker_available = shutil.which("docker") is not None
            logger.info(f"Docker available: {self._docker_available}")
        return self._docker_available

    async def ensure_image(self) -> bool:
        """
        Проверить наличие образа локально.
        Не скачивает — пользователь должен сделать docker pull сам.
        """
        if not self.docker_available:
            self._image_ready = False
            return False
        try:
            proc = await asyncio.create_subprocess_exec(
                "docker", "image", "inspect", settings.docker_image,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await asyncio.wait_for(proc.communicate(), timeout=5)
            self._image_ready = proc.returncode == 0
        except Exception:
            self._image_ready = False
        logger.info(f"Docker image {settings.docker_image} ready: {self._image_ready}")
        return self._image_ready

    async def run(self, code: str) -> SandboxResult:
        """
        Выполнить код. Автоматически выбирает Docker или subprocess fallback.
        """
        if self.docker_available and self._image_ready:
            return await self._run_docker(code)
        return await self._run_subprocess(code)

    async def _run_docker(self, code: str) -> SandboxResult:
        """
        Запуск в Docker контейнере:
        --network none   : нет сети
        --memory 128m    : лимит памяти
        --cpus 0.5       : лимит CPU
        --read-only      : файловая система read-only
        --tmpfs /tmp     : /tmp в tmpfs (RAM)
        --user nobody    : не root
        """
        full_code = SANDBOX_SAFE_PRELUDE + "\n" + code
        container_name = f"agent_sandbox_{int(time.time() * 1000)}"

        cmd = [
            "docker", "run", "--rm",
            "--name", container_name,
            "--network", "none",
            "--memory", settings.sandbox_memory,
            "--cpus", settings.sandbox_cpus,
            "--read-only",
            "--tmpfs", "/tmp",
            "--user", "nobody",
            settings.docker_image,
            "python", "-c", full_code,
        ]

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=settings.sandbox_timeout,
                )
                return SandboxResult(
                    stdout=stdout_bytes.decode("utf-8", errors="replace"),
                    stderr=stderr_bytes.decode("utf-8", errors="replace"),
                )
            except asyncio.TimeoutError:
                logger.warning(f"Docker sandbox timeout: {container_name}")
                return SandboxResult(stdout="", stderr="", timed_out=True)
        except Exception as e:
            logger.error(f"Docker run error: {e}")
            return SandboxResult(stdout="", stderr=str(e), timed_out=False)
        finally:
            # Гарантированная очистка контейнера
            await self._force_remove_container(container_name)

    async def _force_remove_container(self, name: str) -> None:
        """Принудительно удалить контейнер (на случай timeout)."""
        try:
            proc = await asyncio.create_subprocess_exec(
                "docker", "rm", "-f", name,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            await asyncio.wait_for(proc.communicate(), timeout=5)
        except Exception:
            pass  # Если не удалось — ничего страшного, --rm сам почистит

    async def _run_subprocess(self, code: str) -> SandboxResult:
        """
        Fallback: запуск через subprocess на хосте.
        Сначала AST проверка, затем subprocess.
        """
        # AST проверка как предфильтр
        guard = get_ast_guard()
        ast_result = guard.check(code)
        if not ast_result:
            return SandboxResult(
                stdout="",
                stderr="",
                blocked=True,
                block_reason=ast_result.reason,
            )

        full_code = SANDBOX_SAFE_PRELUDE + "\n" + code

        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-c", full_code,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    proc.communicate(),
                    timeout=settings.sandbox_timeout,
                )
                return SandboxResult(
                    stdout=stdout_bytes.decode("utf-8", errors="replace"),
                    stderr=stderr_bytes.decode("utf-8", errors="replace"),
                )
            except asyncio.TimeoutError:
                proc.kill()
                return SandboxResult(stdout="", stderr="", timed_out=True)
        except Exception as e:
            return SandboxResult(stdout="", stderr=str(e))

    def get_sandbox_info(self) -> str:
        """Описание текущего режима sandbox для UI/status."""
        if self.docker_available and self._image_ready:
            mem = settings.sandbox_memory
            cpus = settings.sandbox_cpus
            return f"Docker (network=none, memory={mem}, cpus={cpus}, read-only, user=nobody)"
        if self.docker_available:
            return f"Docker доступен но образ {settings.docker_image} не готов → subprocess+AST"
        return "subprocess+AST (хост, без Docker)"


# Синглтон
_docker_runner: DockerRunner | None = None


def get_docker_runner() -> DockerRunner:
    """FastAPI dependency — синглтон DockerRunner."""
    global _docker_runner
    if _docker_runner is None:
        _docker_runner = DockerRunner()
    return _docker_runner
