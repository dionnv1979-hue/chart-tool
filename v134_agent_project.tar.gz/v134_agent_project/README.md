# 🧠 Qwen Multi-Agent System v2.0

FastAPI + LangGraph мультиагентная система для кодирования, анализа и решения задач через локальный LLM (Ollama).

---

## Стек

| Компонент | Технология |
|-----------|-----------|
| API | FastAPI + uvicorn |
| Workflow | LangGraph + MemorySaver |
| LLM | Ollama (любая локальная модель) |
| Database | SQLAlchemy async + aiosqlite |
| Validation | Pydantic v2 |
| Sandbox | Docker (+ subprocess fallback) |
| UI | Vanilla HTML/CSS/JS |

---

## Архитектура

```
app/
├── main.py              # FastAPI entrypoint + lifespan
├── core/
│   ├── config.py        # Pydantic BaseSettings
│   ├── constants.py     # Все константы
│   └── logger.py        # Логирование
├── memory/
│   ├── models.py        # SQLAlchemy ORM
│   ├── database.py      # async engine + get_db_session
│   └── repository.py    # Repository pattern
├── schemas/
│   ├── chat.py          # Request/Response Pydantic модели
│   ├── tool.py          # Structured tool call схемы
│   └── message.py       # Message/Session схемы
├── services/
│   ├── ollama_service.py  # HTTP клиент Ollama
│   ├── session_service.py # Управление сессиями
│   ├── tool_service.py    # Tool registry + executor
│   └── project_service.py # Сохранение проектов
├── sandbox/
│   ├── ast_guard.py     # AST pre-filter
│   └── docker_runner.py # Изолированный запуск кода
├── tools/               # Реализации инструментов
├── agents/              # BaseAgent + конкретные агенты
├── graph/               # LangGraph workflow
│   ├── state.py         # WorkflowState TypedDict
│   ├── nodes.py         # Узлы графа (make_*_node factories)
│   ├── routes.py        # Conditional edges
│   └── workflow.py      # build_workflow + compile
├── api/                 # FastAPI роутеры
└── ui/                  # HTML + CSS + JS
```

---

## LangGraph граф

```
START
  └─→ route_single_or_pipeline
        ├─→ single_agent ─→ [human_approval] ─→ END
        ├─→ manager ─→ architect ─→ coder ─→ critic
        │                                      ├─→ coder (если не APPROVED и раунды < max)
        │                                      └─→ tester ─→ human_approval
        │                                                      ├─→ save_project ─→ END
        │                                                      └─→ [await confirm]
        └─→ coder (debate) ─→ critic ─→ ...
```

---

## Режимы

- **single** — один агент (выбирается из sidebar)
- **multi** — полный pipeline: Менеджер → Архитектор → Кодер → Критик → Тестер
- **debate** — Кодер↔Критик итерируют до APPROVED или лимита раундов
- **stream** — прямой стриминг токенов без graph (Server-Sent Events)

---

## Быстрый старт

### Требования

- Python 3.11+
- [Ollama](https://ollama.ai) запущен: `ollama serve`
- Модель установлена: `ollama pull qwen3:27b`
- Docker (опционально, для sandbox)

### Установка

```bash
# Клонируем / распаковываем проект
cd agent_project

# Виртуальное окружение
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
# .venv\Scripts\activate   # Windows

# Зависимости
pip install -r requirements.txt

# Запуск
python -m app.main
# или
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

Откройте браузер: [http://localhost:8000](http://localhost:8000)

### Docker Compose

```bash
docker compose up -d
# Логи: docker compose logs -f agent
```

---

## Конфигурация (.env)

```env
OLLAMA_BASE_URL=http://localhost:11434
DEFAULT_MODEL=qwen3:27b
NUM_CTX=32768
NUM_GPU=1
NUM_THREAD=12
TEMPERATURE=0.7

DATABASE_URL=sqlite+aiosqlite:///./agent_memory.db
PROJECTS_DIR=~/Projects

SANDBOX_TIMEOUT=10
DOCKER_IMAGE=python:3.11-slim

DEBATE_MAX_ROUNDS=3
MAX_AGENT_STEPS=5
HISTORY_LIMIT=10

APP_PORT=8000
APP_DEBUG=false
```

---

## API endpoints

| Method | Path | Описание |
|--------|------|---------|
| POST | `/chat` | Отправить сообщение |
| POST | `/confirm` | Подтвердить/отклонить действие |
| POST | `/stream` | Стриминговый ответ (SSE) |
| GET | `/sessions` | Список сессий |
| POST | `/clear` | Очистить сессию |
| GET | `/history` | История сообщений |
| GET | `/models` | Список моделей Ollama |
| GET | `/model` | Текущая модель |
| POST | `/model` | Сменить модель |
| GET | `/files` | Файловый браузер |
| GET | `/projects` | Список проектов |
| GET | `/status` | Статус системы |

Интерактивная документация: [http://localhost:8000/docs](http://localhost:8000/docs)

---

## Инструменты агента

| Инструмент | Тип | Описание |
|------------|-----|---------|
| `run_python` | безопасный | Запуск Python в Docker/subprocess |
| `read_file` | безопасный | Чтение файла |
| `list_files` | безопасный | Список файлов |
| `web_search` | безопасный | DuckDuckGo поиск |
| `write_file` | ⚠️ подтверждение | Запись файла в Projects |
| `save_project` | ⚠️ подтверждение | Сохранение проекта |

---

## Тесты

```bash
pip install pytest pytest-asyncio
pytest tests/ -v
```

---

## Миграция из v1 (Flask монолит)

| v1 (Flask) | v2 (FastAPI+LangGraph) |
|-----------|------------------------|
| Flask routes | FastAPI routers |
| sqlite3 + regex | SQLAlchemy async + Pydantic |
| Global dict TOOLS | ToolService registry |
| Linear pipeline | LangGraph StateGraph |
| HTML в Python строке | Отдельные файлы ui/ |
| Regex tool parsing | Structured JSON tool calls |
| Синхронный код | Полностью async |
