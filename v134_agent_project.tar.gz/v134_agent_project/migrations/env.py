"""
Alembic migration environment.

Поддерживает оба варианта URL:
- sqlite:///./db.sqlite           → sync engine
- sqlite+aiosqlite:///./db.sqlite → async engine

DATABASE_URL из переменных окружения переопределяет alembic.ini.

Запуск:
    alembic upgrade head
    alembic downgrade -1
    alembic revision --autogenerate -m "message"
"""
import asyncio
import os
from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

from alembic import context

# Импортируем Base — autogenerate находит метадату через него
from app.memory.models import Base  # noqa: F401

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata

# Переопределяем URL из ENV (для продакшна / CI)
db_url = os.getenv("DATABASE_URL", config.get_main_option("sqlalchemy.url"))
config.set_main_option("sqlalchemy.url", db_url)

_IS_ASYNC = "+aiosqlite" in db_url or "+asyncpg" in db_url or "+aiomysql" in db_url


def run_migrations_offline() -> None:
    """Генерация SQL без подключения к БД."""
    context.configure(
        url=db_url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        compare_type=True,
        compare_server_default=True,
    )
    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)
    await connectable.dispose()


def run_migrations_sync() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        do_run_migrations(connection)
    connectable.dispose()


if context.is_offline_mode():
    run_migrations_offline()
elif _IS_ASYNC:
    asyncio.run(run_async_migrations())
else:
    run_migrations_sync()
